package com.yash.hibernateMapping;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Student1 {
	@Id
	private int rollno;
	private String name;
	private int marks;
	private Laptop laptop;
	public int getRollno() {
		return rollno;
	}
	public String getName() {
		return name;
	}
	public int getMarks() {
		return marks;
	}
	public Laptop getLaptop() {
		return laptop;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public void setLaptop(Laptop laptop) {
		this.laptop = laptop;
	}
	
	@Override
	public String toString() {
		return "Student1 [rollno=" + rollno + ", name=" + name + ", marks=" + marks + ", laptop=" + laptop + "]";
	}
	
	

}
