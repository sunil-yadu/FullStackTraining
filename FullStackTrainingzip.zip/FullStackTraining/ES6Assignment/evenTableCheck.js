function show(msg){
console.log(msg);
}

let myPromise = new Promise(function(myResolve,myReject){
let x = evenTablePrint();
if(x == 1)
myResolve("Even Table Printing");

else if(x ==2)
myReject("Odd Number");

});




myPromise.then(function(value){show(value);},
function(error){show(error);}
);

function evenTablePrint(str){
	let i=0;
	let j=0;
	for(i==0;i<=10;i++)
		
		if(i%2==0)
			for(j=0;j<=10;j++)
				console.log(i*j);
			
		else
			console.log("odd number" +i);
	
	
 
}

