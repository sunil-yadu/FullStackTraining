function show(msg){
console.log(msg);
}

let myPromise = new Promise(function(myResolve,myReject){
let x = checkPalindrome("naman");
if(x == 1)
myResolve("A palindrome");
else if(x ==0 )
myReject("Not a palindrome");
});



myPromise.then(function(value){show(value);},
function(error){show(error);}
);

function checkPalindrome(str){
const len = str.length;

for(let i=0;i<len/2;i++){
if(str[i] != str[len-1-i]){
return 0;
}
}
return 1;
}