abstract class GeneralBank
{
	abstract void getSavingsInterestRate();
	abstract void getFixedDepositInterestRate();
}
class ICICIBank extends GeneralBank
{
	public void getSavingsInterestRate()
	{
		System.out.println("Saving Rate is 4%");
		
	}
	public void getFixedDepositInterestRate()
	{
		System.out.println("FIxed rate is 8.5%");
	}
}
class SBIBank extends GeneralBank
{
	public void getSavingsInterestRate()
	{
		System.out.println("Saving Rate is 4%");
		
	}
	public void getFixedDepositInterestRate()
	{
		System.out.println("FIxed rate is 7.5%");
		
	}
}


class Bank
{
	public static void main(String args[])
	{
		ICICIBank i=new ICICIBank();
		SBIBank s = new SBIBank();
		//GeneralBank g= new GeneralBank();
		i.getFixedDepositInterestRate();
		i.getSavingsInterestRate();
		s.getFixedDepositInterestRate();
		s.getSavingsInterestRate();
	}
}