
interface LibraryUser{
	public void registerAccount();
	public void requestBook();
}

class KidUser implements LibraryUser
{
	private int age;
	private String bookType;
	
	KidUser(int age, String bookType){
		this.age = age;
		this.bookType = bookType;
	}
	
	public void registerAccount(){
		if(this.age < 12){
			System.out.println("Ragistered succefully for kid");
		}
		System.out.println("OOps age most be less than 12");
	}
	
	public void requestBook(){
		if(!this.bookType.equals("Kids")){
			System.out.println("Requested book from kids account");
		}
		else{
		System.out.println("you are allow to take only kids book");
		}
	}
}

class AdultUser implements LibraryUser{
	private int age;
	private String bookType;
	
	
	AdultUser(int age, String bookType){
		this.age = age;
		this.bookType = bookType;
	}
	
	public void registerAccount(){
		if(this.age > 12){
			System.out.println("Registered for an adult");
		}
		else{
		System.out.println("age most be greater then 12:");
		}
	}
	
	public void requestBook(){
		if(!this.bookType.equals("Fiction")){
			System.out.println("Requestd book for Adult Account");
		}
		else{
		System.out.println("oops kids are not allowed");
		}
	}
}

class Library{
	public static void main(String[] args){
		KidUser k = new KidUser(10,"Kids");
		AdultUser a = new AdultUser(21, "Fiction");
		
		k.registerAccount();
		k.requestBook();
		
		a.registerAccount();
		a.requestBook();
		
		
	}
	}


