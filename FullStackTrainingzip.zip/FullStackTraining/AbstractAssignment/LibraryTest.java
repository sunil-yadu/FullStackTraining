import java.util.Scanner;
interface LibraryUser
{
	 registerAccount();
     requestBook();
	
}
class KidUsers implements LibraryUser
{
	int age;
	String bookType;
	public void setAge(int age)
{
age=age;
}
public void setBookType(String bookType)
{
bookType=bookType;
}
public int getAge()
{
return age;
}
public String getBookType()
{
return bookType;
}


	public static void registerAccount()
	{
		
		if(age<12)
		{
			System.out.println("you have successfully rag as a kid");
		}
		else
		{
			System.out.println("Sorry age must be less than 12 to rag as a kid");
		}
		
	}
	public static void requestBook()
	{
		
		if(bookType=="kids")
		{
			System.out.println("Book issued successfully please return it in 10days");
		}
		else
		{
			System.out.println("OOps you are allow to take only kids book");
		}
		
	}
	
}

class AdultUser implements LibraryUser
{
	int age;
	String bookType;
	public void setAge(int age)
{
age=age;
}
public void setBookType(String bookType)
{
bookType=bookType;
}
public int getAge()
{
return age;
}
public String getBookType()
{
return bookType;
}
	public static void ragisterAccount()
	{
	
		if(age>12)
		{
			System.out.println("you have successfully rag as a adult account");
		}
		else
		{
			System.out.println("Sorry age must be greater than 12 to rag as a kid");
		}
		
	}
	public static void requestBook()
	{
		this.bookType=bookType;
		if(bookType=="Fiction")
		{
			System.out.println("Book issued successfully please return it in 7 days");
		}
		else
		{
			System.out.println("OOps you are allow to take only adult book");
		}
		
	}
	
	
}

class Library
{
	public static void main(String args[])
	{
		KidUsers k=new KidUsers();
		AdultUser a=new AdultUser();
		
		System.out.println("Enter Age");
		Scanner age1=new Scanner(System.in);
		int ag=age1.nextInt();
		
		
		System.out.println("Enter Book Type: ");
		Scanner bType=new Scanner(System.in);
		String b=bType.next();
		 k.setAge(ag);
		 
	     k.setBookType(b);
		 a.setAge(ag);
		 
	     a.setBookType(b);
	
		
		
	}
}