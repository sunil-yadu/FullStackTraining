package animalPackage;
public class Animal
{
public void eat()
{
System.out.println("It can eat");
}

public void walk()
{
	System.out.println("It can walk");
}
}