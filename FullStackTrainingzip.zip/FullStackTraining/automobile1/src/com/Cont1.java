package com;

import com.automobile.Vehicle;
import com.automobile.twowheeler.Honda;
import com.automobile.twowheeler.Hero;
class Cont1{
	public static void main(String[] args){
		Honda ho = new Honda("Model NewOne", "123", "Sunil");
		Hero he = new Hero("Model 2020", "789", "Aman");
		
		
		System.out.println("--------------------------------------------------------");
		
		System.out.println("Hero : owner-" + he.getOwnerName() + ", registration-" + he.getRegistration() + ", model-"+ he.getModelName());
		System.out.println("Speed: " + he.getSpeed());
		System.out.println("Radio: ");
		he.radio();
		
		System.out.println("--------------------------------------------------------");
		
		System.out.println("Honda : owner-" + ho.getOwnerName() + ", registration-" + ho.getRegistration() + ", model-"+ ho.getModelName());
		System.out.println("Speed: " + ho.getSpeed());
		System.out.println("CD player: ");
		ho.cdPlayer();
	}
	
}