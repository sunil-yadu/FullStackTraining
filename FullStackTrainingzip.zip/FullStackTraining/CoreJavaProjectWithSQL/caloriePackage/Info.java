import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.*;

//To get entered Information
class Info 
{   
    double fat;
   // String name;
	int age;
	String gender;
	double height;
	double weight;
    int activity;
	double calculate;
	double bmrM;
	double bmrF;
	/*
public void setName(String pName)
{
name=pName;
}
*/
public void setAge(int pAge)
{
age=pAge;
}
public void setGender(String pGender)
{
gender=pGender;
}
public void setHeight(double pHeight)
{
height=pHeight;
}
public void setWeight(double pWeight)
{
weight=pWeight;
}
public void setActivity(int pActivity)
{
activity=pActivity;
}




/*public String getName()
{
return name;
}*/
public int getAge()
{
return age;
}
public String getGender()
{
return gender;
}
public double getHeight()
{
return age;
}
public double getWeight()
{
return weight;
}
public int getActivity()
{
return activity;
}

public void bmiCal()
{ double fat;
   JFrame frame=new JFrame();
   frame.setSize(800,850);
   fat=weight/height/height*10000;
   //System.out.println("BMI="+fat);
   if(fat<=18.5)
   {     
	   //ImageIcon icon = new ImageIcon("https://cloudfront-us-east-1.images.arcpublishing.com/ajc/CT7KFY3YQGILIH3YNROBKZKIHI.jpg");
	   JOptionPane.showMessageDialog(null, "You are Thin..", 
                "BMI Cal Says:", JOptionPane.INFORMATION_MESSAGE);
   }
   else if(fat>18.5)
   {     //ImageIcon icon = new ImageIcon("C:\Users\Sunil.M\Desktop\Test\fit.jpg");
	   JOptionPane.showMessageDialog(null, "You are Fit..", 
                "BMI Cal Says:", JOptionPane.INFORMATION_MESSAGE);
	   
   }
   else
   {
	  //ImageIcon icon=new ImageIcon("data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYVFRgWFRUYGRgaHBocGBwcHBwaGhodGBwaHBwYGhwcIS4lHB4rHxwZJzgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHBISHDQhISE0NDQ0NDQ0NDQxMTQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDExNDQxNDQxNDQ0ND80NDQ0Mf/AABEIAKgBLAMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAEAAIDBQYHAQj/xABAEAACAQIEAwUGAwcEAQQDAAABAhEAAwQSITEFQVEiYXGBkQYTMqGxwVLR8AcUQmJykuEjorLxwiQzU4I0Q0T/xAAZAQADAQEBAAAAAAAAAAAAAAAAAQIDBAX/xAAhEQEBAQEAAgIDAQEBAAAAAAAAAQIREiEDMRNBUWEiBP/aAAwDAQACEQMRAD8A0v7MLalLxIBYMo1EnKVOngSD6VvFtKBAUR0gRXMP2dcQWy+IzsAuRX1MTkYjTqe1XTbeIVlDhhlIBBnQg86U+jqalVFxLjKIwVbyZgVOSMzMCYygg6E1a+9YkALpPaJ05SMvXWBR0k1Optek0B7SpjOBTQ0waOjiSvajza1JTBVwXjyZbzgcncejGu9Vw32sTLibwj/9j/MzSoU1NY16TTWNAMamGvWovheHzNmOyiT9qm+jn2lw9hUXM8Dopiabf4sx+Dsju3NQYu8GckxA2/6pquJhFJPWorWT+LfhuMOYZy41B2LLprJ0racL9pVJvECVSAgYgOS05l0MZZUxrzFc9w2JNvNnLo0EoRqJ6ETp4inPxE3budgqFgueBCkhQC0RuYk1nrPb1rP5W/u4HC8TTO9p0vAZQymSY1iW7Lxrodd4rA+1Hs62EKmQ9t9EcSNQdQR/C3dr+W24QguC22DxAS4g7duTlcTpmB+KBInpFL22uK+GfMoVpm4mhyOuoYR1AJnnSzvUslZ6xO+nKxRmHJK0HyqTD3CDA1HQ11MU2MEZaGmpcTdLBZEQTUSb0BNiG0XTr9qscCFKKD/N9TVfiphZEb/aprJYIpG0H60BFj27flRWBxKgdphtoKAxBk04WBA31oA03gTNPN8xO9ANZiNZnlTjZIE6UukNTFGochJ3FRJNEWBJimQvBvkIIjskGSQDA3gHeQeVG8btgsHUj8LDZhGxKnWO/uqlTEMp0Md4ifWpxjZXKyzrIOYiDz02+VTz30117J2lbE2g2wJbaZKKzAfKrnD41rQIHMlufPT7VT+ydwh7lxd7dsnaQC7KnPnDNR2Xv5n6mp19tcQN7CYW3exHu7q5lZHgSRqIMyD0BrrvuAiFLQVSFOURoDGhMVxn2LxGTGWD1fL/AHgp967VZUic0b6HqNxPQiYrRmAHDVPaIUXNBm3iDO51JOomjcHY92ipmLRzO5qR9j502+8KT3GKXqew8xN2BPQj6ivMVchZ6Ff+Qqp47f00O4PyII+lOxGIzJ45qi6qpkRiMRGtOe9NuRuCKr8U/ZH62Io7T3TRv2T8xvSg0OLSR4/aanoG4+iHvH5UcK0lSVcV9vLeXG3u9lP9yKa7VXH/ANpKRi3/AJltt8sv2qiZBqa5r1jTWNIPUOoNe4m+wQKDuZPlypk15xC4AECjUj01qdKgVZdgonXc/WtJgbIGvWqXB2yqyfibbuH+asrOJddcgYdBvU1v8fq9q5uWlYQwB8ajXCITAUelPt3cyhtu7pRPCTbuOFL5TIjlUV0ziuWx+7YhHSV0YmO4ST4SK0XtEovqLgH/AL9pdRsTBiepBMedP43bRb1oP8B7BbllugpPkSD5VBhCyYRrTwXwzlG69kghh1UqQays/aNyd9OZMIJFS2F1qbike8YgR2n+RoXDkzNdc9xw31RGOOi+J+lQWNxT8S5IE9ftUdsUwIxpnKe40Vh2hF/XM0LizongftU+Ht9gH9b0BDjviGnL7mpRcEAdwqC/o0DX9bUwGgJmbUVOy6d3yNBqe6iFfQdw+5oJKtqjcDwkOdboWeYUtHjqKERqPwt8DdgB3mKjVs+l5zL9iePezfuLaXLd5bqHssQuQoxBIBUk6GDB7qruH4dSC7rmRfighT8+6ru/xG02GvpJJZUCn+ZXVhv4HWsmnSlLbPZWSa5Pbo3CMElvAXLijW9cQrO+RHAXfvznzqvuHWry8cmCwydLVqfPWqG+df11NRa3xPTNcLv5LiP+B0b+1gftX0Abwg67T9Jr5yQ8u6uz8O4iLmQnVSqMPF0g/UitNa4wk6urWKDAj8Sg+oy/UGo7l7NaQ9VU+oE1VYR2RlDSCAR5KxP/AJUQj/6X9JYf2sR9AKjtq/GRBxQyEJ6D5gGfnTrDFkU/yj5rFQX1le1prv5QPpTsG3ZMHQaejEA+gFECTPKI3UR6gH7UdhDKP/T+VDYXDBkAZsuUkCdPhkTRfDr5YFSojLAMdBVRNou4wCSOUfIiaOU1Uo02vX6TVpbMgHqKrKafXJv2o24xIbraX5O4rrNcx/atb/1LLdUcf2sp/wDKrJzw0w16aa1IPJp6Wc5WDtMnoP1NR0dYGS2zddPECp0rP2bYdS8ch+hU1zDvJCPCnkRt4Gqy02VietXC3ezm5RUujPBdi24tnKZI/wACoMLfJOV0MzuI/Qq44FxTDrbuLcaA6wpiSrToY6ChbBB1OhAqK3zUvGLjrh1D7A5VBPnXuHxrFkac2ZFDE/xAKUluukeg6UDxvFG6qpvlM+O+tS8IQhBOyq/kFBY1nfpOr2+mb4wsO0bFmPzqLDFTpTcc8keZ131JpWbU105+nFr7p2OgQBvufPT7UywxG0a/ran4tYCzE60rNkESapJMpbc+gpwQRzqPE2skQTrPyj869tq5Eg+tBpUEEEad/Tvoi3bMEAiOeq68tJOu/KgjdI0MV6HHNT+vEVISuuU6N6GaY809HTv9P80RYFsmC0DnOlPoR4e+FBJEmOz0nYT3c/KoGedSdatMDh7LKxefiOUCfh5bdaKa1hkEizcbvlQPXX6Uuw+KdQ7LCoxG+ikg+lT2hctw657ZX+MZkif5htVta4ndUqtqUTSFYh4IJMgkab7U68mJuFxkzhgR2lLRP8QiApnn3CjsHGqx993t2s5zFrdtiSASSUBmYnXWqgrWp41hsuGsOYAC21Ous5AI8oNZfEsJ35Cs7G2NemGRq6b7OY9f3ewMnaygFp/A7DauWI1b72RGax8UMrNAPfB+5rTX0yy0lq8fesCZIZv9wH2FWFtuw4/mb/cA33qlLxcJ70PqKsrLyzjuVh59n7VnIumYg5lMHkvqC0/8l9KbgLkJE9frP3ptsdph/L/n7Gm8OB7Y6GfXT7Gmkc1wFWGuhI9ZP3ong7w8TpB09aDOz92X/iPzojhZHvFJ5H6rVpqwwfwx3kfJhVlg2lFP8o+lVeFI2G+Zvqas8ERkWOlE+xfpMzRXPf2sJ2cO3fcX1CH7Vvrz7eIrFftWT/09pul2P7kf8hVpcmJrxq9Jrw0g8UEwBudB51YvJXLyUAem/wA5oTBDtZuSyfPlRaHTx+9RpeVY7RTrZZwelNvCaVpoEcjUr7wTZUoZA+YNGLiWfbSNIoFQBqKL4PhWL69RU69Rrm2+limEZ4I5VpTgxYw7uXALIyjSe1cygAA7nTbnRfC8KvdMVlfbHjFz3nulOVFmdiS0kZ5AkEaRG3nWGe61yNd8xnrJY18zSNoEAwCNO7QeAp+GOtDNRGHrtjge45tVHd969snQVDiD2j3QKJww0pgzHfw+f2qbDaqNKHxp1HnU9gwgI6VIDYsQ0d1F3FkDuFB4r4vIVOMUDoQaA9CU9LAYwKjW6OtFYNwMx6KY8SIHzIoPgV7cHfwqe0HglWIA7zULnWrC2kjIN2UAT1LAH61RH4Tj2Jt6I6xAEFE+oUE+tWI9r8SB2ktHqchkjpMkD0rPjfXkY8I5Ubh7YYwTAAlvDu76mycOWrbifti94KrJkURlQElYHcQDQL8bkzlHqau+LW8/u0jViqDuzOg/OtJc4BZnWxa7v9NNvSo7F8rjiGtd7La23IMFXU+TAj6rWPU1pPZN+06zoyg/2yPvV2IjZF5M9w/21Z4Zu2e9I/tM/eqRp0AkwGPkRt6VZ4Zu0jdQw9QD9qk+ikbtuV0hZXugx9zQmCuSzeG3gT+YqS2CbjRtkefAa/avOF4J3aVWBqBOkg5ZI8NfSn40rqQSW+P+lT9R9qN9n1DMZIBWPPb8qktcIMdp4JEHL2hoTHyb5UbgcDaQwCGgyDIJnUEECqmaV1AuGYm64APxaDrsSfqausPbygr+tZpBlB6ydNNtANPSm4rFBFLMyqo1YuYAHjTmStPa3JE/oiKxP7ReI2btg2UdWuK6tlEmIkGSBGx61Xe0vte96bdglbexbUO47vwr8z8qyqLG9TrX6jXPx991UNhm7vWme5bp8xVvjLABBHPehilT5L/HA/uyAF7InfWfPQVMqwAD/inhKiu2zFK3p+EA3zvUJNPuioGNOIsHYMgiDzrUcMjTashhm1FaHC3QKx+SdbfE2mCYNtMnaNBWY9t/Z+8HD27Fx1I7bKpfXkezJ2irfhN4yoA03mdgKk4z7VPnCWWhV3O8np4Vn8fc661+TN1OOV3DBg6Ebg6EeINTYYg71vmxL3mBch25FlUkeor2/wANtOIe2hP4lUI48GUA10fk/wAc9/8APf6547do+NEYd4FEcb4O2HIMlkY9luYP4X7+/Y1DhAIrSWX6Yazc3lRYppjzomyOwtQ45YKx0P2qbDpKL4UFAuJHa8hRbW1PIUJidHI8KJdooOGPZA2mpihFoAGM7SfBdAPWDUIk0TfcZgBsoy+MSSfU/KgwtpGLR689OtbXg3BsE5U3MbcDCDHuxb2IO5ziNOtY7Dvq3eNPMiiRcqdVWcyx1nB+yHDi2cAXGYz2rjMDP8qkD5Vbt7O4PLl/d7IXuVV85GvzriCPrI0+VELin2Dt6kj0NZ32rw/11TF8MwSOjtcylHDqM8gsNRIMmPypl/jOGzH/AFvka5nhWLuFmZOu+lWf7kvU0h4sGGq99mni6veGB+v2qiG9WPDXyuI/Ugiuli65huDOcjAnTkFJkeOm4o79xRDL5EiCQW1EqVPZWd5rGezHFXNnI91zlciGc845ncd1W7vnEBSxG3IT40dk/Q5V8OI4dYguxXbKoUdP4uVe2+Ks2qoqyDEkz5kggDyqkS2NAQoI6nUT0qZriIkuwyrJlyAI7o1+VHlR4xaWeII5i6oYg/iZkHUkHsj0o5iTJGWCCBzAB5COVYDF+1oXs2UBH4m5+C9PH0oR/a3FHQOFH8qqPtSu1z4nTbmKVLRN18qxM/Dt+Ebk1zX2g4zcxL9okWwZRJGnRmjQt9OVVOIxrO2Z5c9SST86Z76eQFRrVrTPxSe0q0nZSCJHrUD3DBM8qEAqZFa14rdYdApZc3j96h/dHHLwIII9aDVopy3TOpo4jzHPgXH8PoVP3pn7o3d0+JfzqE3jEVAVk0+H53+Isfw50PaUidRIIkd1VDoQa6xh7Fv91yXtRnVRO6M8x2tx0mslxrgTI2WMytORgPiA7hsdRIqZqd4q56zWGUk6Vd4K2SdTGn0pmFwoWjAOlGva854dcxJAyqSBzPM0ywms1MlqaKs4aTUeo1gnhQgsx5Kx9ATUS4gnWrjCYYLbusdhbf8A4Gs9hNVBok6L6WDWFuoyOJVhB+xHeDBB7qxJwzWma2/xIxE9eh8xB863mAWaz/tzg8pS7rB7DR5lSfRh6U8a5rjL5cdz5fxncSAWXwNLOQIB0qBGHKKlzTW7lkeRO+9LKanwyE/CAe40Wllu4eAn6tSuuH49CYa0cwJGg19NvnFJsNcMwhJ51YLaPVvl8uz4Vo/ZjhyOuIDscxtlF1OgPaZ50GYZUgabmjomffGEV2Q6iDzDD7MKntOWglQRzABEAbkZSK3XCP2eNiYuXr4VNlFvtO0HUlm0XXuNarCewmEs/DZLmNWuOzf7fh+VPnU3svI5CbiD+LL4kf8AkB9acjT8LK0frlIrsVzCWkPZS2sfhRZ9YqEudg5HhpR4yqmr/HMuFqVcM4AXWSDtIMVcfvlv8Q+dbNHb8ZPSTPzFMzN+NvX/ABU34p37VPk/xxSpcO0MD3j615kpRFVKixr/AGYuKPeKyzDAjlvPP0rSWMUdQNBE6Dv671k/Z0n3zj8SA/8AHXxgmtT7oDrPiKAmQMx0BNZDj/FDccop7CmNP4mGhJ+nlW4wClSTEdkxz1rlqbfrnS1fS8TqZakDVAhqRKhsmBpwpiipVFKiHMkgjrQiCjkFC3UymOXKlKN59dNpA14rU7LT6y8Xq0Xw2znuou2Z1X1IFDDpReAxXunW4BJTVZ2zRofIwfKjo41HF+NGwystrPZuKc5y5kOVyAGP8LARv1qW3xTD38O5trJUBnQsQAsgEowMpqR3abVjsDxDEW3BQsNdCpMa/iU1qL2MDWMzWkS5cdQxRVU3AhUgtA5HNWWpyHbQjcHBMowC8gzdodxIAB1pr8MZN006gz9KsmcusFo1/FH/ACAmo2d0dUUEzB1I1nw0is/yWKnyWAEtirDC2xUrYHOJUQ2UZBzaJ7J6mI1361X4fFZTJrTvY3xqa+l1xk5MHeYf/G49VIH1rK4A9hfCtRj0N/BXlQgko2XxAkD1FZPhTygjoKfx/tWl3w5xNSe1uHDWG0mBm/t1/OgsM8MK0DoLlsqdQRB86nV5rqpPLNjjmKQKRA5V6LZgEHcA1Px7CGzdKNyGh/ECdD6fMGvHPYTwH0rrl7OvN1LNcr3C4sIxzzoIGXWZijhxi2Nw8/0j86or57fmPoKssLhWcScuU6T8TAHSVB0B7zR4+Qm7le4K2LiM6sIMhcpBZSsfEP4TWl9m+JIlrEWnyjMMyCJJZVOYegU+RrJYJ7eHb4SUYFXjQzsr6jca+tGNeRSri6uUQ2acp0EwAdc3KOtaZzM/bPeta+m8wHtaLVuWBuD+DIAAACAUYwII7xOo33pY/wBskYpkuC0MpYh1+IDeTsFEGSDpXPX4vaLMjt8WouICoIjN8LLvMjblWjVEtYL99uPLsCLK6ABpZc0COyF1yjfnMxR8szqczeH8Xc+9e1uvHUeCBbed8l1D9CTQeOuBxlUuozaHKszB27Qnx0rlwvhTquYeANWNjH2Oar/b/isJjU/bf8mb+msGLuIGtqz5c2Y5QQ0QIAK/Dyqe9bvXDmNwryjMeXM99Z7DcSw06qn9s/aruxj8MwlbDkdRh2I9clZ7z2+60zuSeow2WkyaUZbsM3wqT10opOD330W2xnu/OtYysFeyTxfXvQj0G1bRAZ008P1NZLhnsvjVdXRETLMF2HPQ9lZPOtMnshcf/wDJxjuv4ba5B5zIPpVM6G43xVLVm4Pej3hBCgMMwzabDUaTvWCuXRGldn4T7K4O1qlpCfxN2z4gtIHkKyXtr7AlQb2CQkbvZGpH81sdOqenSlrLTOuMFbeibLVWe8ykqdGGhUiCO4g6inpihtmE+NRxfVoLvfTTiO+osBhLt45bVp7hP4FLDzOw8zXQfZv9nJJD4w6aEWlO/wDWw5fyr68qJm0ruRnuAcAxOM7VtQqTq7yE8F0lz4ad9ZnHh1vvaZh/pu6HLMEoxE66xpX0fbshFCoFVVAAUCFAHIAbVwr2zwuTiOJ0jM6sP/uiMfmTV3MkTN3VV9t6e4nmaiRaeVNQ1hxvRVlwC6ju1u6kq6wjCQUfcFY3nmKqvdDnTc5kRpG0UrOhscBhHwz55JkMApGhkEb7FdjpvRtlJykiSBA7tqA4D7UJAS+QDtLfA3jOgPjWst2LTgEKAOqsY8txWfjy+xc2/SmxGGzj+CR+IDbpO/pXtoAZUeNCSuVjtGwbkZ1ANW78OtTMP/cPyr23hUB7KLruWlvkdPlUa51P4tUOzhFN9wQlvthtszCQqd7E6VinvBge+tr7RW2vqFaQq6qBzMRmI2NYTG4IoSBof1yqs8vqN8YuJ2/ta8K4qbKMuaRBAHjVZwY9k9MzR5GKr3Jg91F8Db/TB6yfUmtZnh3XatCaOw2Oy6VXMabmpWSiXir9tVFxFuAdpJk/yNv6GD61n3QlEgHYfQVq8S0g1VLibbaEwe/l6Grz6nHN8s/66zjoc23MVYYFwmgLaGdNDB3A76sF4SXPZuKe7Y+k0k4HcZ3tpq9sAmNyWEqoA1mKd0ymVfi3JP8A7ucExqGVhPMgjUeFetgLgEhc4GvZII0AJ2naRPiKJ4jwzE4ZEfEI9sPOUNlJMbzE5TtoetBLeMnRDAElez9N6rytPxiG4j6KykQRy1Guv/VWmKfE3ktWwT7u0GCDX+NixJEnXbu0qFeIOsEs40BWYcc9Rm5TJ8assB7TtaHw2rm3ZZIYAADQx50eVLxVa4NknMCY3q/4c+BVU95adjlGcSgBMGTPxDf5UHifaNLmb/01pSZ1LvuZ1AJjyihrXGQmq28KTKntWxcYZQAYLAwDvv1iKPs56ro/BvZ7DYhEv4e2EQZgVYBmdlO87RW0t2CBGaO4BQPSuKj25xagKuIQAQBlQADLJJgLsZiKhb20xh//AK35xC7iSZ27/SKzuLVdbxcAkhsoDDY7H1H0oo8syhoMjTUHqOVQC4B4jcdPHpT1vVslYWsSDz+x9KKW+TvrVS7giQO0O8j5ipLd4jfXrH50FxbBp1Eg9Rv617ZxVxSS5DJyyqFYeOsN5RQCOG2NEJsdSe/celA7RzJYvavbtuf51VmHd2hIonDYe2miW0TuVVX6Cqi8gYCGKkGQRHp2gY8oqVMS6cjcHWQHHloG+VLg7F4g8vCkCw37Q67H8jVZhOKI5iYbmrDKw8qMfEmOQ8aZWKj2u9qEwdqRDXXkW1PUbsw3yjTxkCuJYriD37r3brFnaJJjkIAEbADSKsvavjDYvEPcnsfCg10RZy69+reLVRAQwnnUavVZnFgj1KTQ9oVMahvCyzU1vDTUlm1pR1pKDkRpggRtRGD4a6n/AE3dP6GZfkNKmt1o+FOFG1Rq+muZGevHEK+Vrtw92Y/OK1fBsRoAareJ5c8gcqO4XdXSs9TsaTjRG0GWDWP9puHEdoDb6VsbB6UJxkLkObc0ss+8vHJb4AnSmcDxAgr0Yj11H1ozi+HCOehrOYa/kvEToRXRn3Gerytmp0qF2qNL0rXj3ABSaIsRc0NZp0XOCYidQdQfGaucVe0iqiy/+sonfTrqdJqs/bD5KHxPYfssQpjblPKDoa3XspxUYbDu/vbaM5LMQpuXgqCPhHwroTr1rLYm37u5lOUqxAbTQAhZI/CRBgirLFcVVF9wrAqqhTpOYFRqdIMggx309Z76jKWT3RHFuI28Yh+O4x2Z3AKmOSrMc9KxtxCpKncb+EbjrUmIKo4a0WU8xy8vyNPv4s3YLAZlIBPIyenLnTznxTdSoWdgZDcoHcCRoJ5ampM8wNBy1jfSZNQlDA8VBPi2x8hRlhFbMC0GDlMxr1nb/qq4XUWUKT2QzAmd2TURy31M0421yMRMCJkCQ0dfw01Nojlry7/TapcNZzsZOgAJI2nlvy0GvcaZdDM4GUgiQQBp36E9f8U0nqVBOupiZ1mKfe+Ef1Ad/P8AL5026sxqdABz8enfS4fa7NirYbWNeRB1oN2ZN+0Oo3HivPymiyxppfqPzqJWtR2L4OxBokXaDv2M3aHZb8Q09RsaFv4p7fxrPR0DMP7VBIP6mrlTYuUuKTufKpPeEazI686z/wC9u3wWnjkzRbWekHt+eWnvbusjReRHI7MIXAPexcf8afU1oBfB1mn/AL5l5iO/T51l7FtA4N43g/ItcYox/lyZV8mAPdzq0e2mhAgjZh8QnvP3pdHB9zFo42LRtl3Hg23zqo41xfJhrgS6SWGQI6kXFz6EgwNhO8+NPbGsNHPnyP5VQe1GIz5EnbMx01/CBpy1NK6VxlIM/wDYrx/nRnuzyIPdqD6NUN5dhsZqTiSytEoutNsppU6jWptawQgopFoe3R1paFw+2tWWGv5aDWvS1Li0t+5mMmlh7xQ0H73tVO1HB1ocLxjIJbaq/FcUa4SxEDlVRcJqB7xjupTMibUHFGzzWLx9ps8jkPvWqxFyqPG2wWWesdN6rLLfuLjhjH3ak7kAnz1r3EPTk0EChL760NO8yGxL0Dh8UEfPkzssZZOg8v4jU996rnb4gO70nU/QedVlz7qxxOP960xqYPTlEfrrUGPvSQ2miKpHeugbaNso8qDFwzM7fnUt1s6zG3Tv7/GtGdoVmmT8q9RtxG4jX61AxBqS1OYazrzoIZc1VNCDmHyaPtSsoxMAb65QJPj3frevGM5F1+Mn1OkUZecBgLAMgTJJEnbNrBGpigGWgmXM5zGdEAOp6/r5VFccsSQAoJ2Gg8PXp68ql9yoBJOfQMW2AVoCsSY7MFjI5rHKmuxSUYA5o7RGvWBOxPP9GgBgJgdWH0avDPX60TiLJR0E79oET+E9amw6plWYmBPw7/2H60qI3TYu6hyhxcHIk5WXuJAIYeVevibk9t0C8mAZvUkjIfEEd9KlSWkzafG7eJj0ygUxLzDePLSvaVAem9NL3h60qVP9GRxGhB1HMHWaFll+B4/kaSnlzX5jur2lSBh4iJC3AUPeOyfBtj9e6q/HtmcxyAA3Pfy2pUqk6hRZ7/DUeYOvpQmMTtIe/wC1KlQU+xCCpVFKlUthFuikalSoVE4am3GkUqVCgWQ5viNGI5ivaVBGu00LepUqCquxJgVU5s7qByIJ8qVKnEaWLXyBzoS9dnelSpsu0BeuVLgLGbUgeevgAPClSploa9hY+3Z+gqra0bbsm+sdxGh/I0qVOJVl5MrEeY8DtXtowQaVKqSNtt2lnbN9ifpR9xwLjFBlAAKgGJyt8HYkwTqY5LrFKlQYe7i8rFREHmCY0OnMyZGu28U9m7PKCVk6MWY5SDm+L4QZzDkD0pUqCLHgB0ysCMskrA3UdPGpLXvIEK0QPp/VXtKpN//Z");
	   JOptionPane.showMessageDialog(null, "You are Fatty..", 
                "BMI Cal Says:", JOptionPane.INFORMATION_MESSAGE); 
   }
   
	
}


//To calculate BMR For Male bcz it is needed in calorie formula to find exact need.
public double setBmrMale(double pWeight,double pHeight,int pAge)
{
 
 this.bmrM=10*pWeight+6.25*pHeight-5*pAge+5;
 //System.out.println("Bmr for Male is: " +bmrM);
 return bmrM;
 
	
}
//To calculate BMR For Female to find exact need

public double setBmrFemale(double pWeight,double pHeight,int pAge)
{
 
 this.bmrF=10*pWeight+6.25*pHeight-5*pAge-161;
 //System.out.println("Bmr for FeMale is: " +bmrF);
 return bmrF;
 
	
}
  
//To display entered Information...

	public void display()
	{
		//System.out.println("Entered Name is :"+name);
		System.out.println("Entered age is :"+age);
		
		System.out.println("Gender is:"+gender);
		
		System.out.println("Entered Height is :"+height);
		System.out.println("Entered Weight is:"+weight);
		System.out.println("Entered activity is :"+activity);
		System.out.println("BmrM is :"+bmrM);
		System.out.println("BmrF is :"+bmrF);
		//System.out.println("Fat is :"+fat);
		
		
		
	}
	
	//To calculate Final need for active person..
	public void needCalorieActive()
	{
		//System.out.println("Calorie Need For Active Male:="+bmrM*1.375);
		JOptionPane.showMessageDialog(null, bmrM*1.375, "Calorie Need For Active Male:=.", JOptionPane.PLAIN_MESSAGE);
		
	}
	////To calculate Final need for Moderate person..
	public void needCalorieModerate()
	{
		//System.out.println("Calorie Need For Moderate Male:="+bmrM*1.5);
		JOptionPane.showMessageDialog(null, bmrM*1.5, "Calorie Need For Moderate Male:=.", JOptionPane.PLAIN_MESSAGE);
		
	}
	//To calculate Final need for Hard person..
	public void needCalorieHard()
	{
		//System.out.println("Calorie Need For Hard Male:="+bmrM*1.7);
		JOptionPane.showMessageDialog(null, bmrM*1.7, "Calorie Need For Hard Male:=.", JOptionPane.PLAIN_MESSAGE);
		
	}
	
	//To calculate Final need for active Female ..
	public void needCalorieActiveFemale()
	{
		//System.out.println("Calorie Need For Active Female :="+bmrF*1.375);
		JOptionPane.showMessageDialog(null, bmrM*1.375, "Calorie Need For Active FeMale:=.", JOptionPane.PLAIN_MESSAGE);
		
	}
	//To calculate Final need for Moderate Female..
	public void needCalorieModerateFemale()
	{
		//System.out.println("Calorie Need For Moderate Female:="+bmrF*1.5);
		JOptionPane.showMessageDialog(null, bmrM*1.5, "Calorie Need For Moderate FeMale:=.", JOptionPane.PLAIN_MESSAGE);
		
	}
	//To calculate Final need for Hard Female..
	public void needCalorieHardFemale()
	{
		//System.out.println("Calorie Need For Hard Female:="+bmrF*1.7);
		JOptionPane.showMessageDialog(null, bmrM*1.7, "Calorie Need For Hard FeMale:=.", JOptionPane.PLAIN_MESSAGE);
		
	}
	
	
	
}

