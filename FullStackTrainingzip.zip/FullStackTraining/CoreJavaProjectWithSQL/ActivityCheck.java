class ActivityCheck
{
	public static void main(String args[])
	{
		String[] activity=new String[] {"No","Moderate","Active","VeryActive","ExtraActive"};
		for(int i=0;i<activity.length;i++)
		{
		System.out.println(activity[i]);
		}
	}

}