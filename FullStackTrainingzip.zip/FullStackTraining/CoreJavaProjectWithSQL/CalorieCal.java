
import java.util.Scanner;
import caloriePackage.*;


class CalorieCal extends Info
{
	public static void main(String args[])
	{
		System.out.println("Enter your activity level");
		System.out.println("1_Active: 2_Moderate: 3_Hard");
		
		
		
		Scanner choice=new Scanner(System.in);
		int a=choice.nextInt();
		
		/*System.out.println("Enter Name");
		Scanner name1=new Scanner(System.in);
		String n=name1.next();
		*/
		
		System.out.println("Enter Age");
		Scanner age1=new Scanner(System.in);
		int ag=age1.nextInt();
		
		
		System.out.println("Enter Gender: 1_Male 2_Female ");
		Scanner gender1=new Scanner(System.in);
		String g=gender1.next();
		
		System.out.println("Enter Height in CM: ");
		Scanner height1=new Scanner(System.in);
		double h=height1.nextDouble();
		
		System.out.println("Enter Weight in KG: ");
		Scanner weight1=new Scanner(System.in);
		double w=weight1.nextDouble();
        Info f=new Info();
		
		if(a==1){
			
		switch(g){
		case "male":
		{
			//System.out.println("Active");
			f.setBmrMale(w,h,ag);
			f.needCalorieActive();
			//f.display();
			break;
			
		}
		case "female":
		{
			System.out.println("Moderate");
			f.setBmrFemale(w,h,ag);
			f.needCalorieActiveFemale();
			//f.display();
			break;
		}
		
		default :
		{
			System.out.println("Please select right option");
		}
		}
		}
		else if(a==2)
		{
			switch(g){
		case "male":
		{
			System.out.println("Active");
			f.setBmrMale(w,h,ag);
			f.needCalorieModerate();
			//f.display();
			break;
			
		}
		case "female":
		{
			System.out.println("Moderate");
			f.setBmrFemale(w,h,ag);
			f.needCalorieModerateFemale();
			//f.display();
			break;
		}
		
		default :
		{
			System.out.println("Please select right option");
		}
		}
			
		}
		else if(a==3)
		{
		switch(g){
		case "male":
		{
			System.out.println("Active");
			f.setBmrMale(w,h,ag);
			f.needCalorieHard();
			//f.display();
			break;
			
		}
		case "female":
		{
			System.out.println("Moderate");
			f.setBmrFemale(w,h,ag);
			f.needCalorieHardFemale();
			//f.display();
			break;
		}
		
		default :
		{
			System.out.println("Please select right option");
		}
		}
		}
		
		
		
	   f.setActivity(a);
	   //f.setName(n);
	   f.setAge(ag);
	   f.setGender(g);
	   f.setHeight(h);
	   f.setWeight(w);
	   f.display();
	   //f.bmiCal();
	   System.exit(0);
		
	}
	
}