package com.yash.springjdbc.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.yash.springjdbc.entities.Student;

public class StudentDaoImpl implements StudentDao {
	private JdbcTemplate jdbctemp;

	@SuppressWarnings("unchecked")
	public Student selectDetails(int stuid) {
		// TODO Auto-generated method stub
		String q="select * from student where id=?";
		RowMapper rowmapper=new RowMapperImpl();
		Student student=this.jdbctemp.queryForObject(q,rowmapper,stuid);

		return student;

		}

}
