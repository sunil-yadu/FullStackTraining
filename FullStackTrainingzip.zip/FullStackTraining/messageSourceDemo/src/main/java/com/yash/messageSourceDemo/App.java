package com.yash.messageSourceDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
       System.out.println(context.getMessage("message", null,"Default Message",null)); 
      ((AbstractApplicationContext) context).close();
        
    }
}
