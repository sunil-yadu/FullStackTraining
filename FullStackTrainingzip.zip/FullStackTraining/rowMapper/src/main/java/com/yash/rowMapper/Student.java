package com.yash.rowMapper;

public class Student {
	private String gmail;  
	private String name;  
    
	public String getGmail() {
		return gmail;
	}

	public void setGmail(String gmail) {
		this.gmail = gmail;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String toString(){  
	    return gmail+" "+name ; 
	}  

}
