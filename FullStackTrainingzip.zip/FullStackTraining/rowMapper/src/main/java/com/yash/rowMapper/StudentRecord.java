package com.yash.rowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.jdbc.core.RowMapper;

import javax.swing.tree.RowMapper;
import javax.swing.tree.TreePath;

import org.springframework.jdbc.core.JdbcTemplate;

public class StudentRecord implements RowMapper{
	private JdbcTemplate template;  
	  
	public void setTemplate(JdbcTemplate template) {  
	    this.template = template;  
	}  
	  
	public List<Student> getAllSpringDataRowMapper(){  
	 return template.query("select * from springdata",new RowMapper()){  
	    public Student mapRow(ResultSet rs, int rownumber) throws SQLException {  
	        Student s=new Student();  
	        s.setGmail(rs.getString(1));  
	        s.setName(rs.getString(2));  
	         
	        return s;  
	    }

		public int[] getRowsForPaths(TreePath[] path) {
			// TODO Auto-generated method stub
			return null;
		}  
	    });  
	}

	public int[] getRowsForPaths(TreePath[] path) {
		// TODO Auto-generated method stub
		return null;
	}  

}
