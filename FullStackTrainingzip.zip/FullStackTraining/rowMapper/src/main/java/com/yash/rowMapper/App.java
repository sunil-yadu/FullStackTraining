package com.yash.rowMapper;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
	public static void main(String[] args) {  
	    ApplicationContext ctx=new ClassPathXmlApplicationContext("Beans.xml");  
	    StudentRecord dao=(StudentRecord)ctx.getBean("ds");  
	    List<Student> list=dao.getAllSpringDataRowMapper();  
	          
	    for(Student s:list)  {
	        System.out.println(s);  
	    }
	   
	}  
}
