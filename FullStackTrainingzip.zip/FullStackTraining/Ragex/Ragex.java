import java.util.regex.*;
class Ragex
{
	public static void main(String args[])
	{
		//Pattern pt=Pattern.compile("Hello /to / Welcom",Pattern.CASE_INSENSITIVE);
		//Pattern pt=Pattern.compile(".");
		//Pattern pt=Pattern.compile(".el.a");
		//Pattern pt=Pattern.compile("^Hello");
		//Pattern pt=Pattern.compile("java$"); Hello 0 5
		//Pattern pt=Pattern.compile("\\d"); integer and their index
		//Pattern pt=Pattern.compile("\\D"); all string and their index
		//Pattern pt=Pattern.compile("\s");
		//Pattern pt=Pattern.compile("\\S");all string and integer and their index
		//Pattern pt=Pattern.compile("\\w"); starting index and ending index
		// pt=Pattern.compile("\\W"); space and special character and their index
		//Pattern pt=Pattern.compile("\\bHello"); 0 to 5
		Pattern pt=Pattern.compile("Java\b");
		
		
	
	Matcher mt=pt.matcher("Hello123 & Welcom56 to 89 java");
	
	while(mt.find())
	{
		System.out.println(mt.group()+"\t"+mt.start()+"\t"+mt.end());
	}
	}
}