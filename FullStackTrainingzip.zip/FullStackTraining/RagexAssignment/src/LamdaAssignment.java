public interface LamdaInterface {
	void display();
}

public class LamdaAssignment implements LamdaInterface{
	public static void main(String[] args) {
		LamdaInterface obj =()->{System.out.println("Implementation of lamda");};
		obj.display();
	
	}
	

}
