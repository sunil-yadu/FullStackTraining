import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class RagexAssignment2 {
	public static void main(String[] args) {
		String s1="Hii buddy 'How are you?'";
		Pattern pt= Pattern.compile("'(.*?)'");//syntax to find sub string in any string.
		Matcher mt=pt.matcher(s1);
		while(mt.find())
		{
			System.out.println(mt.group()+"\t"+mt.start()+"\t"+mt.end());
		}
		
	}

}
