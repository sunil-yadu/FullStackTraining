import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class URLRagex {

	public static void main(String[] args) {
		String url="((http|https)://)(www.)?"
	              + "[a-zA-Z0-9@:%._\\+~#?&//=]"
	              + "{2,256}\\.[a-z]"
	              + "{2,6}\\b([-a-zA-Z0-9@:%"
	              + "._\\+~#?&//=]*)";
		Pattern pt=Pattern.compile(url);
		
				
	
		
		
	
	Matcher mt=pt.matcher("https://spring.io/tools");
	

	if(mt.matches()==true)
	{
		//System.out.println(mt.group()+"\t"+mt.start()+"\t"+mt.end());
		System.out.println("URL  Validated");
	}
	else {
		System.out.println("URL is Not Validated");
	}
}
}
