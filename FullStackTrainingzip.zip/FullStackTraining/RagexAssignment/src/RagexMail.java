import java.util.regex.Matcher;
import java.util.regex.Pattern;

class RagexMail
{
	public static void main(String args[])
	{
		
		Pattern pt=Pattern.compile("^([0-9])(\\d)");
		//Pattern pt=Pattern.compile("7089094454");
		
		
	
	Matcher mt=pt.matcher("7898909094");
	
	while(mt.find()==true)
	{
		//System.out.println(mt.group()+"\t"+mt.start()+"\t"+mt.end());
		System.out.println("Number Validated");
	}
	}
}