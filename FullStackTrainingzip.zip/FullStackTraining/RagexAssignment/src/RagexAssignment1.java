import java.util.regex.*;


public class RagexAssignment1 {
	public static void main(String[] args) {
		Pattern pt= Pattern.compile("\\d");
		Matcher mt=pt.matcher("Hii here 1 2 3 ");
		while(mt.find())
		{
			System.out.println(mt.group()+"\t"+mt.start()+"\t"+mt.end());
		}
		
	}

}
