import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate; 
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;

public class DateApi {    
  public static void main(String[] args) {    
    LocalDate date = LocalDate.now();    
    LocalDate yesterday = date.minusDays(1);    
    LocalDate tomorrow = yesterday.plusDays(2);    
    System.out.println("Today date: "+date);    
    System.out.println("Yesterday date: "+yesterday);    
    System.out.println("Tomorrow date: "+tomorrow); 
    LocalTime time1=LocalTime.now();
    System.out.println("Local Time:"+time1);
    System.out.println("Local Time Before 1 Hour:"+time1.minusHours(1));
    System.out.println("Local Time After 1 Hour:"+time1.plusHours(1));
    System.out.println("Local Time Before 10 Minutes:"+time1.minusMinutes(10));
    System.out.println("Local Time After 10 Minutes:"+time1.plusMinutes(10));
   // ZoneId zone1 = ZoneId.of("Asia/NewDelhi");
    ZoneId zone1 = ZoneId.of("Asia/Kolkata");
    
    ZoneId zone2=ZoneId.of("Asia/Tokyo");
    LocalTime t1=LocalTime.now(zone1);
    LocalTime t2=LocalTime.now(zone2);
    System.out.println("India Time Zone:"+t1);
    System.out.println("Japane Time Zone:"+t2);
    long diffHour=ChronoUnit.HOURS.between(t1, t2);
    System.out.println("Difference of Hours:"+diffHour);
    long diffMinutes=ChronoUnit.MINUTES.between(t1, t2);
    System.out.println("Difference of Minutes:"+diffMinutes);
    
    
    
    LocalDate date1 = LocalDate.of(2016,1,1);    
    System.out.println(date1.isLeapYear());    
    LocalDate date2 = LocalDate.of(2016,1,1);    
    System.out.println(date2.isLeapYear());  
    LocalDateTime datetime=date1.atTime(2,50,9);
    System.out.println(datetime);
    date2=LocalDate.now();//To print current time
    String s1=date2.format(DateTimeFormatter.ISO_DATE);
    System.out.println(s1);
    String s2="2022-11-12";
    LocalDate d1=LocalDate.parse(s2);
    System.out.println(d1);
    
  }    
}    