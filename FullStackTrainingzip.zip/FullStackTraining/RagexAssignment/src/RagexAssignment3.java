import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class RagexAssignment3 {
	public static void main(String[] args) {
		String s1="Hii'how'are'you'?";
		String[] split1=s1.split(Pattern.quote("'"));
		
		for(String s:split1)
		{
			System.out.println(s);
		}
	}

}
