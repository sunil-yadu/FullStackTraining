import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class RagexAssignment4 {
	public static void main(String[] args) {
		int n=7;
		public static boolean isPrime(int n) {
		    return !new String(new char[n]).matches(".?|(..+?)\\1+");
		}
		
	}

}
