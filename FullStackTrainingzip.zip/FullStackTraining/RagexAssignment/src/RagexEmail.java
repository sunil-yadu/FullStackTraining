import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RagexEmail {
	public static void main(String[] args) {
		String mail="^(.+)@(.+)$";
		Pattern pt=Pattern.compile(mail);
		Pattern pt1=Pattern.compile(mail);
				
	
		
		
	
	Matcher mt=pt.matcher("sunil.m@yash.com");
	Matcher mt1=pt1.matcher("sunilYashCom");
	
	if(mt.find()==true)
	{
		//System.out.println(mt.group()+"\t"+mt.start()+"\t"+mt.end());
		System.out.println("Email  Validated");
	}
	else {
		System.out.println("Mail Not Validated");
	}
	if(mt1.find()==true)
	{
		//System.out.println(mt.group()+"\t"+mt.start()+"\t"+mt.end());
		System.out.println("Email  Validated");
	}
	else
	{
		System.out.println("Maile Not validated"+mt1);
	}
	}

}
