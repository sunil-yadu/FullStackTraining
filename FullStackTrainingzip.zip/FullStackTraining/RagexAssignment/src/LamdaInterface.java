
public interface LamdaInterface {
	void display();
}
