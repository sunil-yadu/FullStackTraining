import com.automobile.twowheeler.*;

class Test{
public static void main(String args[]){
	   Hero h=new Hero();
		h.getSpeed(60);
		h.cdplayer();
		h.getModelName("2022Interprise");
		h.getRegistrationNumber("2AS33");
		h.getOwnerName("Sunil");
	
	   Honda h=new Honda();
		h.getSpeed(60);
		h.cdplayer();
		h.getModelName("2022Interprise");
		h.getRegistrationNumber("2AS33");
		h.getOwnerName("Sunil");
	
	}
	}