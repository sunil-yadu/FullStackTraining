package com.automobile.twowheeler;
import com.automobile.*;
class Hero extends Vehicle
{
	int s;
	String mName;
	String rgN;
	String oName;
	public int getSpeed(int s)
	{
		return s;
	}
	
	public void cdplayer()
	{
		System.out.println("yes cd playerr Facility is available:");
	}
	
	public String getModelName(String mName)
	{
		return mName;
	}
	public String getRegistrationNumber(String rgN)
	{
		return rgN;
	}
	public String getOwnerName(String oName)
	{
		return oName;
	}
	
	
}