package LoginCode;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import DBConnection.DataBaseConnectivy;

public class Login
{
	String gmail;
	String password;
	public void login() {

	try {
		
		PreparedStatement p=null;
		ResultSet rs=null;
		boolean status=false;
		
		Connection con= DataBaseConnectivy.dbConnection();
		
		InputStreamReader in = new InputStreamReader(System.in);
	    BufferedReader b = new BufferedReader(in);
		
		System.out.println("Please Enter Your UserName/Gmail: ");
		this.gmail=b.readLine();
		
		System.out.println("Enter Password: ");
		this.password=b.readLine();

		String sq="select * from userlogin where gmail=? and password=?";
		// inserting records
		
		p=con.prepareStatement(sq);
		p.setString(1, this.gmail);
		p.setString(2, this.password);
		rs=p.executeQuery();
		 
		status=rs.next();
		
		if(status==true)
		{  
			
		
			System.out.println("Login SuccesFully");
			
			
		}
		else
		{
			System.out.println("Wrong UserName Password OR Create New Account");
			System.out.println("Please Re-Enter:");
			login();
		}
	
	
		
		
		con.close();

	} catch (Exception e) {
		System.out.println(e);
	}

}
	
	public void history()
	{
		try {
			
			PreparedStatement p=null;
			ResultSet rs=null;
			boolean status=false;
			Connection con= DataBaseConnectivy.dbConnection();
			
			String sq="select * from userdata where gmail=?";
			// inserting records
			
			p=con.prepareStatement(sq);
			p.setString(1, this.gmail);
		//	p.setString(2, password);
			rs=p.executeQuery();
			System.out.println("Gmail\t\t Age\t\t Heigh\t\t Weight\t\t ActivityLevel\tBMI\t\t Calorie\t Gender\t"); 
			while(rs.next())
			{
				
				String gmailOut=rs.getString("gmail");
				int ageOut=rs.getInt("age");
				double hOut=rs.getDouble("height");
				double wOut=rs.getDouble("weight");
				int activityOut=rs.getInt("activitylevel");
				double bmiOut=rs.getDouble("bmi");
				double calorieOut=rs.getDouble("calorie");
				String genderOut=rs.getString("gender");
				System.out.println(gmailOut+"\t\t"+ageOut+"\t\t"
				+hOut+"\t\t"+wOut+"\t\t" +activityOut+"\t\t"+bmiOut+"\t\t"+calorieOut+"\t\t"+genderOut);
				
			}
		
			
			
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		
	}
	
	
}

	
