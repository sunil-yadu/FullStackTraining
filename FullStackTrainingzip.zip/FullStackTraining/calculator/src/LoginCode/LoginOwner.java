package LoginCode;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import DBConnection.DataBaseConnectivy;

public class LoginOwner
{
	
	public static void loginOwner(String ownerGmail,String ownerPass) {
		String gmail=ownerGmail;
		String password=ownerPass;

	try {
		
		PreparedStatement p=null;
		ResultSet rs=null;
		boolean status=false;
		
		Connection con= DataBaseConnectivy.dbConnection();
		
		InputStreamReader in = new InputStreamReader(System.in);
	    BufferedReader b = new BufferedReader(in);
		
		System.out.println("Please Enter Your UserName/Gmail: ");
		gmail=b.readLine();
		
		System.out.println("Enter Password: ");
		password=b.readLine();

		String sq="select * from ownerlogin where gmail=? and password=?";
		// inserting records
		
		p=con.prepareStatement(sq);
		p.setString(1, gmail);
		p.setString(2, password);
		rs=p.executeQuery();
		 
		status=rs.next();
		
		if(status==true)
		{
			System.out.println("Login SuccesFully");
			GymInfo.insertGymInfo();
			
		}
		else
		{
			System.out.println("Wrong UserName Password OR Create New Account");
			
		}
	
	
		
		
		con.close();

	} catch (Exception e) {
		System.out.println(e);
	}

}
}