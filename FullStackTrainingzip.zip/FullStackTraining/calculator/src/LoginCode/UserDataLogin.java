package LoginCode;
import java.sql.*;
import java.io.*;
import java.lang.NullPointerException;


public class UserDataLogin {
	public static void main(String args[]) throws Exception
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/calculator";
			String user = "root";
			String pass = "root";
			Connection con = DriverManager.getConnection(url, user, pass);
			
			String name;
			String gmail;
			String password;
			String pWord;
			
			
			InputStreamReader in = new InputStreamReader(System.in);
		    BufferedReader b = new BufferedReader(in);
			
			System.out.println("Please Enter Your Name: ");
			name=b.readLine();
			
			System.out.println("Enter Valid Gmail ID: ");
			gmail=b.readLine();
			
			System.out.println("Enter Password: ");
			password=b.readLine();

			String sq="insert into userlogin values(?,?,?)";
			// inserting records
			
			PreparedStatement stmt1 = con.prepareStatement(sq);
//1 specifies the first parameter in the query  

			stmt1.setString(1, name); 
			stmt1.setString(2, gmail); 
			stmt1.setString(3, password);

			int i = stmt1.executeUpdate();

			System.out.println(i + " records inserted succesfully:");
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	private int executeUpdate() {
		// TODO Auto-generated method stub
		return 0;
	}
}
