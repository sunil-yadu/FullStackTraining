package RagisterCode;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;

import DBConnection.DataBaseConnectivy;
import ValidatePart.Validation;

public class Ragister{
	
	
public static void ragister()
{ 
	
	try {
		Connection con= DataBaseConnectivy.dbConnection();
		 
		
		String name;
		String gmail;
		String password;
		
		
		
		InputStreamReader in = new InputStreamReader(System.in);
	    BufferedReader b = new BufferedReader(in);
		
	    System.out.print("Please Enter Your Name: ");
		name=b.readLine();
		
		System.out.print("Enter Valid Gmail ID: ");
		gmail=b.readLine();
		
		System.out.print("Enter Password: ");
		password=b.readLine();
		
		Validation.validationCheck(name, gmail);
        
		String sq="insert into userlogin values(?,?,?)";
		// inserting records
		
		PreparedStatement stmt1 = con.prepareStatement(sq);
//1 specifies the first parameter in the query  

		stmt1.setString(1, name); 
		stmt1.setString(2, gmail); 
		stmt1.setString(3, password);

		stmt1.executeUpdate();

		System.out.println("Account Created Succesfully:");
		
		con.close();
		
		

	} catch (Exception e) {
		
		System.out.println("Email Already Exist Please Enter Another Mail_ID  "+e);
		ragister();
	}

}

private int executeUpdate() {
	// TODO Auto-generated method stub
	return 0;
}

}

