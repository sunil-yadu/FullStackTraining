package RagisterCode;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;

import DBConnection.DataBaseConnectivy;
import LoginCode.MediLoginOwner;
import ValidatePart.RagisterMediOwnerValidation;

public class RagisterMediOwner{
	
public static void ragisterMediOwner()
{
	try {
		Connection con= DataBaseConnectivy.dbConnection();
		 
		
		String name;
		String gmail;
		String password;
		
		
		
		InputStreamReader in = new InputStreamReader(System.in);
	    BufferedReader b = new BufferedReader(in);
		
	    System.out.print("Please Enter MediCenter Owner Name: ");
		name=b.readLine();
		
		System.out.print("Enter Valid Gmail ID: ");
		gmail=b.readLine();
		
		System.out.print("Enter Password: ");
		password=b.readLine();
		
		RagisterMediOwnerValidation.rmValidationCheck(name, gmail);
        
		String sq="insert into mediownerlogin values(?,?,?)";
		// inserting records
		
		PreparedStatement stmt1 = con.prepareStatement(sq);
//1 specifies the first parameter in the query  

		stmt1.setString(1, name); 
		stmt1.setString(2, gmail); 
		stmt1.setString(3, password);

		stmt1.executeUpdate();

		System.out.println("MediOwner's Account  Created Succesfully:");
		System.out.println("Please Login Here:");
		MediLoginOwner.mediLoginOwner(gmail,password);
		
		con.close();
	 

	} catch (Exception e) {
		System.out.println("Email Already Exist Please Enter Another Mail_ID  "+e);
		ragisterMediOwner();
	}

}



}