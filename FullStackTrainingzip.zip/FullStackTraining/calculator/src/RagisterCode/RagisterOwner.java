package RagisterCode;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;

import DBConnection.DataBaseConnectivy;
import LoginCode.LoginOwner;


public class RagisterOwner{
	
public static void ragisterOwner()
{
	try {
		Connection con= DataBaseConnectivy.dbConnection();
		 
		
		String name;
		String gmail;
		String password;
		
		
		
		InputStreamReader in = new InputStreamReader(System.in);
	    BufferedReader b = new BufferedReader(in);
		
	    System.out.print("Please Enter GYM Owner Name: ");
		name=b.readLine();
		
		System.out.print("Enter Valid Gmail ID: ");
		gmail=b.readLine();
		
		System.out.print("Enter Password: ");
		password=b.readLine();
		
		RagisterOwnerValidation.rValidationCheck(name, gmail);
        
		String sq="insert into ownerlogin values(?,?,?)";
		// inserting records
		
		PreparedStatement stmt1 = con.prepareStatement(sq);
//1 specifies the first parameter in the query  

		stmt1.setString(1, name); 
		stmt1.setString(2, gmail); 
		stmt1.setString(3, password);

		stmt1.executeUpdate();

		System.out.println("GymOwner's Account  Created Succesfully:");
		
		System.out.println("Please Login Here:");
		LoginOwner.loginOwner(gmail,password);
		
		con.close();
	 

	} catch (Exception e) {
		System.out.println("Email Already Exist Please Enter Another Mail_ID  "+e);
		ragisterOwner();
	}

}

private int executeUpdate() {
	// TODO Auto-generated method stub
	return 0;
}

}

