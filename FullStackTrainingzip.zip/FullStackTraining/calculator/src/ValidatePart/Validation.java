package ValidatePart;
import RagisterCode.Ragister;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Validation
{
	public static void validationCheck(String name,String gmail)
	{
		String str=name.toLowerCase();
		String regexCheck="^(.+)@(.+)$"; 
		
		for(int i=0;i<name.length();i++)
		{
			if(!(str.charAt(i)>=97 && str.charAt(i)<=122))
			{   System.out.println("Please Enter Correct Name:");
				Ragister.ragister();
			}
			
		}
		
		ArrayList<String> emails=new ArrayList<String>();
		emails.add(gmail);
		Pattern pattern=Pattern.compile(regexCheck);
		for(String email:emails)
		{
			Matcher matcher =pattern.matcher(email);
			if(!(matcher.matches()))
			{
				System.out.println("You Have Entered Wrong Gmail");
				Ragister.ragister();
			}
		}
	}

	
}






