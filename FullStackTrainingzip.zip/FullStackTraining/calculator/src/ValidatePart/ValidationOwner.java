package ValidatePart;

import RagisterCode.RagisterOwner;

	import java.util.ArrayList;
	import java.util.regex.Matcher;
	import java.util.regex.Pattern;


public class ValidationOwner
	{
		public static void ownerValidationCheck(String name,String gmail)
		{
			String str=name.toLowerCase();
			String regexCheck="^(.+)@(.+)$"; 
			
			for(int i=0;i<name.length();i++)
			{
				if(!(str.charAt(i)>=97 && str.charAt(i)<=122))
				{   System.out.println("Please Enter Correct Name:");
					RagisterOwner.ragisterOwner();
				}
				
			}
			
			ArrayList<String> emails=new ArrayList<String>();
			emails.add(gmail);
			Pattern pattern=Pattern.compile(regexCheck);
			for(String email:emails)
			{
				Matcher matcher =pattern.matcher(email);
				if(!(matcher.matches()))
				{
					System.out.println("You Have Entered Wrong Gmail");
					RagisterOwner.ragisterOwner();
				}
			}
		}

		
	}








