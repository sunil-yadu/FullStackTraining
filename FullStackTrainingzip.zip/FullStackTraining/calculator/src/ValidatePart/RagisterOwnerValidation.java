
package ValidatePart;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import RagisterCode.RagisterOwner;


public class RagisterOwnerValidation
{
	public static void rValidationCheck(String name,String gmail)
	{
		String str=name.toLowerCase();
		String regexCheck="^(.+)@(.+)$"; 
		
		for(int i=0;i<name.length();i++)
		{
			if(!(str.charAt(i)>=97 && str.charAt(i)<=122))
			{   System.out.println("Please Enter Correct Name:");
				RagisterOwner.ragisterOwner();
			}
			
		}
		
		ArrayList<String> emails=new ArrayList<String>();
		emails.add(gmail);
		Pattern pattern=Pattern.compile(regexCheck);
		for(String email:emails)
		{
			Matcher matcher =pattern.matcher(email);
			if(!(matcher.matches()))
			{
				System.out.println("You Have Entered Wrong Gmail");
				RagisterOwner.ragisterOwner();
			}
		}
	}

	
}






