package ValidatePart;
import calculator.GymInfo;


import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class InsertingOwnerDataValidation {
	
	public static void nameValidationCheck(String name)
	{
		String str=name.toLowerCase();
		
		for(int i=0;i<name.length();i++)
		{
			if(!(str.charAt(i)>=97 && str.charAt(i)<=122))
			{   System.out.println("Please Enter Correct Name:");
			    GymInfo.insertGymInfo();
			}
			
		}
	}
	
	public static void gymNameValidationCheck(String gname)
	{
		String str=gname.toLowerCase();
		
		for(int i=0;i<gname.length();i++)
		{
			if(!(str.charAt(i)>=97 && str.charAt(i)<=122))
			{   System.out.println("Please Enter Correct GymName:");
			    GymInfo.insertGymInfo();
			}
			
		}
	}
	
	public static void isValidContact(String contact)
	{
		Pattern ptr1=Pattern.compile("(0/91)?[7-9][0-9]{9}");
		Matcher match=ptr1.matcher(contact);
		if(!(match.find()&&match.group().equals(contact)))
		{   System.out.println("Please Enter Correct Contact Number:");
			GymInfo.insertGymInfo();
		}
		
	}
	
	public static void validAddress(String address)
	{
		String str=address.toLowerCase();
		
		for(int i=0;i<address.length();i++)
		{
			if(!(str.charAt(i)>=97 && str.charAt(i)<=122))
			{   System.out.println("Please Enter Correct GymName:");
			    GymInfo.insertGymInfo();
			}
			
		}
	}
	
	public static void feesValidation(String fees)
	{
		
		
		String regex="[+-]?[0-9]+";
		Pattern ptr2=Pattern.compile(regex);
		Matcher m=ptr2.matcher(fees);
		if(!(m.find() && m.group().equals(fees)))
		{ 
	     System.out.println("Please Enter Rate In Integer:");
		 GymInfo.insertGymInfo();	
		}
		
	}
		
	public static void openTimeValidate(String openTime)
	{
		String time12Hours="(1[012]|[1-9]):[0-5][0-9](\\s)?(?i)(am|pm)";
		Pattern pt=Pattern.compile(time12Hours);
		Matcher match=pt.matcher(openTime);
		if(!(match.matches()))
		{
			System.out.println("Enter Valid Open Time Formate:");
			GymInfo.insertGymInfo();
		}
	}
	public static void closeTimeValidate(String closeTime)
	{
		String time12Hours="(1[012]|[1-9]):[0-5][0-9](\\s)?(?i)(am|pm)";
		Pattern pt=Pattern.compile(time12Hours);
		Matcher match=pt.matcher(closeTime);
		if(!(match.matches()))
		{
			System.out.println("Enter Valid closing Time Formate:");
			GymInfo.insertGymInfo();
		}
	}
	
	
	public static void gmailValidation(String gmail)
	{
		String regexCheck="^(.+)@(.+)$";
		ArrayList<String> emails=new ArrayList<String>();
		emails.add(gmail);
		Pattern pattern=Pattern.compile(regexCheck);
		for(String email:emails)
		{
			Matcher matcher =pattern.matcher(email);
			if(!(matcher.matches()))
			{
				System.out.println("You Have Entered Wrong Gmail");
				GymInfo.insertGymInfo();
			}
		}
	}
	
	String oName;
	String oGymName;
	String contact;
	String address;
	String fees;
	String openTime;
	String closeTime;
	String oGmail;

}
