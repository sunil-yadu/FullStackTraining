package ValidatePart;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import calculator.Main;

public class BMIValidation extends Main{

	public static void bmiValidationCheck(String gmail)
	{  
		Main m=new Main();
		
		String regexCheck="^(.+)@(.+)$"; 
		
		
		ArrayList<String> emails=new ArrayList<String>();
		emails.add(gmail);
		Pattern pattern=Pattern.compile(regexCheck);
		for(String email:emails)
		{
			Matcher matcher =pattern.matcher(email);
			if(!(matcher.matches()))
			{
				System.out.println("You Have Entered Wrong Gmail");
				m.currentCalorie();
			}
		}
	}

	
}




