
package calculator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import RagisterCode.RagisterMediOwner;
import RagisterCode.RagisterOwner;

import java.sql.*;
import java.io.*;
import java.lang.NullPointerException;


public class ConsoleOut extends Main {
	
	
	public static void fighter() {
	Fighter f=new Fighter();
	
	System.out.println("Welcome To Raastrang Fitness Center..");
	System.out.println("Press 1 If You are Gym Owner or MediOwner.. Press 2 If You are Fighter.");
	Scanner sc4=new Scanner(System.in);
	int selectOption=sc4.nextInt();
	if(selectOption==1)
	{
		System.out.println("Press 1 GYM Owner.. Press 2 MediOwner..");
		Scanner sc5=new Scanner(System.in);
		int sOptionCheck=sc5.nextInt();
		if(sOptionCheck==1)
		{
		RagisterOwner.ragisterOwner();
		}
		else if(sOptionCheck==2)
		{
			RagisterMediOwner.ragisterMediOwner();
		}
	}
	else if(selectOption==2)
	{
		f.fighterFunctions();
	}
	else
	{
		System.out.println("Please Select Right Option:");
		fighter();
	}
	
	}
	
	
	public static void main(String[] args) throws Exception
	{
	
		
		fighter();
		
	}
}

