package calculator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Iterator;


	
public class Gym{
			
	public static void gymData()
		{
		GymInfo gi=new GymInfo();
	/*
		Map<Integer,String> gymName=new HashMap<Integer,String>();
		gymName.put(1,"Hydra");
		gymName.put(2,"Physics&Figure");
		
		Map<Integer,String> mediCenter=new HashMap<Integer,String>();
		mediCenter.put(1,"Divin_YogaCenter");
		mediCenter.put(2,"Third_Eyes_YogaCenter");
		
		Set s1=gymName.entrySet();
		Iterator itr1=s1.iterator();
		
		Set s2=mediCenter.entrySet();
		Iterator itr2=s2.iterator();
		
		*/
		
		System.out.println("Are you worry about your health?");
		System.out.println("Press 1_Yes 2_No:");
		Scanner sc2=new Scanner(System.in);
		int wOption=sc2.nextInt();
		if(wOption==1)
		{
			
			System.out.println("what would you prefare?");
			System.out.println("Press 1_GYM Info 2_Meditation Center Info:");
			Scanner sc3=new Scanner(System.in);
			int pOption=sc3.nextInt();
			
			if(pOption==1)
			{
				/*
				while(itr1.hasNext())
				{
					Map.Entry e1=(Map.Entry)itr1.next();
					System.out.print(e1.getKey()+" "+e1.getValue()+"\t\t");
				}
				System.out.println();
				System.out.println();
				*/
				
				
				
				
				gi.gymInfo();
				
				
			}
			else if(pOption==2)
			{
				GymInfo.mediInfo();
				/*
				while(itr2.hasNext())
				{
					Map.Entry e2=(Map.Entry)itr2.next();
					System.out.print(e2.getKey()+" "+e2.getValue()+"\t\t");
				}*/
			}
			else
			{
				System.out.println("Please Choose Right Option:");
				gymData();
			}
			
		}
		else
		{
			System.out.println("God Bless You Dear..");
		}
		
		}
		
		
	}








