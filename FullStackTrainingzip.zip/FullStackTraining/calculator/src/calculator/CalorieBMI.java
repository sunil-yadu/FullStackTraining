
package calculator;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.*;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.sql.*;
import java.io.*;
import java.lang.NullPointerException;
import calculator.Info;

public class CalorieBMI implements Info {
	DecimalFormat df = new DecimalFormat("0.00");

	double fat;
	
	int age;
	String gender;
	double height;
	double weight;
	int activity;
	double calculate;
	double bmrM;
	double bmrF;
	static double outCal;
	static double outBMI;



	/*
	 * public void setName(String pName) { name=pName; }
	 */ // Setter Getter for Encapsulation part
	public void setAge(int pAge) {
		age = pAge;
	}

	public void setGender(String pGender) {
		gender = pGender;
	}

	public void setHeight(double pHeight) {
		height = pHeight;
	}

	public void setWeight(double pWeight) {
		weight = pWeight;
	}

	public void setActivity(int pActivity) {
		activity = pActivity;
	}

	/*
	 * public String getName() { return name; }
	 */
	public int getAge() {
		return age;
	}

	public String getGender() {
		return gender;
	}

	public double getHeight() {
		return height;
	}

	public double getWeight() {
		return weight;
	}

	public int getActivity() {
		return activity;
	}
	

	

//To calculate BMR For Male bcz it is needed in calorie formula to find exact need.
	public double setBmrMale(double pWeight, double pHeight, int pAge) {

		this.bmrM = 10 * pWeight + 6.25 * pHeight - 5 * pAge + 5;
		// System.out.println("Bmr for Male is: " +bmrM);
		return bmrM;

	}
//To calculate BMR For Female to find exact need

	public double setBmrFemale(double pWeight, double pHeight, int pAge) {

		this.bmrF = 10 * pWeight + 6.25 * pHeight - 5 * pAge - 161;
		// System.out.println("Bmr for FeMale is: " +bmrF);
		return bmrF;

	}
	

//To display entered Information...

	public void display() {
	
		// System.out.println("Entered Name is :"+name);
		System.out.println("Entered age is :" + age);

		System.out.println("Gender is:" + gender);

		System.out.println("Entered Height is :" + height);
		System.out.println("Entered Weight is:" + weight);
		System.out.println("Entered activity is :" + activity);
		//System.out.println("BmrM is :" + bmrM);
		//System.out.println("BmrF is :" + bmrF);
		// System.out.println("Fat is :"+fat);
		

	}

	// To calculate Final need for active person..
	public void needCalorieActive() {
		// System.out.println("Calorie Need For Active Male:="+bmrM*1.375);
		this.outCal=bmrM*1.375;
		System.out.println(" KiloCalorie Need For Active Male:="+df.format(outCal));

	}

	//// To calculate Final need for Moderate person..
	public void needCalorieModerate() {
		// System.out.println("Calorie Need For Moderate Male:="+bmrM*1.5);
		this.outCal=bmrM*1.5;
		System.out.println(" KiloCalorie Need For Moderate Male:="+df.format(outCal));

	}

	// To calculate Final need for Hard person..
	public void needCalorieHard() {
		// System.out.println("Calorie Need For Hard Male:="+bmrM*1.7);
		this.outCal=bmrM*1.7;
		System.out.println(" KiloCalorie Need For Hard Male:="+df.format(outCal));

	}

	// To calculate Final need for active Female ..
	public void needCalorieActiveFemale() {
		// System.out.println("Calorie Need For Active Female :="+bmrF*1.375);
		this.outCal=bmrF*1.375;
		System.out.println(" KiloCalorie Need For Active Female:="+df.format(outCal));

	}

	// To calculate Final need for Moderate Female..
	public void needCalorieModerateFemale() {
		// System.out.println("Calorie Need For Moderate Female:="+bmrF*1.5);
		this.outCal=bmrF*1.5;
		
		System.out.println(" KiloCalorie Need For Moderate Female:="+df.format(outCal));
	}

	// To calculate Final need for Hard Female..
	public void needCalorieHardFemale() {
		// System.out.println("Calorie Need For Hard Female:="+bmrF*1.7);
		this.outCal=bmrF*1.7;
		System.out.println(" KiloCalorie Need For Hard Female:="+df.format(outCal));
	

	}
public double setFat(double pWeight,double pHeight )
{
	this.outBMI=pWeight/pHeight/pHeight*10000;
	return outBMI;
}
public void bmiCal() {
		
		
		if (outBMI <= 18.5) { 
			System.out.println("You are Thin.&BMI is= " + df.format(outBMI));
					
		} else if (outBMI > 18.5 && fat < 24.9) { 
			System.out.println("You are Fit.&BMI is= " + df.format(outBMI));
			

		} else {
			
			
			System.out.println("You are Fatty.&BMI is= " + df.format(outBMI));
		}

	}

@Override
public void setAge() {
	// TODO Auto-generated method stub
	
}

@Override
public void setGender() {
	// TODO Auto-generated method stub
	
}

@Override
public void setHeight() {
	// TODO Auto-generated method stub
	
}

@Override
public void setWeight() {
	// TODO Auto-generated method stub
	
}

@Override
public void setActivity() {
	// TODO Auto-generated method stub
	
}


@Override
public void jOption() {
	// TODO Auto-generated method stub
	
}

}

