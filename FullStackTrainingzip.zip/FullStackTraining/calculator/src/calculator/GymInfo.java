package calculator;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import DBConnection.DataBaseConnectivy;
import ValidatePart.InsertingMediOwnerDataValidation;
import ValidatePart.InsertingOwnerDataValidation;

public class GymInfo {
	
public static void insertGymInfo()
	{
		try {
			Connection con= DataBaseConnectivy.dbConnection();
			 
			
			String oName;
			String oGymName;
			String contact;
			String address;
			String fees;
			String openTime;
			String closeTime;
			String oGmail;
	
			
			
			InputStreamReader in = new InputStreamReader(System.in);
		    BufferedReader b = new BufferedReader(in);
			
		    System.out.print("Please Enter Your Name: ");
			oName=b.readLine();
			System.out.print("Please Enter Your Email_ID: ");
			oGmail=b.readLine();
			
			System.out.print("Enter GymName: ");
			oGymName=b.readLine();
			
			System.out.print("Enter Contact Number: ");
			contact=b.readLine();
			
			System.out.print("Please Enter Address Of GYM:");
			address=b.readLine();
			
			System.out.print("Enter Fees Per Head: ");
			fees=b.readLine();
			
			System.out.print("Enter Opening Time (Time Formate Most be 9:30 am/pm) : ");
			openTime=b.readLine();
			
			System.out.print("Enter Closing Time: (Time Formate Most be 9:30 am/pm) : ");
			closeTime=b.readLine();
			
			
			InsertingOwnerDataValidation.nameValidationCheck(oName);
			InsertingOwnerDataValidation.gymNameValidationCheck(oGymName);
			InsertingOwnerDataValidation.isValidContact(contact);
			InsertingOwnerDataValidation.validAddress(address);
			InsertingOwnerDataValidation.openTimeValidate(openTime);
			InsertingOwnerDataValidation.feesValidation(fees);
			InsertingOwnerDataValidation.closeTimeValidate(closeTime);
			InsertingOwnerDataValidation.gmailValidation(oGmail);
	        
			String sq="insert into gyminfo values(?,?,?,?,?,?,?,?)";
			// inserting records
			
			PreparedStatement stmt1 = con.prepareStatement(sq);
	//1 specifies the first parameter in the query  

			stmt1.setString(1, oName); 
			stmt1.setString(2, oGymName); 
			stmt1.setString(3, contact);
			stmt1.setString(4, address); 
			stmt1.setString(5, fees); 
			stmt1.setString(6, openTime);
			stmt1.setString(7, closeTime);
			stmt1.setString(8, oGmail);
		
			
			
			


			stmt1.executeUpdate();
			

			System.out.println("GYM Info Inserted Succesfully:");
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}

public static void insertMediInfo()
{
	try {
		Connection con= DataBaseConnectivy.dbConnection();
		 
		
		String oName;
		String oGymName;
		String contact;
		String address;
		String fees;
		String openTime;
		String closeTime;
		String oGmail;
	
		
		
		InputStreamReader in = new InputStreamReader(System.in);
	    BufferedReader b = new BufferedReader(in);
		
	    System.out.print("Please Enter Your Name: ");
		oName=b.readLine();
		
		System.out.print("Please Enter Your Email_Id: ");
		oGmail=b.readLine();
		
		System.out.print("Enter MediCenterName: ");
		oGymName=b.readLine();
		
		System.out.print("Enter Contact Number: ");
		contact=b.readLine();
		
		System.out.print("Please Enter Address Of MediCenter: ");
		address=b.readLine();
		
		System.out.print("Enter Fees Per Head: ");
		fees=b.readLine();
		
		System.out.print("Enter Opening Time: (Time Formate Most be 9:30 am/pm) ");
		openTime=b.readLine();
		System.out.print("Enter Closing Time:  (Time Formate Most be 9:30 am/pm)");
		closeTime=b.readLine();
		
		
		InsertingMediOwnerDataValidation.nameValidationCheck(oName);
		InsertingMediOwnerDataValidation.gymNameValidationCheck(oGymName);
		InsertingMediOwnerDataValidation.isValidContact(contact);
		InsertingMediOwnerDataValidation.validAddress(address);
		InsertingMediOwnerDataValidation.openTimeValidate(openTime);
		InsertingMediOwnerDataValidation.feesValidation(fees);
		InsertingMediOwnerDataValidation.closeTimeValidate(closeTime);
		InsertingMediOwnerDataValidation.gmailValidation(oGmail);
        
		String sq="insert into mediinfo values(?,?,?,?,?,?,?,?)";
		// inserting records
		
		PreparedStatement stmt1 = con.prepareStatement(sq);
//1 specifies the first parameter in the query  

		stmt1.setString(1, oName); 
		stmt1.setString(2, oGymName); 
		stmt1.setString(3, contact);
		stmt1.setString(4, address); 
		stmt1.setString(5, fees); 
		stmt1.setString(6, openTime);
		stmt1.setString(7, closeTime);
		stmt1.setString(8, oGmail);
		
		
		
		


		stmt1.executeUpdate();
		

		System.out.println("Meditation Center Info Inserted Succesfully:");
		con.close();

	} catch (Exception e) {
		System.out.println(e);
	}

}

public void gymInfo()
{

		try {
			
			PreparedStatement p=null;
			ResultSet rs=null;
			boolean status=false;
			
			Connection con= DataBaseConnectivy.dbConnection();
			
			InputStreamReader in = new InputStreamReader(System.in);
		    BufferedReader b = new BufferedReader(in);
			
			String sq="select * from gyminfo";
			
			p=con.prepareStatement(sq);
			
			rs=p.executeQuery();
			System.out.println("OwnerName\t\t GYMCenterName\t\t Contact\t\t Address\t\t Fees\t\t OpeningTime\t\t ClosingTime\t\tEmail");
			 
			while(rs.next())
			{
			String oName=rs.getString("ownername");
			String gName=rs.getString("gymname");
			String cContact=rs.getString("contact");
			String aAddress=rs.getString("address");
			String fFees=rs.getString("fees");
			String oOpentime=rs.getString("opentime");
			String cClosetime=rs.getString("closetime");
			String gGmail=rs.getString("gmail");
		
			System.out.println(oName+"\t\t" +gName+"\t\t"+cContact+"\t\t"
					+aAddress+"\t\t"+fFees+"\t\t"+oOpentime+"\t\t"+cClosetime+"\t\t"+gGmail);
				
				
			}
		
			
			
			con.close();

		} catch (Exception e) {
			System.out.println("Hello");
			System.out.println(e);
		}
		
	}

public static void mediInfo()
{

		try {
			
			PreparedStatement p=null;
			ResultSet rs=null;
			
			Connection con= DataBaseConnectivy.dbConnection();
			
			
			String sq="select * from mediinfo";
			
			p=con.prepareStatement(sq);
			
			rs=p.executeQuery();
			System.out.println("OwnerName\t\t MediCenterName\t\t Contact\t\t Address\t\t Fees\t\t OpeningTime\t\t ClosingTime\t\tGmail");
			 
			while(rs.next())
			{
			String oName=rs.getString("ownername");
			String gName=rs.getString("mediname");
			String cContact=rs.getString("contact");
			String aAddress=rs.getString("address");
			String fFees=rs.getString("fees");
			String oOpentime=rs.getString("opentime");
			String cClosetime=rs.getString("closetime");
			String gGmail=rs.getString("gmail");
			System.out.println(oName+"\t\t" +gName+"\t\t"+cContact+"\t\t"
					+aAddress+"\t\t"+fFees+"\t\t" +oOpentime+"\t\t"+cClosetime+"\t\t"+gGmail);
				
				
			}
		
			
			
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		
	}


}

