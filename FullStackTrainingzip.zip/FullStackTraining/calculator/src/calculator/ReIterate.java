package calculator;

import java.util.Scanner;

public class ReIterate {

	public static void reiterate()
	{
		System.out.println("Login");
		Scanner sc=new Scanner(System.in);
		try {
		int input=sc.nextInt();
		
		}catch(Exception e)
		{
			System.out.println("Wrong input  "+e);
			reiterate();
		}
	}
	

	public static void main(String[] args) {
		reiterate();
		
	}
}
