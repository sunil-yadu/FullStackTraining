package calculator;

public interface Info {
	
abstract void setAge();
abstract void setGender();
abstract void setHeight();
abstract void setWeight();
abstract void setActivity();
abstract int getAge();
abstract String getGender();
abstract double getHeight();
abstract double getWeight();
abstract double getActivity();
abstract void bmiCal();
abstract void display();
abstract void jOption();



}
