package calculator;
import java.util.Scanner;

import DBConnection.DataBaseConnectivy;
import ValidatePart.BMIValidation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;

public class Main extends CalorieBMI {
	
 public void dataPass(String gmail,int ag,double h,double w,int a,double outBMI,double outCal,String g)
	{
		{
		
			
			try {
				Connection con= DataBaseConnectivy.dbConnection();
				

				String sq="insert into userdata values(?,?,?,?,?,?,?,?)";
				// inserting records
				
				PreparedStatement stmt1 = con.prepareStatement(sq);
		//1 specifies the first parameter in the query  

				
				stmt1.setString(1, gmail); 
				stmt1.setInt(2, ag);
				stmt1.setDouble(3,h);
				stmt1.setDouble(4,w);
				stmt1.setInt(5,a);
				stmt1.setDouble(6,outBMI);						
				stmt1.setDouble(7,outCal);
				stmt1.setString(8,g);
				

				int i = stmt1.executeUpdate();

				System.out.println(i + " records inserted succesfully:");
				con.close();

			} catch (Exception e) {
				System.out.println(e);
			}

		}
		
		
	
	}
	
 
    public void currentCalorie() {
	//public static void main(String args[]) throws IOException
	// Concept of AbstractAction that user only entering info and he/she is getting
	// desired output
	try{
		
		// Class Object & Inheritance
		
		CalorieBMI f = new CalorieBMI();
		InputStreamReader in = new InputStreamReader(System.in);
	    BufferedReader b = new BufferedReader(in);
		
		
		System.out.println("Enter your Gmail:");
		String gmail=b.readLine();
        BMIValidation.bmiValidationCheck(gmail);
        
		System.out.println("Enter your activity level");
		System.out.println("1_Active: 2_Moderate: 3_Hard");

		Scanner choice = new Scanner(System.in);
	    int a = choice.nextInt();
	    if(a==1 ||a== 2 ||a==3)
	    {
	    	System.out.println("Enter Age");
			Scanner age1 = new Scanner(System.in);
			int ag = age1.nextInt();
			if(ag>0 && ag<=100)
			{
				System.out.println("Enter Gender: 1_Male 2_Female ");
				Scanner gender1 = new Scanner(System.in);
				String g = gender1.next();
				String g1="Male";
				String g2="Female";
				if(g.equalsIgnoreCase(g1) || g.equalsIgnoreCase(g2))
				{
					System.out.println("Enter Height in CM: ");
					Scanner height1 = new Scanner(System.in);
					double h = height1.nextDouble();
					if(h>1 && h<=200.00)
					{
						System.out.println("Enter Weight in KG: ");
						Scanner weight1 = new Scanner(System.in);
						double w = weight1.nextDouble();
						if(w>1 && w<=150)
						{
							if (a == 1) {
								// Conditional Statements
								switch (g) {
								case "male": {
									// System.out.println("Active");
									f.setBmrMale(w, h, ag);
									f.setFat(w,h);
									
									f.needCalorieActive();
									f.bmiCal();
									
									// f.display();
									break;

								}
								case "female": {
									// System.out.println("Moderate");
								   	f.setBmrFemale(w, h, ag);
								   	f.setFat(w,h);
									
									f.needCalorieActiveFemale();
				  					f.bmiCal();   
									
									// f.display();
									break;
								}   

								default: {
									System.out.println("Please select right option");
									currentCalorie();
								}
								}
							} else if (a == 2) {
								switch (g) {
								case "male": {
									// System.out.println("Active");
									f.setBmrMale(w, h, ag);
									f.setFat(w,h);
									
									f.needCalorieModerate();
									f.bmiCal();
									
									// f.display();
									break;

								}
								case "female": {
									// System.out.println("Moderate");
									f.setBmrFemale(w, h, ag);
									f.setFat(w,h);
								
									f.needCalorieModerateFemale();
									f.bmiCal();
									
									// f.display();
									break;
								}

								default: {
									System.out.println("Please select right option");
									currentCalorie();
								}
								}

							} else if (a == 3) {
								switch (g) {
								case "male": {
									// System.out.println("Active");
									f.setBmrMale(w, h, ag);
									f.setFat(w,h);
								
									f.needCalorieHard();
									f.bmiCal();
									// f.display();
									break;

								}
								case "female": {
									// System.out.println("Moderate");
									f.setBmrFemale(w, h, ag);
									f.setFat(w,h);
									
									f.needCalorieHardFemale();
									f.bmiCal();
									// f.display();
									break;
								}

								default: {
									System.out.println("Please select right option");
									currentCalorie();
								}
								}
							}

							f.setActivity(a);
							// f.setName(n);
							f.setAge(ag);
							f.setGender(g);
							f.setHeight(h);
							f.setWeight(w);
							// f.display();
							
							Main m1=new Main();
							m1.dataPass(gmail, ag, h, w, a, outBMI, outCal, g);
							
							
							
							
							System.out.println("Want to see Entered Info ?:");
							System.out.println("Press: 1: Yes 2: No");
							
							Scanner sOption=new Scanner(System.in);
							
							int press = sOption.nextInt();
							if(press==1)
							{
								System.out.println();
								f.display();		}
							else
							{
								System.out.println("Have a Good Day:");
							}

									
							System.exit(0);
						}
						else
						{
							System.out.println("Enter Weight Between 1-150");
							currentCalorie();
						}
					}
					else {
						System.out.println("Please Enter Height Between 100-200 Cm:");
						currentCalorie();
					}
					
				}
				else
				{
					System.out.println("Please Enter Correct Gender:");
					currentCalorie();
				}

			}
			
			else
			{
				System.out.println("Please Enter Age Between 1-100:");
				currentCalorie();
			}
	    }
	    else
	    {
	    	System.out.println("Please Enter right choice");
	    	currentCalorie();
	    }
		
		
		
		

	}
	catch(IOException i)
	{
		System.out.println(i);
	}

	
    }
}

