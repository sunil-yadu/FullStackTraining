package calculator;

import java.util.Scanner;

import LoginCode.Login;
import RagisterCode.Ragister;

class Fighter
{
	Main m1=new Main();
	Ragister r=new Ragister();
	Login l=new Login();
	
public void reSelectOption()
{
	System.out.println("Select Option:");
	System.out.println("1_Wants To see Previous Data? 2_Wants To Calculate Current Calorie&BMI? 3_Wants to get Info of NearGym/MediCenter");
	Scanner sc1=new Scanner(System.in);
	int sOption=sc1.nextInt();
	if(sOption==1)
	{
		l.history();
		
	}
	else if(sOption==2)
	{
	  m1.currentCalorie();
	}
	else if(sOption==3)
	{   System.out.println("Press 1 For GYM Info.. Press 2 For MediCenter Info..");
	   Scanner sc6=new Scanner(System.in);
	   int pOption3=sc6.nextInt();
	   if(pOption3==1)
	   {
		Gym.gymData();
	   }
	   else if(pOption3==2)
	   {
		   GymInfo.mediInfo();
	   }
	}
	else
	{
		System.out.println("Please Select Right Option:");
	}
	

}

	
	
	public void fighterFunctions()
	{

		System.out.println("Please Select Option:");
		System.out.println("1_Login: 2_NewUser:");
		
		Scanner sc=new Scanner(System.in);
		int option=sc.nextInt();
		if(option==1)
		{
			System.out.println("Welcome To The FItness World:");
			l.login();
			System.out.println("Select Option:");
			System.out.println("1_Wants To see Previous Data? 2_Wants To Calculate Current Calorie&BMI? 3_Wants to get Info of NearGym/MediCenter");
			Scanner sc1=new Scanner(System.in);
			int sOption=sc1.nextInt();
			if(sOption==1)
			{
				l.history();
				reSelectOption();
				
			}
			else if(sOption==2)
			{
			  m1.currentCalorie();
			  reSelectOption();
			}
			else if(sOption==3)
			{  
			   System.out.println("Press 1 For GYM Info.. Press 2 For MediCenter Info..");
			   Scanner sc6=new Scanner(System.in);
			   int pOption3=sc6.nextInt();
			   if(pOption3==1)
			   {
				Gym.gymData();
			   }
			   else if(pOption3==2)
			   {
				   GymInfo.mediInfo();
			   }
			}
			else
			{
				System.out.println("Please Select Right Option:");
				 m1.currentCalorie();
			}
			
		}
		else if(option==2)
		{
			System.out.println("Hii Upcoming Fighter:");
			Ragister.ragister();
			
			
		}
		else
		{
			System.out.println("Please Select Right Option:");
		}
	}
}
