package DBConnection;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DataBaseConnectivy {
	private static Connection con;
	public static Connection dbConnection() 
	{
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/calculator";
		String user = "root";
		String pass = "root";
	    con = DriverManager.getConnection(url, user, pass);
		
	} catch (Exception e) {
		System.out.println(e);
	}
     return con;
}
}

