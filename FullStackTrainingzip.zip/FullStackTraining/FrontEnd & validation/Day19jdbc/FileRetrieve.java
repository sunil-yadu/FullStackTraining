import java.sql.*; 
import java.io.*;
class FileRetrieve{  
public static void main(String args[]){  
try{  
	Class.forName("com.mysql.jdbc.Driver");
	String url="jdbc:mysql://localhost:3306/employee";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	
	//Retrieve file
   String sq="select * from textfile";
   PreparedStatement stmt1=con.prepareStatement(sq); 
   ResultSet rs=stmt1.executeQuery();
   rs.next();
   Clob t=rs.getClob(2);
   Reader r=t.getCharacterStream();
   FileWriter fw=new FileWriter("d:\\retrivefile.txt");  
              
     int i;  
    while((i=r.read())!=-1)  
    fw.write((char)i);  
              
    fw.close();  
   
   
   

   System.out.println( "File Retrieve SuccesFully");
   con.close();  
  
}catch(Exception e){ System.out.println(e);}  
  
}

private int executeUpdate() {
	// TODO Auto-generated method stub
	return 0;
}  
}  