import java.sql.*; 
import java.io.*;
class FileInsert{  
public static void main(String args[]){  
try{  
	Class.forName("com.mysql.jdbc.Driver");
	String url="jdbc:mysql://localhost:3306/employee";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	
	//insert file
   String sq="insert into textfile values(?,?)";
   PreparedStatement stmt1=con.prepareStatement(sq); 
   
   File f=new File("D:/yash.txt");
   FileReader fr=new FileReader(f);
   stmt1.setString(1,"Sunil");
   stmt1.setCharacterStream(2,fr,(int)f.length());
   int i=stmt1.executeUpdate();
   

   System.out.println( "File Inserted SuccesFully");
   con.close();  
  
}catch(Exception e){ System.out.println(e);}  
  
}

private int executeUpdate() {
	// TODO Auto-generated method stub
	return 0;
}  
}  