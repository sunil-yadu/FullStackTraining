import java.sql.*;
class DataConnectivity
{
	public static void  main(String args[])
	{
		try
		{
			//Class.forName("com.mysql.jdbc.Driver");//Old One
			Class.forName("com.mysql.cj.jdbc.Driver");//connection java newone
			//String url="jdbc:mysql://localhost:3306/employee"; //all valid
			//String url="jdbc:mysql://localhost/employee";
			String url="jdbc:mysql://127.0.0.1/employee";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("connection created succesfully");
				
			}
			else
			{
				System.out.println("Connection is not Created");
			}
			/*
			String insert="insert into employee1 values(102,'yadu')";
			Statement stInsert=con.createStatement();
			stInsert.executeUpdate(insert);
			System.out.println("Inserting value in employee1 table");*/
			/*
			String delete="delete from employee1 WHERE empID = 102";
			Statement stDelete=con.createStatement();
			stDelete.executeUpdate(delete);*/
			
			
			String q="select * from employee1";
			Statement st=con.createStatement();
			ResultSet set=st.executeQuery(q);
			while(set.next())
			{  // int id=set.getInt(1); 1 stands for column number
		      //String name=set.getString(2); name is in second column
				int id=set.getInt("empId");//("empID");
				String name=set.getString("name");
				System.out.println("id:"+id);
				System.out.println("Name:"+name);
				
			}
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}