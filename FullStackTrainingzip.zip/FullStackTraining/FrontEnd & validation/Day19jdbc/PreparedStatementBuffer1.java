import java.sql.*; 
import java.io.*;
class PreparedStatementBuffer1{  
public static void main(String args[]){  
try{  
	Class.forName("com.mysql.jdbc.Driver");
	String url="jdbc:mysql://localhost:3306/employee";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	

	InputStreamReader in = new InputStreamReader(System.in);
    BufferedReader b = new BufferedReader(in);
	
	System.out.println("Enter empId");
	int empId=Integer.parseInt(b.readLine());
	
	System.out.println("Enter name");
	String name1=b.readLine();
	
	//Updating records
   String sq="update employee1 set name = ? where empID = ?";
   PreparedStatement stmt1=con.prepareStatement(sq); 
//1 specifies the first parameter in the query  

   stmt1.setInt(2,empId); //pass 2? mark
   stmt1.setString(1,name1); //? sequence of question mark  pass value for first ? mark

   int i=stmt1.executeUpdate();  

   System.out.println(i+" records Updated");
   con.close();  
  
}catch(Exception e){ System.out.println(e);}  
  
}

private int executeUpdate() {
	// TODO Auto-generated method stub
	return 0;
}  
}  