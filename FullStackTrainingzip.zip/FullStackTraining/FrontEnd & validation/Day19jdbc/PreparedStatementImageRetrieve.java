import java.sql.*; 
import java.io.*;
class PreparedStatementImageRetrieve{  
public static void main(String args[]){  
try{  
	Class.forName("com.mysql.jdbc.Driver");
	String url="jdbc:mysql://localhost:3306/employee";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	
	//Retrieve image
   String sq="select * from imageinsert";
   PreparedStatement stmt1=con.prepareStatement(sq); 
    ResultSet rs=stmt1.executeQuery();
	if(rs.next())
	{
		Blob b=rs.getBlob(2);
		byte arr[] = b.getBytes(1,(int)b.length());
		FileOutputStream fout=new FileOutputStream("d:/thorFatyy.jpg"); //Name of file of retrieving data from sql.
		fout.write(arr);
		fout.close();
	}
   
   
   
   

   System.out.println( "Image Retrieved SuccesFully");
   con.close();  
  
}catch(Exception e){ System.out.println(e);}  
  
}

}  