import java.sql.*; 
import java.io.*;
class PreparedStatementImageInserting{  
public static void main(String args[]){  
try{  
	Class.forName("com.mysql.jdbc.Driver");
	String url="jdbc:mysql://localhost:3306/employee";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	
	//inserting image
   String sq="insert into imageInsert values(?,?)";
   PreparedStatement stmt1=con.prepareStatement(sq); 
    stmt1.setString(1,"name");
   
   FileInputStream f1=new FileInputStream("D:/fat.jpg"); //if img size is larg than in sql the image column size should be change from blob to long blob.
   stmt1.setBinaryStream(2,f1,f1.available());
   
   int i=stmt1.executeUpdate();  

   System.out.println(i+" Image inserted SuccesFully");
   con.close();  
  
}catch(Exception e){ System.out.println(e);}  
  
}

private int executeUpdate() {
	// TODO Auto-generated method stub
	return 0;
}  
}  