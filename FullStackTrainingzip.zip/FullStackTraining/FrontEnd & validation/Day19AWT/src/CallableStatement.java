import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager; 
class CallableStatement{  
public static void main(String args[]){  
try{  
	Class.forName("com.mysql.jdbc.Driver");
	String url="jdbc:mysql://localhost:3306/employee";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	java.sql.CallableStatement stmt=con.prepareCall("{call employee1(?,?)}");  
	stmt.setInt(1,1011);  
	stmt.setString(2,"Amit");  
	stmt.execute();  
	  
	System.out.println("success");  
	con.close();
}
catch(Exception e)
{
	e.printStackTrace();
}
}

private void execute() {
	// TODO Auto-generated method stub
	
}

private void setString(int i, String string) {
	// TODO Auto-generated method stub
	
}

private void setInt(int i, int j) {
	// TODO Auto-generated method stub
	
}
}
