import java.sql.*; 
class PreparedStatement{  
public static void main(String args[]){  
try{  
	Class.forName("com.mysql.jdbc.Driver");
	String url="jdbc:mysql://localhost:3306/employee";
	String user="root";
	String pass="root";
	Connection con=DriverManager.getConnection(url,user,pass);
	//insert record using preparedstatement
/*java.sql.PreparedStatement stmt=con.prepareStatement("insert into employee1 values(?,?)"); 
stmt.setInt(1,103);//1 specifies the first parameter in the query  
stmt.setString(2,"Radhe"); 
int i=stmt.executeUpdate();  

System.out.println(i+" records inserted"); */
	//Deleting record using prepared statement
/*
java.sql.PreparedStatement stmt1=con.prepareStatement("delete from employee1 where empId=?");  
stmt1.setInt(1,101);  

int i1=stmt1.executeUpdate();  
System.out.println(i1+" records deleted");  
*/

	java.sql.PreparedStatement stmt=con.prepareStatement("select * from employee1"); 
	ResultSet rs=stmt.executeQuery();
	ResultSetMetaData rsmd=rs.getMetaData();
	System.out.println("Total Colums:"+rsmd.getColumnCount());
	System.out.println("Column Name of 1st column:"+rsmd.getColumnName(1));
	System.out.println("Column Type Name of 1st column:"+rsmd.getColumnTypeName(1));
	
con.close();  
  
}catch(Exception e){ System.out.println(e);}  
  
}

private int executeUpdate() {
	// TODO Auto-generated method stub
	return 0;
}  
}  