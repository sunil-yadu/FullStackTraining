import javax.swing.*; 

class SwingDemo  
{  
public static void main(String args[])  
    {  
    JFrame f= new JFrame("Label Example");  
    JLabel l1,l2;  
    l1=new JLabel("Enter Your Gender:");  
    l1.setBounds(50,30, 100,50);  
      
    f.add(l1); 
    l2=new JLabel("Are You Shy?");
    f.add(l2);
    
    JTextField t1;
    t1=new JTextField("Write Somthing About yourself:");
    t1.setBounds(10,10,100,30);
    f.add(t1);
    
    JRadioButton j1=new JRadioButton("A) Male");
    JRadioButton j2=new JRadioButton("B)Female");
    j1.setBounds(75,50,100,30);
    j2.setBounds(75,100,100,30);
    ButtonGroup bg=new ButtonGroup();
    bg.add(j1);
    bg.add(j2);
    f.add(j1);
    f.add(j2);
    
    JCheckBox checkBox=new JCheckBox("True:");
    JCheckBox checkBox1=new JCheckBox("False:");
    checkBox.setBounds(120,120,60,60);
    checkBox1.setBounds(120,150,60,60);
    f.add(checkBox);
    f.add(checkBox1);
    
    f.setSize(400,400);  
    f.setLayout(null);  
    f.setVisible(true);  
    
    
    
    }  
    }