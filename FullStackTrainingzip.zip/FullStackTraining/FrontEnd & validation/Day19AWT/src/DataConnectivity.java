
import java.sql.*;
public class DataConnectivity
{
	public static void  main(String args[])
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/employee";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("connection created succesfully");
				
			}
			else
			{
				System.out.println("Connection is not Created");
			}
			String q="select * from employee1";
			Statement st=con.createStatement();
			ResultSet set=st.executeQuery(q);
			while(set.next())
			{
				int id=set.getInt("empId");
				String name=set.getString("name");
				System.out.println("id:"+id);
				System.out.println("Name:"+name);
				
			}
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}