package com.yash.servlate;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AddServlet extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*//GET and Post Operations
//public void doPost(HttpServletRequest req,HttpServletResponse res ) throws IOException
	public void service(HttpServletRequest req,HttpServletResponse res ) throws IOException, ServletException
	{
		int i=Integer.parseInt(req.getParameter("num1"));
		int j=Integer.parseInt(req.getParameter("num2"));
		int k=i+j;
		
		
		PrintWriter out=res.getWriter();
		out.println("Result is " +k);
		
		
		req.setAttribute("k", k);
		
		RequestDispatcher rd=req.getRequestDispatcher("sq");
		rd.forward(req, res);
		
		res.sendRedirect("k");
		
		
		
	}
	*/

	/*
	 public void doGet(HttpServletRequest req,HttpServletResponse res ) throws IOException
	{
		int i=Integer.parseInt(req.getParameter("num1"));
		int j=Integer.parseInt(req.getParameter("num2"));
		int k=i+j;
		
		
		PrintWriter out=res.getWriter();
		out.println("Result is " +k);
	}
	 */
	
	public void service(HttpServletRequest req,HttpServletResponse res ) throws IOException, ServletException
	{
		int i=Integer.parseInt(req.getParameter("num1"));
		int j=Integer.parseInt(req.getParameter("num2"));
		int k=i+j;
		
		
		/*PrintWriter out=res.getWriter();
		out.println("Result is " +k);
		*/
		
		
		
		
		
		res.sendRedirect("sq?k="+k); //URL Rewriting
		
		
		
	}
	
	
	
}
