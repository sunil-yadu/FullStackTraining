package com.yash.beanPostProcessorDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
public static void main(String[] args) {
		
		ApplicationContext applicationContext = null;
		
		try {
			
			//Creating Instance of ApplicationContext Spring Container
			applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
			
			//Asking Spring Container to return Spring bean with id "message"
			Object object = applicationContext.getBean("message");
			//Covert Spring bean into your business Object
			Message message = (Message)object;
			
			//Print Spring bean state
			System.out.println(message.getMessageId()+"\t"+message.getMessage());
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (applicationContext != null)
				((AbstractApplicationContext) applicationContext).close();
		}
	}
}
