package com.yash.beanPostProcessorDemo;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class MyBeanPostProcessor implements BeanPostProcessor {
	 
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("Inside of postProcessAfterInitialization");
		Message message = null;
		if(bean instanceof Message) {
			message = (Message)bean;
			message.setMessage("Setting bean value in postProcessAfterInitialization");
			
		}
		return message;
	}
	
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("Inside of postProcessBeforeInitialization");
		return bean;
	}
}