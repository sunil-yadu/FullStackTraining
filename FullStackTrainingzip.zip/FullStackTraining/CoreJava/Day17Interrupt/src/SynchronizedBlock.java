class BookTicket1
{
	int totalseats=12;
 void bookSeat(int seats)  
	{
	 synchronized(this)    //ding particular block shnchronization
		if(totalseats>=seats)
		{
			System.out.println("Booke succesfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats:" +totalseats);
		}
		else
		{
			System.out.println("Sorry: available seats are:"+totalseats);
		}
	}
}

public class SynchronizedBlock extends Thread {
	static BookTicket1 b;
	int seats;
	public void run()
	{
		b.bookSeat(seats);
	}
	
	public static void main(String[] args) {
	 b=new BookTicket1();
	 SynchronizedBlock p1=new SynchronizedBlock();
	 p1.seats=8;
	 p1.start();
	 SynchronizedBlock p2=new SynchronizedBlock();
	 p2.seats=10;
	 p2.start();
	 
	}
	
}



	
