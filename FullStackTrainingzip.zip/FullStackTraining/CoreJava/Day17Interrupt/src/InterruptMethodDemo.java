
public class InterruptMethodDemo extends Thread{

	public void run()
	{//try inside try catch and so on for interrupted and isInterrup
		//System.out.println(Thread.currentThread().getName()+" "+Thread.interrupted());
		//System.out.println(Thread.currentThread().getName()+" "+Thread.interrupted());
		System.out.println(Thread.currentThread().getName()+" "+Thread.currentThread().isInterrupted());
		try {
			for(int i=1;i<=3;i++)
			{
				System.out.println(i);
				Thread.sleep(1000);
				/*Thread thread = new Thread();
				thread.wait();*/
			}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		InterruptMethodDemo id=new InterruptMethodDemo();
		id.start();
		id.setName("Thread-1");
	
		id.interrupt();//to check wheather any interrup is occured or not due to sleep() or wait()
	}
}
