class BookTicket
{
	int totalseats=12;
	synchronized void bookSeat(int seats)  //doing method shnchronization
	{
		if(totalseats>=seats)
		{
			System.out.println("Booke succesfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats:" +totalseats);
		}
		else
		{
			System.out.println("Sorry: available seats are:"+totalseats);
		}
	}
}

public class Synchronized extends Thread {
	static BookTicket b;
	int seats;
	public void run()
	{
		b.bookSeat(seats);
	}
	
	public static void main(String[] args) {
	 b=new BookTicket();
	 Synchronized p1=new Synchronized();
	 p1.seats=8;
	 p1.start();
	 Synchronized p2=new Synchronized();
	 p2.seats=10;
	 p2.start();
	 
	}
	
}



	
