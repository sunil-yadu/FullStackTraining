class BookTicket
{
	int totalseats=20;
	void bookSeat(int seats)
	{
		if(totalseats>=seats)
		{
			System.out.println("Booke succesfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats:"+totalseats);
		}
		else
		{
			System.out.println("Sorry: available seats are:"+totalseats);
		}
	}
}

public class WithoutSynchronization extends Thread {
	static BookTicket b;
	int seats;
	public void run()
	{
		b.bookSeat(seats);
	}
	
	public static void main(String[] args) {
	 b=new BookTicket();
	 WithoutSynchronization p1=new WithoutSynchronization();
	 p1.seats=8;
	 p1.start();
	 WithoutSynchronization p2=new WithoutSynchronization();
	 p2.seats=10;
	 p2.start();
	 
	}
	
}



	