//getState() to return thread state
public class GetStateInThread extends Thread {
	public void run()
	{
		Thread.State s=Thread.currentThread().getState();
		System.out.println("Current Thread Name:"+Thread.currentThread().getName());
		System.out.println("State of Thread :"+s);
		/*Thread.State s1=Thread.currentThread().getState();
		System.out.println("State of Thread :"+s1);*/
	}
	public static void main(String[] args)
	{
		GetStateInThread g= new GetStateInThread();
		Thread t1=new Thread(g);
		t1.interrupt();
		Thread t2 = new Thread(g);
		t1.start();
		t1.interrupt();
		t2.start();
		
				
	}
}
