class BookTicket2
{
 static int totalseats=12;   //for synchronization define static
 static synchronized void bookSeat(int seats)   //fro synchronization using multiple class concept
	{
	 
		if(totalseats>=seats)
		{
			System.out.println("Booke succesfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats:" +totalseats);
		}
		else
		{
			System.out.println("Sorry: available seats are:"+totalseats);
		}
	}
}

class Thread1 extends Thread
{
 static BookTicket2 b;
 int seats;
 Thread1(BookTicket2 b,int seats)
 {
	 this.b=b;
	 this.seats=seats;
 }
 public void run()
 {
	 b.bookSeat(seats);
 }
}
class Thread2 extends Thread
{
 static BookTicket2 b;
 int seats;
 Thread2(BookTicket2 b,int seats)
 {
	 this.b=b;
	 this.seats=seats;
 }
 public void run()
 {
	 b.bookSeat(seats);
 }
}

public class DifferentClassThreadSynchronization extends Thread {
	
	public static void main(String[] args) {
	 BookTicket2 b= new BookTicket2();
	 Thread1 t1=new Thread1(b,8);
	 t1.start();
	 Thread2 t2=new Thread2(b,3);
	 t2.start();
	 
	 BookTicket2 b1=new BookTicket2();
	 Thread1 t3=new Thread1(b1,3);
	 t3.start();
	 Thread2 t4=new Thread2(b1,4);
	 t4.start();
	 
	
	 
	}
	
}



	
