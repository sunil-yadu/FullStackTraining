//To group multiple thread in single object
public class ThreadGroupTest extends Thread {
	public void run()
	{
		System.out.println(Thread.currentThread().getName());
	}
	public static void main(String[] args) {
		ThreadGroupTest tg=new ThreadGroupTest();
		ThreadGroup tg1=new ThreadGroup("Thread Group");
		Thread t1=new Thread(tg1,tg,"Thread-1");
		t1.start();
		
		Thread t2=new Thread(tg1,tg,"Thread-2");
		t2.start();
		
		Thread t3 = new Thread(tg1,tg,"Tread-3");
		t3.start();
		
		System.out.println("ThreadGroupName:"+tg1.getName());
		
	}

}
