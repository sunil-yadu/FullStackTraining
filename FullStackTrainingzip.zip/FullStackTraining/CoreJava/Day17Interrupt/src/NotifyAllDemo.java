class Revenue extends Thread
{
	int total=0;
	public void run()
	{
		synchronized(this)
		{
			for(int i=1;i<=5;i++)
			{
				total = total+400;
			}
			this.notifyAll();
			System.out.print("Revenue Done");
			
		}
	}
}

public class NotifyAllDemo 
{
public static void main(String[] args) throws Exception
	{
		
		Revenue r= new Revenue();
		r.start();
		synchronized(r)
		{
			r.wait();
			System.out.println("Toatl Amount:"+r.total);
		}
	}
}

	

