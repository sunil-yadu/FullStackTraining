import java.util.Scanner;
import java.util.InputMismatchException;
class ArithmeticException extends RuntimeException
{
	ArithmeticException(String s)
	{
		super(s);
	}
}

class Assignment8
{
	public static void main(String args[])
	{
		
		
			
	    Scanner sc=new Scanner(System.in);
		int a;
		System.out.println("Enter First Integeer:");
		a=sc.nextInt();
		//Scanner sc=new Scanner(System.in);
		int b;
		System.out.println("Enter Second Integeer:");
		b=sc.nextInt();
		
		try{ 
		int c=0;
		if(b==0)
		{
			throw new ArithmeticException("Divide by zero ");//Try to throw two exception
			
		}
		else{
		c=a/b;
		System.out.println("division:"+c);
		}
		}
		
		catch(IndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		catch(NumberFormatException m)
		{
			System.out.println(m);
		}
		finally
		{
			System.out.println("In final block");
		}
		
		
	}
}