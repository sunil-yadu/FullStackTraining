import java.util.Scanner;
class VoteEligiblity extends RuntimeException
{
	VoteEligiblity(String s)
	{
		super(s);
	}
}

class ThrowDemo
{ //abnormal throw exception 
	/*public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter your age");
		int age=s.nextInt();
		if(age<18)
		{
			throw new VoteEligiblity("You are not eligible for vote");
			System.out.println("After throw");//Unreacheble
			
		}
		else
		{
			System.out.println("You can vote");
		}
		System.out.println("abnormal termination");
	}*/
	//Normal throw exception using try catch
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter your age");
		int age=s.nextInt();
		try{
		if(age<18)
		{
			throw new VoteEligiblity("You are not eligible for vote");
			//System.out.println("After throw");//Unreacheble bcz after nothing can work
			
		}
		else
		{
			System.out.println("You can vote");
		}
		}
		catch(VoteEligiblity e)
		{
			e.printStackTrace();
		}
		System.out.println("normal termination");
	}
}