import java.util.Scanner;
import java.util.InputMismatchException;
class NegativeValue extends RuntimeException
{
	NegativeValue(String s)
	{
		super(s);
	}
}

class Assignment5 
{
	public static void main(String args[])
	{
		try{
		
			
	    Scanner sc=new Scanner(System.in);
		String s1;
		System.out.println("Enter First Student name");
		s1=sc.next();
		
		
		int student1[];
		student1=new int[3];
		System.out.println("Enter Marks of first student:");
	   
		for(int i=0;i<student1.length;i++)
		{   if(sc.nextInt()>100)
			{
				throw new NegativeValue ("You have entered wrong marks:");
			}
			else if(sc.nextInt()<0)
			{
				throw new NegativeValue ("You have entered negative marks:");
			}
			else
		{
			System.out.println("okay fine");
		}
			
			student1[i]=sc.nextInt();
			
		}
		String s2;
		System.out.println("Enter Second Student name");
		s2=sc.next();
		int student2[];
		student2=new int[3];
		System.out.println("Enter Marks of second student:");
	    int sum1=0;
		for(int i=0;i<student2.length;i++)
		{
			if(sc.nextInt()>100)
			{
				throw new NegativeValue ("You have entered wrong marks:");
			}
			else if(sc.nextInt()<0)
			{
				throw new NegativeValue ("You have entered negative marks:");
			}
			else
		{
			System.out.println("okay fine");
		}
			
			student2[i]=sc.nextInt();
			
		}
		
		for(int j=0;j<student1.length;j++)
		{
			sum1+=student1[j];
		}
		System.out.println(sum1/3);
		
		int sum2=0;
		for(int j=0;j<student2.length;j++)
		{
			sum2+=student2[j];
		}
		System.out.println(sum2/3);
		
		}
		catch(IndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		catch(NumberFormatException m)
		{
			System.out.println(m);
		}
		finally
		{
			System.out.println("In final block");
		}
		
		
	}
}