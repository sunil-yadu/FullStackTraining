import java.io.FileInputStream;

class ExceptionDemo1
{
	public static void main(String args[])
	{     //IO Exception
		//FileInputStream f=new FileInputStream("D:/xyz.txt");//FileNotFoundException; must be caught or declared to be thrown
		System.out.println("Hii");
		try{
		System.out.println(10/0);
		}
		
		catch(Exception e)
		{
			System.out.println(e);//divide by zero exception
		}
	}

}