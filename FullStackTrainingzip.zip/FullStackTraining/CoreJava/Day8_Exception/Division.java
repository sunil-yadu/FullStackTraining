import java.util.Scanner;
import java.util.InputMismatchException;

class Division
{
	public static void main(String args[])
	{
		public void divide()
		{
		}
	
	}
}