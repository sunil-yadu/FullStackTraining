class ExceptionFinally
{
	public static void main(String args[])
	{

		try{
			int a=10;
			int b=0;
			//int c = a/b;
		}//Without catch also it will work
		/*catch(ArithmeticException e)
		{
			//e.printStackTrace();
			//System.out.println(e.getMessage());
			System.out.println(e);
		}*/
		finally  //we can put try catch in finally as well
		{ 
           try{		
		   int c =10;
		   int d=0;
		   int e=c/d;
        } 
        catch(Exception e)
        {
	     System.out.println(e);
        }
		
			System.out.println("In finally block");
		}
	}
}