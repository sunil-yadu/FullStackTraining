import java.util.Scanner;
import java.util.InputMismatchException;
class InvalidCountryException extends RuntimeException
{
	InvalidCountryException(String s)
	{
		super(s);
	}
}

class Assignment7 //UserRagistration 
{
	public void ragisterUser(String userName,String userCountry)
		{
			if(userCountry=="India")
			{
				System.out.println("User Ragistration done successfully");
				
			}
			else
			{
				throw new InvalidCountryException("User Outside India");
				
			}
			
		}
	public static void main(String args[])
	{   
	String s="India";
		
	
		
			
	    Scanner sc=new Scanner(System.in);
		String userName;
		System.out.println("Enter UserName name");
		userName=sc.next();
		String userCountry;
		System.out.println("Enter Country name");
		userCountry=sc.next();
		Assignment7 a=new Assignment7();
		a.ragisterUser(userName,userCountry);
		
	
		
		
		
		
		
		
	}
}