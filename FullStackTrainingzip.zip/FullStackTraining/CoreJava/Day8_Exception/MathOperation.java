import java.util.Scanner;
import java.util.InputMismatchException;

class MathOperation //Assignment3 also in same code
{
	public static void main(String args[])
	{
		try{
		//System.out.println("Enter size of array:");
		
		//int size=sc.nextInt();
		int a[];
		a=new int[5];
		System.out.println("Enter element");
		Scanner sc=new Scanner(System.in);
	
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
		}
		int sum=0;
		for(int j=0;j<a.length;j++)
		{
			sum+=a[j];
		}
		System.out.println("sum is:"+sum);
		System.out.println("average is:"+sum/5);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		catch(NumberFormatException n)
		{
			System.out.println(n);
		}
	}
}