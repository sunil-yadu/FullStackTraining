class ExceptionDemo
{
	public static void main(String args[])
	{
		System.out.println("Hii");
		try{
		System.out.println(10/0);
		}
		catch(Exception e)
		{
			System.out.println(e);//unchecked exception
		}
	}

}