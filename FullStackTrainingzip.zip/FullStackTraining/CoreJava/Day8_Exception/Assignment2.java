import java.util.Scanner;
import java.util.InputMismatchException;

class Assignment2 //Assignment3 also in same code
{
	public static void main(String args[])
	{
		try{
		System.out.println("Enter size of array:");
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int a[];
		a=new int[size];
		System.out.println("Enter element");
	
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
			
		}
		
		System.out.println("Enter Index you want ot acces");
		int idx=sc.nextInt();
		System.out.println("value at index :"+a[idx]);
		}
		catch(IndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		catch(NumberFormatException m)
		{
			System.out.println(m);
		}
		finally
		{
			System.out.println("In final block");
		}
		
		
	}
}