import java.io.FileInputStream;
class ExceptionDemo3
{
	public static void main(String args[])
	{
		try{
			int a=10;
			int b=0;
			int c = a/b;
		}
		catch(ArithmeticException e)
		{
			//e.printStackTrace();
			//System.out.println(e.getMessage());
			System.out.println(e);
		}
	}
}