import java.util.Scanner;

class Assignment1
{
	public static void main(String args[])
	{
		System.out.println("Enter String number");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		try{
			a=a*a;
			System.out.println(a);
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			//System.out.println(e.getMessage());
			System.out.println(e);
			System.out.println("Entered Inputis not in valid Formate");
		}
	}
}