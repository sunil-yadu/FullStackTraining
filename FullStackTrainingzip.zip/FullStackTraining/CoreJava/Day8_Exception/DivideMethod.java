import java.util.Scanner;
import java.util.InputMismatchException;

class DivideMethod
{ int a=10;
  int b=0;
	public void divide()
		{
			System.out.println(a/b);
		}
	public static void main(String args[])
	{
		DivideMethod d=new DivideMethod();
		d.divide();
		
	
	}
}
//apply try catch