
public class SingleTT extends Thread{
	public void run()
	{
	 System.out.println("Hi i am in thread ");
	}
	
	public static void main(String[] args)
	{
		SingleTT t=new SingleTT();
		t.start();
	}

}
