
public class SetPriority extends Thread {
	public void run()
	{
		System.out.println("In run method:");
		System.out.println(Thread.currentThread().getPriority());
	}
	public static void main(String[] args) {
		//System.out.println(Thread.currentThread().getPriority());
		SetPriority s=new SetPriority();
	  Thread t=new Thread(s);
	  t.start();
	}

}
