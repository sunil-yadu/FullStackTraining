
public class SetNameThread {
	public static void main(String[] args)
	{
		Thread.currentThread().setName("SunilMain");
		System.out.println(Thread.currentThread().getName());
		
		
		
	}

}
