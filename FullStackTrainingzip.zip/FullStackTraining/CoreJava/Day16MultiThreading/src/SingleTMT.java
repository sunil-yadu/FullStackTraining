
public class SingleTMT extends Thread{

	public void run()
	{
	 System.out.println("Hi i am in thread ");
	}
	
	public static void main(String[] args)
	{
		SingleTMT t=new SingleTMT();
		SingleTMT t2=new SingleTMT();
		t.start();
		t2.start();
	}

}
