class MyThread11 implements Runnable{
	public void run()
	{
		System.out.println("Thread1 says HIi From runnable");
		
	}
}
class MyThread22 implements Runnable{
	public void run()
	{
		System.out.println("Thread2 says HIi From runnable");
		
	}
}
class MyThread33 implements Runnable{
	public void run()
	{
		System.out.println("Thread3 says HIi From runnable");
		
	}
}


	

public class SingleTaskMultiThreadRunnable {
	public static void main(String[] args)
	{
		
		MyThread11 mt1=new MyThread11();
		Thread t=new Thread(mt1);
		t.start();
		MyThread22 mt2=new MyThread22();
		Thread t2=new Thread(mt2);
		t2.start();
		MyThread33 mt3=new MyThread33();
		Thread t3=new Thread(mt3);
		t3.start();
	}

}




