
public class SingleTaskSIngleThreadUsingRunnable implements Runnable{

	public void run()
	{
	 System.out.println("Hi i am in thread Using Runnable ");
	}
	
	public static void main(String[] args)
	{
		
		SingleTaskSIngleThreadUsingRunnable t=new SingleTaskSIngleThreadUsingRunnable();
		Thread t1=new Thread(t);
		t1.start();
	}
}
