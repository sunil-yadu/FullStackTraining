public class Yield1 extends Thread {
	public void run()
	{
		for(int i=0;i<5;++i)
		{//try it
			Thread.yield();
		System.out.println("In run method threas"+i);
		}
		System.out.println("out from loop");
	}
}

public class ThreadLYield extends Yield1	
{
	public static void main(String[] args)
	{
		Yield1 ty=new Yield1();
		Thread t = new Thread(ty);
		t.start();
		for(int i=0;i<5;++i)
		{
			System.out.println("Thread start Main"+Thread.currentThread().getName());
			System.out.println("Thread end"+Thread.currentThread().getName());
		}
	}
	

}
