
public class SetNameThreadDemo extends Thread {
	public void run()
	{   System.out.println(Thread.currentThread().getName());
	
		System.out.println("In run method");
	}

	public static void main(String[] args)
	{
		SetNameThreadDemo st=new SetNameThreadDemo();
		st.setName("Thread t1");
		Thread t=new Thread(st);
		t.start();
		System.out.println(Thread.currentThread().getName());
		System.out.println(t.isAlive());


		SetNameThreadDemo st2=new SetNameThreadDemo();
		st.setName("Thread t2");
		
		Thread t2=new Thread(st2);
		t2.start();
		System.out.println(Thread.currentThread().getName());
	
		System.out.println("t thread alive ?: "+t.isAlive());
		System.out.println(t2.isAlive());
		System.out.println(Thread.currentThread().isAlive());
	}

}
