
public class ThreadRunnable implements Runnable{
	public void run()
	{
	 System.out.println("Hi i am in thread Runnable ");
	}
	
	public static void main(String[] args)
	{
		ThreadDemo t=new ThreadDemo();
		
		Thread t1=new Thread(t);
		//Thread t1=new Thread(new ThreadDemo());
		//another way or single line way
		
		t1.start();
	}

}
