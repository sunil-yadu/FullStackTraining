import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
class BufferedOutputDemo
{
	public static void main(String[] args)
	    FileOutputStream in=null;
		BufferedOutputStream out=null;
		try
		{
			in=new FileOutputStream ("C:/Users/Sunil.M/Desktop/Trainee/Day10_File/TextFile.txt");
			out=new BufferedOutputStream("C:/Users/Sunil.M/Desktop/Trainee/Day10_File/CopyFile.txt");
			int emptyCheck;
			while((i=binput.read())!=-1)
			{ 
		      out.write(emptyCheck);
				System.out.print((char)emptyCheck);
				
			}
		
		}
			catch(Exception e)
			{
				System.out.println(e);
			
			}

			finally{
		try
		{
			if(in!=null)
			{
			in.close();
			}
		if(out!=null)
		{
			out.close();
		}
		}
		catch(Exception e)
			{
				System.out.println(e);
			}
			}
			
		
	}
}