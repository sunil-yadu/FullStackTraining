import java.io.*;    
class BufferedOutputCombine
{    
  public static void main(String args[])throws Exception{    
   FileInputStream fin1=new FileInputStream("C:/Users/Sunil.M/Desktop/Trainee/Day10_File/TextFile.txt");    
   FileInputStream fin2=new FileInputStream("C:/Users/Sunil.M/Desktop/Trainee/Day10_File/TextFile.txt");    
   FileOutputStream fout=new FileOutputStream("C:/Users/Sunil.M/Desktop/Trainee/Day10_File/combine.txt");      
   SequenceInputStream s1=new SequenceInputStream(fin1,fin2);    
   int i;    
   while((i=s1.read())!=-1)    
   { System.out.print((char)i); 
     fout.write(i);        
   }    
   s1.close();    
   fout.close();      
   fin1.close();      
   fin2.close();       
   System.out.println("Program is Successfully Run..");  
  }    
}    