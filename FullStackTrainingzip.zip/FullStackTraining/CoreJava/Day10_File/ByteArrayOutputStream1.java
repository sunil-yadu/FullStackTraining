import java.io.*;    
class ByteArrayOutputStream1
{    
  public static void main(String args[])throws Exception{    
     
          
   System.out.println("Program is Successfully Run..");  
  }    
}    