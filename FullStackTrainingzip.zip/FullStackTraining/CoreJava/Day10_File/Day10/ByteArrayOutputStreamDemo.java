import java.io.FileOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;    
class ByteArrayOutputStreamDemo
{    
  public static void main(String args[])throws Exception
  { FileOutputStream f1=new FileOutputStream("C:/Users/Sunil.M/Desktop/Day10/yash.txt");
    FileOutputStream f2=new FileOutputStream("C:/Users/Sunil.M/Desktop/Day10/tech.txt");
	ByteArrayOutputStream bt=new ByteArrayOutputStream();
	char s='w';
	int t=(char)s;
	bt.write(t);//e ascii value ?how to give string ?if we want previous data as well
	bt.writeTo(f1);
	bt.writeTo(f2);
	bt.close();
	System.out.println("Done Copy");
     
          
   
  }    
}    