import java.io.File;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

class FInputOutputStreamOp3 
{
	public static void main(String args[]) throws IOException
	{
		FileInputStream input=new FileInputStream("C:/Users/Sunil.M/Desktop/Day10/yash2.txt");
		FileOutputStream output=new FileOutputStream("C:/Users/Sunil.M/Desktop/Day10/yash1.txt");
		int inputCopy;
		while((inputCopy=input.read())!=-1)
			output.write(inputCopy);
		
		
		input.close();
		output.close();
		
		/* //for reading copied data
		File f=new File("C:/Users/Sunil.M/Desktop/Day10/yash1.txt");
		FileReader fr=new FileReader(f);
		char r[]= new char[100];
		fr.read(r);
		for(char c:r)
			System.out.print(c);
		fr.close();
		*/
		System.out.println("Copy Done");
	}
}