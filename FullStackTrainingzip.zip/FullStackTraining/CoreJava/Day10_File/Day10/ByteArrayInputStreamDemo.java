import java.io.*;

class ByteArrayInputStreamDemo
{
	public static void main(String args[]) throws IOException
	{    //the data will read as a byte array stream
	    byte[] bu={12,10,11};
		//FileOutputStream f1=new FileOutputStream("C:/Users/Sunil.M/Desktop/Day10/yash.txt");
		ByteArrayInputStream byt = new ByteArrayInputStream(bu);  
		int k=0;
		while((k=byt.read())!=-1)
		{
			char ch=(char)k;
			//byt.write(ch);
			//byt.writeTo(f1);
			
			System.out.print(+ch);
		}
	}
	
}