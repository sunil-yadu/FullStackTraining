import java.io.File;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.BufferedInputStream;
class BInputDemoOp4
{
	public static void main(String[] args) throws IOException
	{
		FileInputStream input= new FileInputStream("C:/Users/Sunil.M/Desktop/Day10/yash2.txt");
		BufferedInputStream binput=new BufferedInputStream(input);
		int i;
		while((i=binput.read())!=-1)
		{
			System.out.print((char)i);
			
		}
		binput.close();
		input.close();
		
	}
}