import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;


class FileAssignment2 {
    public static void main(String[] args)throws IOException
    {

        String fileName = "C:/Users/Sunil.M/Desktop/Day10/yash.txt";
        String line = "";
        Scanner scanner = new Scanner(new FileReader(fileName));
	
	try {

          while ( scanner.hasNextLine() ){
            line = scanner.nextLine();
           
			int a=0;
			int e=0;
			int i2=0;
			int o=0;
			int u=0;
			

            for( int i=0; i<line.length(); i++ ) {
                if( line.charAt(i) == 'A' ) 
				{
                    a++; 

                } 
				if( line.charAt(i) == 'E' ) 
				{
                    e++; 

                } 
				if( line.charAt(i) == 'I' ) 
				{
                    i2++; 

                } 
				if( line.charAt(i) == 'O' ) 
				{
                    o++; 

                } 
				if( line.charAt(i) == 'U' ) 
				{
                    u++; 

                } 

            }
         
             System.out.println("A:="+a); 
			  System.out.println("E:="+e); 
			   System.out.println("I:="+i2); 
			    System.out.println("O:="+o); 
				 System.out.println("U:="+u);
				 int sum=a+e+i2+o+u;
				 System.out.println("Total Vowels:="+sum);
			 
          }
        }
        finally 
		{

          scanner.close();
        }
    }
}

//Jaynam Sir is our official Technical Trainer
//1       (J appers only 1 time)
	