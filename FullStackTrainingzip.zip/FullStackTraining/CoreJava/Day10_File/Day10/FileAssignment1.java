import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.File;
class FileAssignment1
{
public static void main(String[] args) throws IOException
{
		File f = new File("C:/Users/Sunil.M/Desktop/Day10/yash.txt");
		FileInputStream fis = new FileInputStream(f);
		InputStreamReader isr = new InputStreamReader(fis);
		BufferedReader br = new BufferedReader(isr);
		
		String line;
		int tWord = 0;
		int tChar = 0;
		int tSpace = 0;
		while ((line = br.readLine()) != null)
		{
			{
				tChar += line.length();
				String words[] = line.split("\\s+");
				tWord += words.length;
				tSpace += tWord - 1;
			}
			
		}
		System.out.println("tWord= "+ tWord);
	    System.out.println("tChar = "+ tChar);
		System.out.println("tSpace= "+ tSpace);
	}
}
