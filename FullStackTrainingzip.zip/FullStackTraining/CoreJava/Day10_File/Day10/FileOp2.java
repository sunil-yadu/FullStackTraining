import java.io.File;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.FileReader;
import java.io.FileWriter;
class FileOp2
{
	public static void main(String args[]) throws IOException
	{
		File f=new File("C:/Users/Sunil.M/Desktop/Day10/yash2.txt");
		//FileWriter w=new FileWriter(f);
		//w.write("Buddy love the way you lie");
		//w.close();
		
		/* for reading data from any file*/
		FileReader fr=new FileReader(f);
		char r[]= new char[100];
		fr.read(r);
		for(char c:r)
			System.out.print(c);
		fr.close();
		
		System.out.print("Added succesfully");

	}
}