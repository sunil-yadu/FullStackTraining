import java.io.FileOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
class DataOutputStreamDemo
{//to write any string in file
	public static void main(String args[])throws Exception
	{
	FileOutputStream f1=new FileOutputStream("C:/Users/Sunil.M/Desktop/Day10/yash.txt");
	DataOutputStream data=new DataOutputStream(f1);
	String s="welcom";
	data.writeChars(s);
	data.close();
	System.out.println("Done");
}
}