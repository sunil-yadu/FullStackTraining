import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;


class FileAssignment3 {
    public static void main(String[] args)throws IOException
    {

        String fileName = "C:/Users/Sunil.M/Desktop/Day10/yash.txt";
        String line = "";
        Scanner scanner = new Scanner(new FileReader(fileName));
	try {

          while ( scanner.hasNextLine() ){
            line = scanner.nextLine();
            int count = 0;
            for( int i=0; i<line.length(); i++ ) {
                if( line.charAt(i) == 'j' ) 
				{
                    count++; 

                } 

            }
         
             System.out.println("count of entered char is:="+count); 
			 
			 
          }
        }
        finally 
		{

          scanner.close();
        }
    }
}

//Jaynam Sir is our official Technical Trainer
//1       (J appers only 1 time)
	