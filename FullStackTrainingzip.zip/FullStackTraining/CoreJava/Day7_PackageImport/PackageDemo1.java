/*//First way
class PackageDemo
{
	public static void main(String[] args)
	{
		myPackage1.Start1 ob=new myPackage1.Start1();
		ob.display();
	}
}*/

//second way best as pr my view
import myPackage1.Start1;
class PackageDemo1
{
	public static void main(String[] args)
	{
		Start1 ob =new Start1();
		ob.display();
	}
}

