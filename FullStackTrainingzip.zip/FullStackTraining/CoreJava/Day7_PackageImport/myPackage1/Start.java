package myPackage1;
public class Start1
{
	public void display()
	{
		System.out.println("i am in display-start");
	}
}