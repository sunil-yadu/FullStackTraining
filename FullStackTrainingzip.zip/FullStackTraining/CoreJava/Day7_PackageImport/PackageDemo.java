/*//First way
class PackageDemo
{
	public static void main(String[] args)
	{
		myPackage.Start ob=new myPackage.Start();
		ob.display();
	}
}*/

//second way best as pr my view
import myPackage.Start;
class PackageDemo
{
	public static void main(String[] args)
	{
		Start ob =new Start();
		ob.display();
	}
}

