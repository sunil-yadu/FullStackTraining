/*//First way
class Horse
{
	public static void main(String[] args)
	{
		animalPackage.Animal ob=new animalPackage.Animal();
		ob.eat();
		ob.walk();
	}
	
}*/

//second way best as pr my view
import animalPackage.Animal;
class Horse
{
	void horseCan()
	{
		System.out.println("Horse Can Do:");
	}
	
	public static void main(String[] args)
	{
	 
	    Horse h=new Horse();
		h.horseCan();
		Animal ob =new Animal();
		ob.eat();
		ob.walk();
	}
}

