package com.yash.insertEmployee.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.insertEmployee.entities.Admin;


public class AdminRowMapper implements RowMapper<Admin>{
	
	public Admin mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Admin admin=new Admin();
		
		
		admin.setEmailid(rs.getString(1));//column name1
		admin.setPass_code(rs.getString(2));//column name-2
		

		return admin;
		}
}