package com.yash.insertEmployee.dao;

import com.yash.insertEmployee.entities.Admin;



public interface AdminDao {
	public int createAccount(Admin stu);
	public Admin selectDetails(String aEmail,String aPass_code);
	

}
