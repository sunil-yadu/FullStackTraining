package com.yash.insertEmployee.dao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.yash.insertEmployee.entities.Employee;





public class EmployeeImpl implements EmployeeDao {

private JdbcTemplate jdbctemp;

public JdbcTemplate getJdbctemp() {
return jdbctemp;
}
public void setJdbctemp(JdbcTemplate jdbctemp) {
this.jdbctemp = jdbctemp;
}


public int insert(Employee stu) {

String q="insert into emp(empname,emailid,dob,contactno,salary) values(?,?,?,?,?)";
int msg=this.jdbctemp.update(q,stu.getName(),stu.getEmailid(),stu.getDob(),stu.getContactno(),stu.getSalary());
return msg;
}

public int updatedetails(Employee stu) {
	String q="update emp set emailid=?  where empname=?";
	int msg=this.jdbctemp.update(q,stu.getEmailid(),stu.getName());

	return msg;
}

public int deletedetails(String stu) {
	String q="delete from emp where empname=?";
	
	int msg=this.jdbctemp.update(q,stu);

	return msg;
}
public Employee selectDetails(String stuid) {
	
		// TODO Auto-generated method stub
		String q="select * from emp where empName=?";
		RowMapper<Employee> rowmapper=new RowMapperimpl();
		Employee employee=this.jdbctemp.queryForObject(q,rowmapper,stuid);

		return employee;

		
}


}


