package com.yash.insertEmployee.dao;

import com.yash.insertEmployee.entities.Employee;


public interface EmployeeDao {
	
		public int insert(Employee stu);
	    public int updatedetails(Employee stu);
	    public int deletedetails(String stu);
	    public Employee selectDetails(String stuid);

	

	


}
