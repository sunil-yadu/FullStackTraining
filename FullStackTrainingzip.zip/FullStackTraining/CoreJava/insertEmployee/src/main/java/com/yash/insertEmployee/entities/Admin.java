package com.yash.insertEmployee.entities;

public class Admin {
	private String emailid;
	private String pass_code;
	public String getEmailid() {
		return emailid;
	}
	public String getPass_code() {
		return pass_code;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public void setPass_code(String pass_code) {
		this.pass_code = pass_code;
	}
	@Override
	public String toString() {
		return "Admin [emailid=" + emailid + ", pass_code=" + pass_code + "]";
	}

}
