package com.yash.insertEmployee;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.insertEmployee.dao.AdminDao;
import com.yash.insertEmployee.dao.EmployeeDao;
import com.yash.insertEmployee.entities.Admin;
import com.yash.insertEmployee.entities.Employee;


/**
 * Hello world!
 *
 */
public class App 
{
	public static void main( String[] args )
	{

		ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		EmployeeDao stdao=context.getBean("StudentDao",EmployeeDao.class);
		Employee s=new Employee();
		
		
		AdminDao ad_dao=context.getBean("AdminDao",AdminDao.class);
		Admin a= new Admin();
		
		
		
	System.out.println( "Hello World!" );
	System.out.println("Select Option: 1 Create Account 2 Login");
	Scanner scOption=new Scanner(System.in);
	int option=scOption.nextInt();

	if(option==1)
	{
		System.out.println("Enter EmailId");
		Scanner scEmail=new Scanner(System.in);
		String adminEmail=scEmail.next();
		
		
		System.out.println("Enter Unique Pass_code:");
		Scanner scPass_code=new Scanner(System.in);
		String adminPass_code=scPass_code.next();
		a.setEmailid(adminEmail);
		a.setPass_code(adminPass_code);
		
		int i=ad_dao.createAccount(a);
		System.out.println(i+"Account Created Succefully");
		
	}
	else if(option==2)
	{
		System.out.println("Enter Unique UserName:");
		Scanner sc7=new Scanner(System.in);
        String sUserName=sc7.next();
        System.out.println("Enter Unique PassWord:");
		Scanner sc8=new Scanner(System.in);
        String sPass_code=sc8.next();
        
        Admin s2=ad_dao.selectDetails(sUserName,sPass_code);
		System.out.println(s2);
		
		String validateEmail=s2.getEmailid();
		String validatePass_code=s2.getPass_code();
		
		if(sUserName.equals(validateEmail) && sPass_code.equals(validatePass_code))
		{
			System.out.println("SuccessFully Validated");
			
			
		}
		else
		{
			System.out.println("You Have Entered  Wrong Login ID Password");
			
		}
		
	}
	else
	{
		System.out.println("Plase select right option");
	}
	


		System.out.println("Select Your Choice: 1 Insert 2 Update 3 Delete 4 Print");
		Scanner sc = new Scanner(System.in);
		int c=sc.nextInt();
		
		if(c==1)
		{
			
			
			System.out.println("Enter Unique EmpName:");
			Scanner sc2=new Scanner(System.in);
			String empName=sc2.next();
			
			
			System.out.println("Enter Unique empEmailid:");
			Scanner sc3=new Scanner(System.in);
			String empEmailid=sc3.next();
			System.out.println("Enter Unique empDob:");
			Scanner sc4=new Scanner(System.in);
			String empDob=sc4.next();
			System.out.println("Enter Unique EmpContactno:");
			Scanner sc5 = new Scanner(System.in);
			int empContactno=sc5.nextInt();
			System.out.println("Enter Unique EmpSalary:");
			Scanner sc6 = new Scanner(System.in);
			int salary=sc6.nextInt();
				
			
			s.setName(empName);
			s.setEmailid(empEmailid);
			s.setDob(empDob);
			s.setContactno(empContactno);
			s.setSalary(salary);
			
			int i=stdao.insert(s);
			System.out.println(i + "Employee Inserted Successfully ");
			
		}
		else if(c==2)
		{
			System.out.println("Enter Unique EmpName:");
			Scanner sc2=new Scanner(System.in);
			String empName=sc2.next();
			
			
			System.out.println("Enter Unique empEmailid:");
			Scanner sc3=new Scanner(System.in);
			String empEmailid=sc3.next();
			System.out.println("Enter Unique empDob:");
			Scanner sc4=new Scanner(System.in);
			String empDob=sc4.next();
			System.out.println("Enter Unique EmpContactno:");
			Scanner sc5 = new Scanner(System.in);
			int empContactno=sc5.nextInt();
			System.out.println("Enter Unique EmpSalary:");
			Scanner sc6 = new Scanner(System.in);
			int salary=sc6.nextInt();
				
			
			s.setName(empName);
			s.setEmailid(empEmailid);
			s.setDob(empDob);
			s.setContactno(empContactno);
			s.setSalary(salary);
			
			int i=stdao.updatedetails(s);
		
			
			System.out.println(i + "Employee Updated Successfully ");
		}
		else if(c==3)
		{
			
			System.out.println("Enter empName which is you want to delete");
			Scanner sc1=new Scanner(System.in);
			String nameKey=sc1.next();
			
			int i=stdao.deletedetails(nameKey);
			System.out.println(i + "Employee deleted Successfully ");
			
		}
		else if(c==4)
		{
			System.out.println("Enter Unique UserName:");
			Scanner sc7=new Scanner(System.in);
	        String s1=sc7.next();
	        Employee s2=stdao.selectDetails(s1);
			System.out.println(s2);

		}
		else
		{
			System.out.println("Please Select right option");
		}
		}

		
		
		
		
		//int r=stdao.insert(s);
		//System.out.println(r + "Employee data added Successfully ");
		
		//int r=stdao.updatedetails(s);
		//System.out.println(r+"Updated Successfull");
		
		//int r=stdao.deletedetails("Hariom");//delete the details
		//System.out.println(r + "Employee deleted Successfully ");

}
	
		
		
	


	

	
	

	 

	
	
