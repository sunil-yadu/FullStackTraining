package com.yash.insertEmployee.entities;

public class Employee {

	private String name;
	private String emailid;
	private String dob;
	private double contactno;
	private int salary;
	public String getName() {
		return name;
	}
	public String getEmailid() {
		return emailid;
	}
	public String getDob() {
		return dob;
	}
	public double getContactno() {
		return contactno;
	}
	public int getSalary() {
		return salary;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public void setContactno(double contactno) {
		this.contactno = contactno;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", emailid=" + emailid + ", dob=" + dob + ", contactno=" + contactno
				+ ", salary=" + salary + "]";
	}
	
}
