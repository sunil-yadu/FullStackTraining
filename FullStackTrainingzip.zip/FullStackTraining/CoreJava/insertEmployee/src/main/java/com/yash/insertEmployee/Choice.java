package com.yash.insertEmployee;

import java.util.Scanner;

import com.yash.insertEmployee.entities.Employee;

public class Choice
{
	private static void display() {
		System.out.println("Select Your Choice: 1 Insert 2 Update 3 Delete 4 Print");
		Scanner sc = new Scanner(System.in);
		int c=sc.nextInt();
		
		if(c==1)
		{
			
			
			System.out.println("Enter Unique EmpName:");
			Scanner sc2=new Scanner(System.in);
			String empName=sc2.next();
			
			
			System.out.println("Enter Unique empEmailid:");
			Scanner sc3=new Scanner(System.in);
			String empEmailid=sc3.next();
			System.out.println("Enter Unique empDob:");
			Scanner sc4=new Scanner(System.in);
			String empDob=sc4.next();
			System.out.println("Enter Unique EmpContactno:");
			Scanner sc5 = new Scanner(System.in);
			int empContactno=sc5.nextInt();
			System.out.println("Enter Unique EmpSalary:");
			Scanner sc6 = new Scanner(System.in);
			int salary=sc6.nextInt();
				
			
			s.setName(empName);
			s.setEmailid(empEmailid);
			s.setDob(empDob);
			s.setContactno(empContactno);
			s.setSalary(salary);
			
			int i=stdao.insert(s);
			System.out.println(i + "Employee Inserted Successfully ");
			
		}
		else if(c==2)
		{
			System.out.println("Enter Unique EmpName:");
			Scanner sc2=new Scanner(System.in);
			String empName=sc2.next();
			
			
			System.out.println("Enter Unique empEmailid:");
			Scanner sc3=new Scanner(System.in);
			String empEmailid=sc3.next();
			System.out.println("Enter Unique empDob:");
			Scanner sc4=new Scanner(System.in);
			String empDob=sc4.next();
			System.out.println("Enter Unique EmpContactno:");
			Scanner sc5 = new Scanner(System.in);
			int empContactno=sc5.nextInt();
			System.out.println("Enter Unique EmpSalary:");
			Scanner sc6 = new Scanner(System.in);
			int salary=sc6.nextInt();
				
			
			s.setName(empName);
			s.setEmailid(empEmailid);
			s.setDob(empDob);
			s.setContactno(empContactno);
			s.setSalary(salary);
			
			int i=stdao.updatedetails(s);
		
			
			System.out.println(i + "Employee Updated Successfully ");
		}
		else if(c==3)
		{
			
			System.out.println("Enter empName which is you want to delete");
			Scanner sc1=new Scanner(System.in);
			String nameKey=sc1.next();
			
			int i=stdao.deletedetails(nameKey);
			System.out.println(i + "Employee deleted Successfully ");
			
		}
		else if(c==4)
		{
			System.out.println("Enter Unique UserName:");
			Scanner sc7=new Scanner(System.in);
	        String s1=sc7.next();
	        Employee s2=stdao.selectDetails(s1);
			System.out.println(s2);

		}
		else
		{
			System.out.println("Please Select right option");
		}
		}

		
		
		
		
		//int r=stdao.insert(s);
		//System.out.println(r + "Employee data added Successfully ");
		
		//int r=stdao.updatedetails(s);
		//System.out.println(r+"Updated Successfull");
		
		//int r=stdao.deletedetails("Hariom");//delete the details
		//System.out.println(r + "Employee deleted Successfully ");
		}
	
		
		
	
