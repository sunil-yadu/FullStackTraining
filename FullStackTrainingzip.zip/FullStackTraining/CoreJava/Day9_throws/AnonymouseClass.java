abstract class Person
{
	abstract void eat();
}
class AnonymouseClass
{
	public static void main(String args[])
	{
		Person p=new Person()
		{
			void eat()
			{
				System.out.println("Eating");
			}
			
		};
		p.eat();
	}
}