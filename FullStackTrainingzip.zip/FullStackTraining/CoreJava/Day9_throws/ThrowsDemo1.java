import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter; //to write something after creating file
import java.io.IOException;
class ThrowsD
{
void createFile(String path,String text) throws IOException
{
	//FileInputStream f=new FileInputStream("d:/yash.txt");
	FileWriter writer=new FileWriter(path,true);
	writer.write(text);
	writer.close();
}
}

class ThrowsDemo1
{
	public static void main(String args[])
	{   String path1=""; //if there is path "file.txt" then no error
	    String text="Hii i am in file";
		ThrowsD t = new ThrowsD();
		try{
		t.createFile(path1,text);
		}
		catch(IOException i)
		{
			i.printStackTrace();
		}
		
		System.out.println("Hello normal termination");
		
	}
}