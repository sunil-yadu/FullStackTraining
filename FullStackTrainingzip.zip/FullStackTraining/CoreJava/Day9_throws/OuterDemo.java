class Outer //Non-Static example of inner class
{
   /*void show() //if it is present then we need to create object of outer class to acces this method
     {
	System.out.println("Outer Show");
     }*/
    class Inner
{
     void show()
{  
	System.out.println("Outer Show");
}
}
}
public class OuterDemo
{
	public static void main(String []args)
	{
		Outer o=new Outer();
		Outer.Inner oi=o.new Inner(); //For Non-Static
		o.show();
	}
}
