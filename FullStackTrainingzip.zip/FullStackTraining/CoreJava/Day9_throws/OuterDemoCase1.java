class Outer //Static example of inner class
{
   void show1() //if it is present then we need to create object of outer class to acces this method
     {
	System.out.println("Outer Show");
     }
 static class Inner //if class Inner {} it will give error
{
     void show()
{  
	System.out.println("Outer Inner Show");
}
}
}
public class OuterDemoCase1
{
	public static void main(String []args)
	{
		//Outer o=new Outer();
		Outer.Inner oi=new Outer.Inner(); //Static-inner class
		oi.show();
		//o.show1();
		/*
		Outer.Inner oi=new Outer.Inner(); //Static-inner class
		oi.show();
		oi.show1();//variable of type inner
		*/
		/*Outer.Inner oi=o.new Inner();
		o.show();*/
	}
}
