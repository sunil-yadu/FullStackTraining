class TypeProcast
{
	void show(float a)//coid show(int a)
	{
		System.out.println("Int Methode");
	}
	void show(String b)
	{
		System.out.println("String methode");
	}
	public static void main(String []args)
	{
		TypeProcast t=new TypeProcast();
		t.show(2.6f); //t.show('j') or t.show(1);
	}
}