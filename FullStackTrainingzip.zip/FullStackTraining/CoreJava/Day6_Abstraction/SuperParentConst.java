//Super() to invoke parent class Constructor
//No need to call super() automatically call
class Const1
{
	Const1(){
	System.out.println("i am in class Const1 ");
	}
}
class SuperParentConst extends Const1
{
	SuperParentConst()
	{
		System.out.println("I am in SuperParentConst");
	}

	public static void main(String []args)
	{
		SuperParentConst sp=new SuperParentConst();
	}
}