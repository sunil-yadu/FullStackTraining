class AnonyArray
{
	public static void main(String []args)
	{
		AnonyArray.sum(new int[]{10,30,40});
	}
	static void sum(int[]no)
	{
		int total=0;
		for(int i:no)
		{
			total =total+i;
		}
		System.out.println("Sum is: "+total);
	}
}