//interFace Implementation
interface A1
{
 //public abstract void show(); boyh will work same
 void show();

//public static final int a=20;
int a=20;
}

class InterFace implements A1
{
	public void show()
	{
		System.out.println("in Demo class");
		
	}
	public static void main(String []args)
	{
		InterFace d=new InterFace();
		d.show();
	}
}