class Parent
{
void display()
{
System.out.println("I am in class A-display");
}
}
class InvokeParentMethode extends Parent{

void display()
{
	System.out.println("I am in InvokeParentMethode");
}
void show()
{

	super.display(); //I am in class A-display
		display(); //i am in InvokeParentMethode
	
}
public static void main(String []args)
{
	InvokeParentMethode ipm=new InvokeParentMethode();
	ipm.show();
}
}
