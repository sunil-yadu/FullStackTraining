interface Food
{
 void lunch();
}
interface LightFood
{
 void breakFast();
}

class MultiInheritanceUIF implements Food,LightFood
{
public void lunch()
{
	System.out.println("Lets take lunch");
}
public void breakFast()
{
	System.out.println("Lets take breakFast");
}

public static void main(String []args)
{
	MultiInheritanceUIF m=new MultiInheritanceUIF();
	m.lunch();
	m.breakFast();
}
}