//Super keyword used to invoke immediate parent class instance variable
class A
{
	String s="Yadu";
     int a=100;

}

class SuperClassEx extends A
{
  String s="Sunil";
  int a=200;
  
  void display(int a,String s)
  {
	  System.out.println(a);
	   System.out.println(this.a);
	    System.out.println(super.s);
	    System.out.println(s);
		 System.out.println(this.s);
		  System.out.println(super.s);
	  
  }
  public static void main(String args[])
  {
	  SuperClassEx sc=new SuperClassEx();
	  sc.display(300,"Radhe");
  }

}