class Exception{
public static void main(String args[])
{
	Object o=new Integer(1);
	System.out.println((String)o);
	//System.out.println(o);
	//Type caste like python
}
}
