import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;

import java.io.*;

class ReflectionDemo
{
	public static void main(String[] args) throws Exception
	{
	 Student s1=new Student("sunil",20);
	 Class st=s1.getClass();
	 Method[] m=st.getMethods();
	 for(Method m2:m)
	 {
		 System.out.println(m2.getName());
	 }
	 
	 Field[] fa=st.getDeclaredFields();
	 for(Field f1:fa)
	 {
		 System.out.println(f1.getName());
	 }
	}
}