//package jad; //couldnot find main classException
import java.io.File;
import java.io.FileReader;
import java.io.*;
import java.io.FileInputStream;
class CheckedExceptionAssignment
{
	public static void main(String[] args) throws Exception
	{ 
	try{
		File f=new File("C:/Users/Sunil.M/Desktop/Trainee/Day11_/yash3.srt");
		FileReader fr=new FileReader(f);
	}
	catch(FileNotFoundException fe)
	{
		System.out.println(fe);
	}
	try{
		throw new InterruptedException("Exception is here");
		
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
		
		
	}
}