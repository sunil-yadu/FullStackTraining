import java.util.Scanner;
import java.io.*;
class ExceptionAssignment
{
	public static void main(String[] args)
	{
	int a=10;
	int b=0;
	try{
	System.out.println(a/b);//ArithmeticException
	}
	catch(ArithmeticException ai){
		System.out.println(ai);
	}
	//ArrayOutOfBoundException
	try{
	int arr[]=new int[3];
	for(int i=0;i<4;i++)
	{
		arr[i]=arr[i];
	}
	}
	catch(IndexOutOfBoundsException ab){
		System.out.println(ab);
		
	}
	try{
	String s=null;
	System.out.println(s.equals("sunil"));
	//NullPointerException
	
	
	}catch(NullPointerException n)
	{
		System.out.println(n);
	}
	try{
	
	
	
	//InputMismatchException
	Object o=Integer.valueOf(56);
	String s1=(String)o;
	}
	catch(IllegalArgumentException ip)
	{
	  System.out.println(ip);
	}
	try{
	Scanner sc=new Scanner(System.in);
	int arg=sc.nextInt();
	}catch(ClassCastException cl)
	{
		System.out.println(cl);
	}
}
}