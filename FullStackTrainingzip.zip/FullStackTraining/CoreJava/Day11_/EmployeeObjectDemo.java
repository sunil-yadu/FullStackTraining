import java.io.*;
class Employee implements Serializable
{
	int empId;
	String empName;
	Employee(int empId,String empName)
	{
		this.empId=empId;
		this.empName=empName;
		
	}
	public String toString() //to print actual value of object
	{
		return empId+ "" +empName;
	}
}
class EmployeeObjectDemo
{
	public static void main(String[] args) throws Exception
	{
		Employee e= new Employee(27,"Sunil");
		System.out.println(e);
		File f=new File("C:/Users/Sunil.M/Desktop/Trainee/Day11_/yash2.ser");//yash.txt
		f.createNewFile();
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
	}
}