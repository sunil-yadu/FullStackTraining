class EnumWeek
{
	enum Directions
	{
		EAST(12),WEST(10),NORT(14),SOUTH(45);
		int val;
		Season(int val)
		{
			this.val=val;
		}
		//to take value of it
		
	}
	public static void main(String[] args)
	{
		for(Directions d:Directions.values())
		{
			System.out.println(d+ " = " +d.val);
		}
		
	}
}