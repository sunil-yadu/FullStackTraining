import java.io.*;
class Employee implements Serializable
{
	double salary;
	String empName;
	String department;
	String designation;
	Employee(double salary,String empName,String department,String designation)
	{    
	    this.salary=salary;
		this.empName=empName;
		this.department=department;
		this.designation=designation;
		
		
		
	}
	public String toString() //print object value but still some error
	{
		return empName +" " +department + " " +designation + " "+salary;
	}
}
class EmployeeAssignment
{
	public static void main(String[] args) throws Exception
	{
		Employee e= new Employee(27000,"Sunil","CS_IT","Trainee");
		System.out.println(e);
		File f=new File("C:/Users/Sunil.M/Desktop/Trainee/Day11_/yash3.txt");//yash.txt
		f.createNewFile();
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e.toString());
		oos.close();
	
		
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));//FileInputStream to read input from file
		Employee r=(Employee)ois.readObject();
		ois.close();
		System.out.println(r);
	}
}