class EnumOrdinal
{
	enum Directions
	{
		EAST,WEST,NORT,SOUTH;
		
		
	}
	public static void main(String[] args)
	{
		for(Directin d:Direction.values())
		{
			System.out.println(d+ " = " +d.val);
		}
		
	}
}