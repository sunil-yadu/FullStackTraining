class EnumSeason
{
	enum Season
	{
		WINTER('s'),SUMMER('y'),RAIN('d'),COLD('v');
		char val;
		Season(char val)
		{
			this.val=val;
		}
		//to take value of it
		
	}
	public static void main(String[] args)
	{
		for(Season s:Season.values())
		{
			System.out.println(s+ " = " +s.val);
		}
		
	}
}