import java.io.*;
class Employee implements Serializable
{
	double salary;
	String empName;
	String department;
	String designation;
	Employee(double salary,String empName,String department,String designation)
	{    
	    this.salary=salary;
		this.empName=empName;
		this.department=department;
		this.designation=designation;
		
		
		
	}
	public String tostring()
	{
		return salary+ "" +empName +" " +department + " " +designation;
	}
}
class EmployeeAssignmentRead
{
	public static void main(String[] args) throws Exception
	{
		File f=new File("C:/Users/Sunil.M/Desktop/Trainee/Day11_/yash3.txt");//yash.txt
		
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));//FileInputStream to read input from file
		Employee e=(Employee)ois.readObject();
		ois.close();
		System.out.println(e);
	}
}