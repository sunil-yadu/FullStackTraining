class EnumWeek
{
	enum Week{
		MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY;
		
	}
	public static void main(String args[])
	{
	    Week w;
		w=Week.MONDAY;
		
		
		{
			switch(w)
			{
				case MONDAY:
				    System.out.println("Monday is here");
					break;
				case TUESDAY:
				    System.out.println("Tuesday is here");
					break;
				case WEDNESDAY:
				     System.out.println("Wed is here");
					break;
				case THURSDAY:
				    System.out.println("Thur is here");
					break;
				case FRIDAY:
				     System.out.println("Friday is here");
					break;
				case SATURDAY:
				     System.out.println("Saturday is here");
					break;
				default:
				    System.out.println("Sunday is here");
					break;
					
			}
			
				System.out.println(Week.valueOf("MONDAY").ordinal());
			
				
			
		}
	}
}