import java.util.Properties;
import java.util.Iterator;
import java.util.HashSet;
import java.util.Set;
import java.util.Map.Entry;


public class PropertiesAssignment {

	public static void main(String[] args)
	{
	 Properties p=new Properties();
	 p.setProperty("MP", "Bhopal");
	
	 p.setProperty("Bihar", "Patna");
	 p.setProperty("UP", "Lucknow");
	 Set<Entry<Object,Object>> set = p.entrySet();
	 Iterator<Entry<Object,Object>> i=set.iterator();
	 
	 while(i.hasNext())
	 {
		 Entry<Object,Object> entr=i.next();
		 System.out.println(entr);
	 }
	 
	}
}
