

import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.HashSet;
import java.util.*;
import java.util.Iterator;
public class ContactIterator
{
	public static void main(String[] args)
	{
		Map<String,Integer> contactList=new HashMap<String,Integer>();
		contactList.put("sunil",1033);
		contactList.put("yadu",3894);
		contactList.put("vanshi",1234);
		
		List<String> l=new ArrayList<>(contactList.keySet());
		
		System.out.println(l);
       //For Key Existence
		Iterator<String> iKey=l.iterator();
		String existKey="sunil";
		//to check element exist or not
		while(iKey.hasNext())
		{
			if(iKey.next().equals(existKey))
			{
				System.out.println("Key Exist");
				break;
			}
			else
			{
				System.out.println("Key does not Exist");
			}
		}
		
		
        List<Integer> value = new ArrayList<>(contactList.values());
        
		System.out.println(value);
		
		//For value Existence
		Iterator<Integer> i=value.iterator();
		
		int existValue=1033;
		//to check element exist or not
		while(i.hasNext())
		{
			if(i.next().equals(existValue))
			{
				System.out.println("Value Exist");
				break;
			}
			else
			{
				System.out.println("Value does not Exist");
			}
		}
		
	}
}