import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.HashSet;
import java.util.*;
class MapDemo
{
	public static void main(String[] args)
	{
		Map map=new HashMap();
		map.put(10,"sunil");
		map.put(20,"yadu");
		map.put(30,"vanshi");
		
		//to cover map into set for traversing
		Set s=map.entrySet(); //convert to set traverse
		Iterator i=s.iterator();
		while(i.hasNext())
		{
		 Map.Entry entry = (Map.Entry)i.next();//value separation
         System.out.println("Key:"+entry.getKey()+"Value:"+entry.getValue());
		 
		}
		
		
		
	}
}