import java.util.PriorityQueue;
import java.util.Queue;
import java.util.LinkedList;
class PriorityQueueDemo
{
	public static void main(String[] args)
	{
		
		Queue<Integer> pq=new PriorityQueue<Integer>();
		pq.add(200);
		pq.add(300);
		pq.add(300);
		System.out.println(pq.peek());//Top Element=200
		System.out.println(pq.poll());//200
		System.out.println(pq.peek());//300
		pq.remove();
		Queue<Integer> li=new LinkedList<Integer>();
		li.add(1000);
		li.add(2000);
		li.add(3000);
		System.out.println(pq.peek());
		System.out.println(pq.poll());
		System.out.println(pq.peek());
		li.poll();
		li.poll(); //it will run whether queue empty or not
		li.poll();
		//li.remove(); it will throw exception if ques is empty
		
		
		
	}
}