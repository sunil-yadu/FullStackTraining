import java.util.Properties;
import java.util.Iterator;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;
import java.util.HashMap;
class Setter
{
	String countryName;
	String capital;
	
	public void saveCountryCapital(String countryName,String capital)
	{
		this.countryName=countryName;
		this.capital=capital;
	}
	public String getCountryName()
	{
		return countryName;
	}
	public String getCountryCapital()
	{
		return capital;
	}
}
class CountryMapAssignment
{
	public static void main(String[] args)
	{    Setter m1=new Setter();
		//Map<String,String> m1=new HashMap<String,String>();
		m1.saveCountryCapital("India","Delhi");
		m1.saveCountryCapital("USA","Washington");
		
		System.out.println(m1.getCountryName());
		System.out.println(m1.getCountryCapital());
		System.out.println(m1.toArrayList());
		
	}
}