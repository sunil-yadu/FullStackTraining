import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.HashSet;
import java.util.*;
import java.util.Iterator;
class HashMapAssignment1
{
	public static void main(String[] args)
	{
		Map<Integer,String> map=new HashMap<Integer,String>();
		map.put(10,"sunil");
		map.put(20,"yadu");
		map.put(30,"vanshi");
		/*for(Map.Entry m:map.entrySet())
		{
			System.out.println("Key:"+m.getKey()+"Value:"+m.getValue());
		}*/
		
		List<Integer> l=new ArrayList<>(map.keySet());
		
		System.out.println(l);
		
		List<String> value = new ArrayList<>(map.values());
		Collections.sort(l);
		System.out.println(value);
		
		//For Key Existence
		Iterator<Integer> iKey=l.iterator();
		
		int existKey=10;
		//to check element exist or not
		while(iKey.hasNext())
		{
			if(iKey.next().equals(existKey))
			{
				System.out.println("Key Exist");
				break;
			}
			else
			{
				System.out.println("Key does not Exist");
			}
		}
		
		

		//For value Existence
		Iterator<String> i=value.iterator();
		
		String existValue="sunil";
		//to check element exist or not
		while(i.hasNext())
		{
			if(i.next().equals(existValue))
			{
				System.out.println("Value Exist");
				break;
			}
			else
			{
				System.out.println("Value does not Exist");
			}
		}
		
	}
}