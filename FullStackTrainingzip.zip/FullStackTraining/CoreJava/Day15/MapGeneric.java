import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.HashSet;
import java.util.*;
class MapGeneric
{
	public static void main(String[] args)
	{
		Map<Integer,String> map=new HashMap<Integer,String>();
		map.put(10,"sunil");
		map.put(20,"yadu");
		map.put(30,"vanshi");
		/*for(Map.Entry m:map.entrySet())
		{
			System.out.println("Key:"+m.getKey()+"Value:"+m.getValue());
		}*/
		
		List<Integer> l=new ArrayList<>(map.keySet());
		Collections.sort(l);
		System.out.println(l);
		
		List<String> value = new ArrayList<>(map.values());
		Collections.sort(l);
		System.out.println(value);
		
		
		}
}