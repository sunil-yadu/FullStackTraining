import java.util.HashSet;
import java.util.Iterator;

class HashSetAssignment1
{
	public static void main(String[] args)
	{
		HashSet<String> hs=new HashSet<String>();
		hs.add("Sunil");
		hs.add("Tiger");
		hs.add("Vidhyut");
		//OutPut might be random not in serialized way
		Iterator<String> i = hs.iterator();
		
		while(i.hasNext())
			System.out.println(i.next());
		
	}

}