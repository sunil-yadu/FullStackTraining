import java.util.Iterator;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;
import java.util.ListIterator;
import java.util.Vector;
import java.util.Enumeration;

class ArrayListVectorAssignment3
{
	public static void main(String[] args)
	{
	
	Vector<String> v=new Vector<String>();
	
	v.add("January");
	v.add("Fab");
	v.add("March");
	v.add("April");
	v.add("May");
	v.add("June");
	v.add("July");
	v.add("August");
	v.add("Sept");
	v.add("Oct");
	v.add("Nov");
	v.add("Dec");
	System.out.println(v);
	
	  Enumeration e= v.elements();
	  
	  while(e.hasMoreElements())
	  {
		  System.out.println(e.nextElement());
	  }
	
	
	
	}
}