import java.util.Vector;
import java.util.Enumeration;
import java.util.Iterator;

class EmployeeVector
{
  int id;
  String name;
  String surName;
  double salary;
  
  public EmployeeVector(int id,String name,String surName,double salary)
  {
	  this.id=id;
	  this.name=name;
	  this.surName=surName;
	  this.salary=salary;
  }
  
  public String toString()
  {
	  //return "Employee[id= "+id+",name= "+name+",surName= "+surName+",salary= "+salary+"]";
	  return id +name +surName +salary; //to print only value of employee
  }
  
}
public class EmployeeVectorAssignment4
{
	public static void main(String[] args)
	{
		Vector<EmployeeVector> v=new Vector<EmployeeVector>();
		
		v.add(new EmployeeVector(1,"Sunil","Yadu",100000));
		v.add(new EmployeeVector(2,"Soham","Vyas",800000));
		v.add(new EmployeeVector(3,"Aman","Pal",10000));
		v.add(new EmployeeVector(4,"Shubham","Panchal",70000));
		
		Iterator<EmployeeVector> i=v.iterator();
		
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		System.out.println();
		
		Enumeration e= v.elements();
	  
	  while(e.hasMoreElements())
	  {
		  System.out.println(e.nextElement());
	  }
		
	}
}