import java.util.Iterator;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;
import java.util.ListIterator;
import java.util.LinkedList;

class LinkedListAssignment2
{
  public static void main(String[] args)
  {
	  LinkedList<Double> intList=new LinkedList<Double>();
	  intList.add(1.0);
	  intList.add(4.32);
	  //intList.add("Hii"); //Error not suitable
	  System.out.println(intList);
  }
	
}