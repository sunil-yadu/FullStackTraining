import java.util.Iterator;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Collections;
class VectorAssignment
{
  public static void main(String[] args)
  {
	  Vector<String> v=new Vector<String>();
	  v.add("Hii");
	  v.add("Sunil");
	 
	  Enumeration e= v.elements();
	  
	  while(e.hasMoreElements())
	  {
		  System.out.println(e.nextElement());
	  }
	  
  }
	
}