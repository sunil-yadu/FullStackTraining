import java.util.Iterator;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;
import java.util.ListIterator;
import java.util.LinkedList;

class LinkeHashSet
{
  public static void main(String[] args)
  {
	  HashSet<String> h=new HashSet<String>();
	  h.add("Hii");
	  h.add("Sunil");
	  Iterator<String>i=h.iterator();
	  while(i.hasNext())
	  {
		  System.out.println(i.next());
	  }
	  
  }
	
}