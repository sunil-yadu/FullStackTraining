import java.util.Iterator;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;
import java.util.ListIterator;
import java.util.LinkedList;

class LinkedListAssignment
{
  public static void main(String[] args)
  {
	  LinkedList<Integer> intList=new LinkedList<Integer>();
	  intList.add(1);
	  intList.add(4);
	  System.out.println(intList);
  }
	
}