import java.util.Iterator;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Collections;
import java.util.ListIterator;

class ArrayListAssignment
{
	public static void main(String[] args)
	{
	ArrayList<String> a=new ArrayList<String>();
	
	//ArrayList a=new ArrayList(); javac ArrayListTest.java -Xlint:unchecked
	a.add("January");
	a.add("Fab");
	a.add("March");
	a.add("April");
	a.add("May");
	a.add("June");
	a.add("July");
	a.add("August");
	a.add("Sept");
	a.add("Oct");
	a.add("Nov");
	a.add("Dec");
	System.out.println(a);
	
	ListIterator<String> li=a.listIterator<String>();
	//ListIterator li=a.listIterator();
	li.next();
	//li.next();
	
	while(li.hasPrevious())
	{
		System.out.println(li.previous());
	}
	//li.add("hii");
	//System.out.println(a);
	//li.set("buddy");
	//System.out.println(a);
	
	/*for(String i:a)
	{
		System.out.println(i);
	}
	Iterator i=a.iterator();
	while(i.hasNext())
	{
		System.out.println(i.next());
	}
	System.out.println("Second Month:"+a.get(1));
	System.out.println(a);
	
	Collections.sort(a);
	*/
	
	}
}