import java.util.TreeSet;
import java.util.Iterator;
import java.util.ListIterator;

class TreeSetAssignment
{
	public static void main(String[] args)
	{
		TreeSet<String> ts=new TreeSet<>();
		//if we will not put generic here in constructor then also it will run
		ts.add("Sunil");
		ts.add("Sunil Yadu");
		ts.add("Tiger");
		ts.add("Vidhyut");
		
		
		Iterator<String> i=ts.iterator();
		
		String existElement="Sunil";
		//to check element exist or not
		while(i.hasNext())
		{
			if(i.next().equals(existElement))
			{
				System.out.println("Element Exist");
				break;
			}
			else
			{
				System.out.println("Element does not Exist");
			}
		}
		
		//b iterate the element of the treeset
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		
		/*//Not working
		while(i.hasPrevious())
		{
			System.out.prinln(i.previous()+" ");
		}
		*/
	}


}