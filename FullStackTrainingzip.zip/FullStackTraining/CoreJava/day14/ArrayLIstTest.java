import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

class ArrayListTest
{
	public static void main(String[] args)
	{
	ArrayList<Integer> a=new ArrayList<Integer>();
	//ArrayList a=new ArrayList(); javac ArrayListTest.java -Xlint:unchecked
	a.add(10);
	a.add(20);
	System.out.println(a);
	for(int i:a)
	{
		System.out.println(i);
	}
	}
}