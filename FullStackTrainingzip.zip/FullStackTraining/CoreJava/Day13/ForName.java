

public class ForName {
	public static void main(String[] args)
		throws ClassNotFoundException
	{
		
		Class c1 = Class.forName("Integer");

		System.out.print("Class Reflectin using .forName() "
						+ c1.toString());
						
	    System.out.println();
	    Object obj = new Integer(10);  //here object is integer type so output will be java.lang.Integer
		
						
        Class a = obj.getClass();   
        System.out.println("Object using reflectin " + a.getName());  
	}
}
