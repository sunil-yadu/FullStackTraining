class IsArrayDemo
{
	public static void main(String[] args)
	{
		int arr1[]={1,3};
		Class c1=arr1.getClass();
		boolean ar1=c1.isArray();
		System.out.println(ar1);
		
		String s="Hii i am here";
		Class cl=s.getClass();
		boolean arr=cl.isArray();
		System.out.println(arr);
		Class <int[]> c=int[].class;
		System.out.println(c.isArray());
	}
}