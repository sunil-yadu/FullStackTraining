class A{}
class DeoGetClass
{
	void show(Object o)
	{
		Class c=o.getClass();
		System.out.println(c.getName());
	}
	public static void main(String[] args)
	{
		A a= new A();
		DemoGetClass d = new DemoGetClass();
		d.show(a);
	}
}