package com.yash.employeeTask;

public class EmployeeInfo {
	private String name;
	private String address;
	private int contact;
	private int empId;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getContact() {
		return contact;
	}
	public void setContact(int contact) {
		this.contact = contact;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	@Override
	public String toString() {
		return "EmployeeInfo [name=" + name + ", address=" + address + ", contact=" + contact + ", empId=" + empId
				+ "]";
	}
	 
	

}
