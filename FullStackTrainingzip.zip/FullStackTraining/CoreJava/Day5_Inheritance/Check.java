class Teacher
{
	private double salary;
	public Teacher(String n,int byear,double s)
	{
		super(n,byear);
	}
	public String toString()
	{
		return "Teacher [super="+super.toString()+",salary="+salary+"]";
	}
}
class Person
{
	private String name;
	private int birthYear;
	public int person(String n,int byear)
	{
		name=n;
		birthYear=byear;
	}
	public String toString()
	{
		return "Person[name="+name+",birthYear="+ birthYear+"]";
	}
}
class Student extends Person{
private String major;
public int student(String n,int byear,String m)
{
	super(n,byear);
	major=m;
}
public String toString()
{
	return "Student[super="+super.toString()+",major="+major+"]";
}

}
class Check
{
	public static void main(String args[])
	{
		Person a= new Person("Sunil",2000);
		Student b= new Student("Ram",2001,"Cs");
		Teacher t=new Teacher("jaynam",1995,100000);
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
}