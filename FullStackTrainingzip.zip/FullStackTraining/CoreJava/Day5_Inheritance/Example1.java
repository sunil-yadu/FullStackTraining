class Author
{
 String name;
 String email;
 char gender;
Author(String name,String email,char gender)
{
	this.name=name;
	this.email=email;
	this.gender=gender;
}

}

class Book extends Author
{
	 String bookName;
	double price;
	int qntInStock;
	Book(String name,String email,String bookName,double price,int qntInStock)
	{
		super(name,email);
		this.bookName=bookName;
		this.price=price;
		this.qntInStock=qntInStock;
	}
	
}



class Example1
{
	Book b=new Book("sunil","sunil@gmail.com","java Basic",1200,3);

	
}