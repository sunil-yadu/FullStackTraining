class A
{
	
	public void display(String a)
	{
		System.out.println("i am in m2 of class A");
	}
}
class B extends A
{
	public void display(Object s)
	{
		System.out.println("i am in m2 of class B");
		
	}
}
class MainTest1
{
	public static void main(String args[])
	{
		A a=new A();
		a.display("Sunil");
	
		B b=new B();
		b.display("Sunil");
	}
}