class Animal{
void walk()
{
System.out.println("Walking");
}
void bark()
{
	System.out.println("Bark");
}
}
class Dog extends Animal{
public static void main(String args[])
{
Dog d=new Dog();
d.walk();
d.bark();
}
}