//Assignment1 inheritance
class Animal
{
	void eat()
	{
		System.out.println("Eating Mode Activated:");
		System.out.println();
	}
	void sleep()
	{
		System.out.println("Sleepin Mode Activated:");
		System.out.println();
	}
}
class Bird extends Animal
{
	void fly()
	{
		System.out.println("Birds can fly");
		System.out.println();
	}
	public static void main(String []args)
	{
		Animal a=new Animal();
		a.eat();
		a.sleep();
		Bird b=new Bird();
		b.eat();
		b.sleep();
		b.fly();
	}
}