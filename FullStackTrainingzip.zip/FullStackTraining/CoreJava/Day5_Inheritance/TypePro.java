class TypePro
{
	void show(int a)
	{
		System.out.println("Int Method");
	}
	void show(String b)
	{
		System.out.println("String Method");
	}
	public static void main(String args[])
	{
		TypePro t=new TypePro();
		t.show(1.4);
	}
}
