//Overriding Example Assignment4
class Fruit
{
	String name;
	String taste;
	String size;
	public void eat(String name,String taste,String size )
	{
		this.name=name;
		this.taste=taste;
		this.size=size;
		
		System.out.println("Fruit Taste");
		
		System.out.println("Fruit Name: "+name);
		
		System.out.println("Fruit taste: "+taste);
		
		System.out.println("Fruit Size: "+size);
		
		
		
	}
}
class Apple extends Fruit
{
	public void eat()
	{  
	System.out.println("Apple Taste eat() :");
	System.out.println();
	
	}
}
class Orange extends Fruit
{
	public void eat()
	{
		System.out.println("Orange Taste eat() :");
		System.out.println();
	}
}
class Taste
{
	public static void main(String []args)
	{
		Apple a=new Apple();
		a.eat("Apple","Osm","Small");
		Orange o=new Orange();
		o.eat();
		a.eat();
	}
}
