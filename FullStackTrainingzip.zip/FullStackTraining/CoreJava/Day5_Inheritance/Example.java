//Assignment3 inheritance
class Person{
	String name;
	String dateOfBirth;
	Person(String name,String dateOfBirth)
	{
		this.name=name;
		this.dateOfBirth=dateOfBirth;
	}

}
class Teacher extends Person
{
	double salary;
	String subject;
	Teacher(String name,String dateOfBirth,double salary,String subject)
	{
		super(name,dateOfBirth);
		this.salary=salary;
		this.subject=subject;
	}
	void display()
	{    System.out.println();
		System.out.println("you are in Teacher class");
		System.out.println("Name: "+name);
		System.out.println("Date Of Birth: "+dateOfBirth);
		System.out.println("Salary: "+salary);
		System.out.println("Subject: "+subject);
	}
}
class Student extends Person
{
	int studentId;
	Student(String name,String dateOfBirth,int studentId)
	{
		super(name,dateOfBirth);
		this.studentId=studentId;
		
	}
	void display()
	{     System.out.println();
		System.out.println("you are in Student class");
		System.out.println("Name: "+name);
		System.out.println("Date Of Birth: "+dateOfBirth);
		System.out.println("Salary: "+studentId);
		//System.out.println("Subject: "+subject);
	}
	
}
class CollegeStudent extends Student
{
	String collegName;
	String year;
	CollegeStudent(String name,String dateOfBirth,int studentId,String year,String collegName)
	{
		super(name,dateOfBirth,studentId);
		this.year=year;
		this.collegName=collegName;
	}
	void display()
	{   System.out.println();
		System.out.println("you are in collegeStudent class");
		System.out.println("Name: "+name);
		System.out.println("Date Of Birth: "+dateOfBirth);
		System.out.println("studentId: "+studentId);
		System.out.println("year :"+year );
		System.out.println("collegName :"+collegName );
	}
}



public class Example{
	public static void main(String []args)
	{
		Teacher t=new Teacher("Sunil","15/10/2000",50000,"java");
		Student s=new Student("Ram","18/08/2000",101);
		CollegeStudent cs=new CollegeStudent("rahul","05/10/2000",103,"2022","IET");
		t.display();
		s.display();
		cs.display();
	}
}