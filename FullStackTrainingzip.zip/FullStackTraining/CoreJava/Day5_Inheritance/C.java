class A{
void display()
{
System.out.println("In a class");
}
}
class B extends A
{
 void displayB()
 {
	 System.out.println("In class B");
 }
}
class C extends A
{
	void displayC()
	{
		System.out.println("in class C");
	}
	public static void main(String args[])
	{
		A ob1=new A();
		ob1.display();
		B ob2=new B();
		ob2.display();
		ob2.displayB();
		C ob3=new C();
		ob3.display();
		//ob3.displayB();
		ob3.displayC();
	}
}