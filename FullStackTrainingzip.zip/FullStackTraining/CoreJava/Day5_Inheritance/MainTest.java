class A
{
	
	public void m2()
	{
		System.out.println("i am in m2 of class A");
	}
}
class B extends A
{
	public void m2()
	{
		System.out.println("i am in m2 of class B");
		
	}
}
class MainTest
{
	public static void main(String args[])
	{
		A a=new A();
		a.m2();
	
		B b=new B();
		b.m2();
	}
}