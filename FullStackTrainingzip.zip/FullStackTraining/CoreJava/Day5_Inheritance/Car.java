class Vhicle
{
void color()
{
	System.out.println("Black");

}
}
class Bike extends Vhicle{
void average()
{
	System.out.println("20kmph");
}
}
class Car extends Bike
{
	void seat()
	{
		System.out.println("4 seat");
	}
	public static void main(String args[])
	{
		Vhicle v = new Vhicle();
		v.color();
		Bike b=new Bike();
		b.color();
		b.average();
		Car c=new Car();
		c.color();
		c.average();
		c.seat();
	}
}