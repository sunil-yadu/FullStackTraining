class Author {
   
   private String name;
   private String email;
   private char gender;   
 
   
   public Author(String name, String email, char gender) {
      this.name = name;
      this.email = email;
      this.gender = gender;
   }
 
   
   public String getName() {
      return name;
   }
   
   public char getGender() {
      return gender;
   }
   
   public String getEmail() {
      return email;
   }
   
   public void setEmail(String email) {
      this.email = email;
   }
 
   
   public String toString() {
      return name + " (" + gender + ") at " + email;
   }
}

class Book {
  
   private String name;
   private Author author;
   private double price;
   private int qty;
 
   public Book(String name, Author author, double price, int qty) {
      this.name = name;
      this.author = author;
      this.price = price;
      this.qty = qty;
   }
 
   
   public String getName() {
      return name;
   }
   
   public Author getAuthor() {
      return author; 
   }
   
   public double getPrice() {
      return price;
   }
  
   public void setPrice(double price) {
      this.price = price;
   }
   
   public int getQty() {
      return qty;
   }
  
   public void setQty(int qty) {
      this.qty = qty;
   }
 
  
   public String toString() {
      return "'" + name + "' by " + author;  
   }
}

public class TestAuthor {
   public static void main(String[] args) {
     
     
	  Author author1 = new Author("Sunil", "sunil@gmail.com", 'm');
      System.out.println(author1); 
      

      
      author1.setEmail("sunil@gmail.com");
      System.out.println(author1);  
      
      System.out.println("name is: " + author1.getName());
      
      System.out.println("gender is: " + author1.getGender());
     
      System.out.println("email is: " + author1.getEmail());
      
      
      Book b1 = new Book("Java Beginers", author1, 8.39, 99);
      System.out.println(b1);  
     

      
      b1.setPrice(8.88);
      b1.setQty(88);
      System.out.println("name is: " + b1.getName());
      
      System.out.println("price is: " + b1.getPrice());
     
      System.out.println("qty is: " + b1.getQty());
      
      System.out.println("author is: " + b1.getAuthor());  
      
      System.out.println("author's name is: " + b1.getAuthor().getName());
     
      System.out.println("author's email is: " + b1.getAuthor().getEmail());
      
      System.out.println("author's gender is: " + b1.getAuthor().getGender());
      
     
     
   }
}