class Author{
private String name="";
String email="";
char gender="";
public void setAuthorName(String name)
{
	this.name=name;
}
public String getAuthorName()
{
	return name;
}
}
class Book{
	String name;
	String author;
	double price;
	int quantity;


}
class FinalSol
{
}