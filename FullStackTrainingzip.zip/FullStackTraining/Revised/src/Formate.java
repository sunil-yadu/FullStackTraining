
public class Formate {

	public static void main(String[] args)
	{
		int i=10;
		show();
		if(i<12)
		{
			System.out.println("value is lessar");
		}
		else
		{
			System.out.println("Value is greater then 12");
		}
	}
	 static void show()
	 {
		 for(int j=1;j<=5;j++)
		 {
			 System.out.println(j);
		 }
	 }
}
