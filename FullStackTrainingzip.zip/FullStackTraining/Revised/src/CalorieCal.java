import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.*;

//To get entered Information
class Info {
	double fat;
	// String name;
	int age;
	String gender;
	double height;
	double weight;
	int activity;
	double calculate;
	double bmrM;
	double bmrF;

	/*
	 * public void setName(String pName) { name=pName; }
	 */
	public void setAge(int pAge) {
		age = pAge;
	}

	public void setGender(String pGender) {
		gender = pGender;
	}

	public void setHeight(double pHeight) {
		height = pHeight;
	}

	public void setWeight(double pWeight) {
		weight = pWeight;
	}

	public void setActivity(int pActivity) {
		activity = pActivity;
	}

	/*
	 * public String getName() { return name; }
	 */
	public int getAge() {
		return age;
	}

	public String getGender() {
		return gender;
	}

	public double getHeight() {
		return age;
	}

	public double getWeight() {
		return weight;
	}

	public int getActivity() {
		return activity;
	}

	public void bmiCal() {
		double fat;
		JFrame frame = new JFrame();
		frame.setSize(800, 850);
		fat = weight / height / height * 10000;
		// System.out.println("BMI="+fat);
		if (fat <= 18.5) { // ImageIcon icon = new ImageIcon("C:\Users\Sunil.M\Desktop\Test\fit.jpg");
			JOptionPane.showMessageDialog(null, "You are Thin..", "BMI Cal Says:", JOptionPane.INFORMATION_MESSAGE);
		} else if (fat > 18.5) { // ImageIcon icon = new ImageIcon("C:\Users\Sunil.M\Desktop\Test\fit.jpg");
			JOptionPane.showMessageDialog(null, "You are Fit..", "BMI Cal Says:", JOptionPane.INFORMATION_MESSAGE);

		} else {
			// ImageIcon icon = new ImageIcon("C:\Users\Sunil.M\Desktop\Test\fit.jpg");
			JOptionPane.showMessageDialog(null, "You are Fatty..", "BMI Cal Says:", JOptionPane.INFORMATION_MESSAGE);
		}

	}

//To calculate BMR For Male bcz it is needed in calorie formula to find exact need.
	public double setBmrMale(double pWeight, double pHeight, int pAge) {

		this.bmrM = 10 * pWeight + 6.25 * pHeight - 5 * pAge + 5;
		// System.out.println("Bmr for Male is: " +bmrM);
		return bmrM;

	}
//To calculate BMR For Female to find exact need

	public double setBmrFemale(double pWeight, double pHeight, int pAge) {

		this.bmrF = 10 * pWeight + 6.25 * pHeight - 5 * pAge - 161;
		// System.out.println("Bmr for FeMale is: " +bmrF);
		return bmrF;

	}

//To display entered Information...

	public void display() {
		// System.out.println("Entered Name is :"+name);
		System.out.println("Entered age is :" + age);

		System.out.println("Gender is:" + gender);

		System.out.println("Entered Height is :" + height);
		System.out.println("Entered Weight is:" + weight);
		System.out.println("Entered activity is :" + activity);
		System.out.println("BmrM is :" + bmrM);
		System.out.println("BmrF is :" + bmrF);
		// System.out.println("Fat is :"+fat);

	}

	// To calculate Final need for active person..
	public void needCalorieActive() {
		// System.out.println("Calorie Need For Active Male:="+bmrM*1.375);
		JOptionPane.showMessageDialog(null, bmrM * 1.375, "Calorie Need For Active Male:=.", JOptionPane.PLAIN_MESSAGE);

	}

	//// To calculate Final need for Moderate person..
	public void needCalorieModerate() {
		// System.out.println("Calorie Need For Moderate Male:="+bmrM*1.5);
		JOptionPane.showMessageDialog(null, bmrM * 1.5, "Calorie Need For Moderate Male:=.", JOptionPane.PLAIN_MESSAGE);

	}

	// To calculate Final need for Hard person..
	public void needCalorieHard() {
		// System.out.println("Calorie Need For Hard Male:="+bmrM*1.7);
		JOptionPane.showMessageDialog(null, bmrM * 1.7, "Calorie Need For Hard Male:=.", JOptionPane.PLAIN_MESSAGE);

	}

	// To calculate Final need for active Female ..
	public void needCalorieActiveFemale() {
		// System.out.println("Calorie Need For Active Female :="+bmrF*1.375);
		JOptionPane.showMessageDialog(null, bmrM * 1.375, "Calorie Need For Active FeMale:=.",
				JOptionPane.PLAIN_MESSAGE);

	}

	// To calculate Final need for Moderate Female..
	public void needCalorieModerateFemale() {
		// System.out.println("Calorie Need For Moderate Female:="+bmrF*1.5);
		JOptionPane.showMessageDialog(null, bmrM * 1.5, "Calorie Need For Moderate FeMale:=.",
				JOptionPane.PLAIN_MESSAGE);

	}

	// To calculate Final need for Hard Female..
	public void needCalorieHardFemale() {
		// System.out.println("Calorie Need For Hard Female:="+bmrF*1.7);
		JOptionPane.showMessageDialog(null, bmrM * 1.7, "Calorie Need For Hard FeMale:=.", JOptionPane.PLAIN_MESSAGE);

	}

}

class CalorieCal extends Info {
	public static void main(String args[]) {
		System.out.println("Enter your activity level");
		System.out.println("1_Active: 2_Moderate: 3_Hard");

		Scanner choice = new Scanner(System.in);
		int a = choice.nextInt();

		/*
		 * System.out.println("Enter Name"); Scanner name1=new Scanner(System.in);
		 * String n=name1.next();
		 */

		System.out.println("Enter Age");
		Scanner age1 = new Scanner(System.in);
		int ag = age1.nextInt();

		System.out.println("Enter Gender: 1_Male 2_Female ");
		Scanner gender1 = new Scanner(System.in);
		String g = gender1.next();

		System.out.println("Enter Height in CM: ");
		Scanner height1 = new Scanner(System.in);
		double h = height1.nextDouble();

		System.out.println("Enter Weight in KG: ");
		Scanner weight1 = new Scanner(System.in);
		double w = weight1.nextDouble();
		Info f = new Info();
		if (a == 1) {

			switch (g) {
			case "male": {
				// System.out.println("Active");
				f.setBmrMale(w, h, ag);
				f.needCalorieActive();
				// f.display();
				break;

			}
			case "female": {
				System.out.println("Moderate");
				f.setBmrFemale(w, h, ag);
				f.needCalorieActiveFemale();
				// f.display();
				break;
			}

			default: {
				System.out.println("Please select right option");
			}
			}
		} else if (a == 2) {
			switch (g) {
			case "male": {
				System.out.println("Active");
				f.setBmrMale(w, h, ag);
				f.needCalorieModerate();
				// f.display();
				break;

			}
			case "female": {
				System.out.println("Moderate");
				f.setBmrFemale(w, h, ag);
				f.needCalorieModerateFemale();
				// f.display();
				break;
			}

			default: {
				System.out.println("Please select right option");
			}
			}

		} else if (a == 3) {
			switch (g) {
			case "male": {
				System.out.println("Active");
				f.setBmrMale(w, h, ag);
				f.needCalorieHard();
				// f.display();
				break;

			}
			case "female": {
				System.out.println("Moderate");
				f.setBmrFemale(w, h, ag);
				f.needCalorieHardFemale();
				// f.display();
				break;
			}

			default: {
				System.out.println("Please select right option");
			}
			}
		}

		f.setActivity(a);
		// f.setName(n);
		f.setAge(ag);
		f.setGender(g);
		f.setHeight(h);
		f.setWeight(w);
		// f.display();
		f.bmiCal();
		System.exit(0);

	}

}