class Animal {
	String color;
	int age;
	void show()
	{
		System.out.println(color);
	}
	
}

public class ObjectCreation  extends Animal {
	public static void main(String args[])
	{
	
	Animal sheru=new Animal();
	sheru.color="Black";
	sheru.age=20;
	sheru.show();
	
	
	}
}

