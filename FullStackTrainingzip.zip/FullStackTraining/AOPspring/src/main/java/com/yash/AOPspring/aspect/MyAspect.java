package com.yash.AOPspring.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class MyAspect {

	@Before("execution(* com.yash.AOPspring.services.PaymentServiceImpl.makePayment())")
	public void printBefore() {
		System.out.println("Payment Initilaized");
		System.out.println("Useing Before Annotation");
	}

	@After("execution(* com.yash.AOPspring.services.PaymentServiceImpl.makePayment())")
	public void printAfter() {
		System.out.println("Payment Completed");
		System.out.println("Using After Annotation");
	}

	@Before("execution(* com.yash.AOPspring.services.PaymentServiceImpl.sum(..,..))")
	public void printBeforeSum() {
		System.out.println();
		System.out.println("printBeforeSum Method");
		System.out.println("Using Before Annotation");
	}

	@After("execution(* com.yash.AOPspring.services.PaymentServiceImpl.sum(..,..))")
	public void printAfterSum() {

		System.out.println();

		System.out.println("printAfterSum  method ");
		System.out.println("Using After Annotation");
	}

	/*
	 * @Pointcut("execution(* com.yash.AOPspring.services.PaymentServiceImpl.makePayment())"
	 * ) public void pointcut() { System.out.println("PointCut Annotation"); }
	 * 
	 * @Before("pointcut") public void beforePointCut() {
	 * System.out.println("Before PointCut");
	 * 
	 * }
	 * 
	 * @After("pointcut") public void afterPointCut() {
	 * System.out.println("After PointCut");
	 * 
	 * }
	 */
}