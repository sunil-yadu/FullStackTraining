package com.yash.AOPspring.services;

public class PaymentServiceImpl implements PaymentService {




public void makePayment() {
// TODO Auto-generated method stub

System.out.println("Debit code");

//
//
System.out.println("Credit code");

}
public void sum(int a,int b)
{
	System.out.println("sum is");
	System.out.println(a+b);
}




}