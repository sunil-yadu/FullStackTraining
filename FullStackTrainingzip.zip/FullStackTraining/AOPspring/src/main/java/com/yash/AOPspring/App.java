package com.yash.AOPspring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.AOPspring.services.PaymentService;

/**
 * Hello world!
 *
 */

public class App
{
public static void main( String[] args )
{
ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/AOPspring/config.xml");
PaymentService pobject=context.getBean("payment",PaymentService.class);
pobject.makePayment();
pobject.sum(5,7);
}
}
