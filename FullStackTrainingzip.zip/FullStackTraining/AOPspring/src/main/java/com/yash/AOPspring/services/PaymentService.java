package com.yash.AOPspring.services;

public interface PaymentService {

public void makePayment();
public void sum(int i, int j);



}