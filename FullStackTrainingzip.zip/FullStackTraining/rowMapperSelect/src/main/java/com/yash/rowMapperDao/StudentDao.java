package com.yash.rowMapperDao;

import com.yash.rowMapperEntities.Student;

public interface StudentDao {
	public Student selectDetails(int stuid);
	

}
