package com.yash.rowMapperDao;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.JdbcTemplate;



import com.yash.rowMapperEntities.Student;

public class StudentDaoimpl implements StudentDao {
	private JdbcTemplate jdbctemp;
	public Student selectDetails(int stuid) {
		// TODO Auto-generated method stub
		String q="select * from student where id=?";
		RowMapper<Student> rowmapper=new RowMapperimpl();
		Student student=this.jdbctemp.queryForObject(q,rowmapper,stuid);

		return student;

		}
	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}
	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}

}
