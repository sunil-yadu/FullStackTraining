package log4j;
import org.apache.logging.log4j.*;

import org.apache.logging.log4j.LogManager;

public class LiggingDemoFirst {
	private static Logger demoLogger = LogManager.getLogger(LiggingDemoFirst.class.getName());
	public static void main(String[] args) {
		System.out.println("This is Sysout");
		demoLogger.info("Click SuccesFully");
		demoLogger.error("DB Connection Failed");
		demoLogger.debug("This is debug");
		
	}

}
