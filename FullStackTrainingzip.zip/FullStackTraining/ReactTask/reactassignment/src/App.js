
import LeftContent from './LeftContent';
import RightContent from './RightContent';
import Navigation from './Navigation';
import Queryform from './Queryform';
import Registrationform from './Registrationform';
import Loginform from './Loginform';



import './App.css';

function App() {
  return (
    <div className='Wrapper'>

    <div className='LeftPane'>

        <div className='Logo'>

          <LeftContent/>

        </div>

        <div className='Navigation'>

          <Navigation/>

        </div>

        <div className='Query'>

          <Queryform/>

        </div>

    </div>

    <div className='RightPane'>

      <div className='Bigimage'>

        <RightContent/>

      </div>

      <div className='Contentbox'>

        <div className='Content1'>

          <Registrationform/>

        </div>

        <div>

          <Loginform/>

        </div>

      </div>

    </div>

 </div> 
  );
}

export default App;
