import React, {Component} from 'react';
class RightContent extends Component
{
  render()
  {
    return (
        <div className='rcontent'>
                 
  
        </div>

    );
  }
}
export default RightContent