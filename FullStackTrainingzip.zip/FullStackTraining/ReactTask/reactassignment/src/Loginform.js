import React, {Component} from 'react';
class Loginform extends Component
{
  render()
  {
    return (
        <div className='loginformpage'>
                 
  Login content
          </div>

    );
  }
}
export default Loginform