import React, {Component} from 'react';
class Queryform extends Component
{
  render()
  {
    return (
        <div className='querypage'>
                 
  Queryform content
  <li>
    <ul>
    
      IT related Queries.

      </ul>
      <ul>
      Accommodation Related Queries.
      </ul>
      <ul>
      Relocation Related Queries.
      </ul>
      <ul>
      IT related Queries.
      </ul>

      <ul>
      Accommodation Related Queries.
      </ul>
      <ul>
      Relocation Related Queries.
      </ul>
      <ul>
      Relocation Related Queries.
      </ul>
    </li>
   
  
        </div>

    );
  }
}
export default Queryform