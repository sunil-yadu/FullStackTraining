import React, {Component} from 'react';
class Navigation extends Component
{
  render()
  {
    return (
        <div className='navigationpage'>
                 
  Navigation content
  
    <li>
      <ul>
      IPL is coming soon.
      </ul>

    
    <ul>
      Breaking News.
      </ul>
    
    <ul>
      Daily New Analysis.
      </ul>
    
    <ul>
    
      IT related Queries.
      </ul>
      

    </li>
   
    
        </div>

    );
  }
}
export default Navigation