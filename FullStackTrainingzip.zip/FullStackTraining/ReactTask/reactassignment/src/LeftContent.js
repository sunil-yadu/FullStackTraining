import React, {Component} from 'react';
class LeftContent extends Component
{
  render()
  {
    return (
        <div className='lcontent'>
                 
   <br></br>
 
  <br></br>
  <br></br>
  <br></br>

        </div>

    );
  }
}
export default LeftContent