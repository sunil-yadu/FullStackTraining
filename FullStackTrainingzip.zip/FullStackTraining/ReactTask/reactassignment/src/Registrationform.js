import React, {Component} from 'react';
class Registrationform extends Component
{
  render()
  {
    return (
        <div className='registrationpage'>
                 
  Registration content
  <br>
  </br>
        </div>

    );
  }
}
export default Registrationform