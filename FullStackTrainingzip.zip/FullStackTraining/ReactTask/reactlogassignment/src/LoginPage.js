import React, {Component} from 'react';
class LoginPage extends Component
{
  render()
  {
    return (    
<div className='login_page'>
    <div>
    <button className='login_button' id="backbutton"></button>
    </div>
    <div className='loginbox'>
      <div className='student'></div>
    
            <h1>User Login</h1>
            
            <form action="#" method="post" onSubmit="return login();">
                <p>Username</p>
               
                <input type="text" id="username" name="username" placeholder="Enter Username" required/>
                <p>Password</p>
                
                <input type="password" id="password" name="password" placeholder="Enter password" required/>
                
                <input type="submit" name="submit" value="Login" onclick="#" />
                <a href="#">Forget your password?</a><br/>
                <a href="">Don't  have an account?</a>   
            </form>
    </div>         
 </div>

    );
  }
}
export default LoginPage