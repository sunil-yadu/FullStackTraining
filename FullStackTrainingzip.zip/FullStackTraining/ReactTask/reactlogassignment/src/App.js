import Ragistrationform from './Ragistrationform';
import LoginPage from './LoginPage';

import './App.css';

function App() {
  return (
    <div className='view'>
      
      <div className='ragistration_page'>

        <Ragistrationform/>
      </div>
      <div className='login_page'>
        <LoginPage/>
      </div>

    </div>
  );
}

export default App
