import React, {Component} from 'react';
class Ragistrationform extends Component
{
  render()
  {
    return (
       
		<div class="main-form">           	
        <form action="" onsubmit="return validation()"  oncancel=" mainpage.php" method="post" >
    <div class="form-group">
        <table>
            <tr><td colspan="3"><center><b>USER REGISTRATION</b></center></td></tr>
                <tr>
                 <td><label>First name:</label></td><td><input type="text" name="Fname" id="Fuser" placeholder="Enter the First name"/></td>
                </tr>
                <tr><td></td>
                <td>
                <span id="Fname"></span>
                </td>
            </tr>
            <tr>
                        
            <td><label>Last name:</label></td><td><input type="text" name="Lname" id="Luser" placeholder="Enter the Last name"/></td>
            </tr>
            <tr><td></td>
            <td>
            <span id="Lname"></span>
            </td>
            </tr>
            <tr>
                        
            <td><label>AadharNo:</label></td><td><input type="text" name="RollNo" id="rollno" placeholder="Enter your Aadhar number"/>
            </td>
             </tr>
            <tr><td></td>
                <td>
                <span id="Rn"></span>
                </td>
            </tr>
            <tr>
            <td> 
                <label>Gender: </label></td><td>
   
               <input type="radio" name="gender" value="male"/> Male
               <input type="radio" name="gender" value="female"/> Female

            </td>
            </tr>
             <tr>
                 <td></td>
                <td>
                <span id="Branch"></span>
                </td>
            </tr>
            <tr>
                <td><label>Address:</label></td><td><input type="text" name="Semester" id="sem" placeholder="Address"/></td>
            </tr>
             <tr><td></td>
                <td>
                <span id="Semester"></span>
                </td>
            </tr>
            <tr>
                 <td><label>Password:</label></td><td><input type="password" name="Password" id="pass" placeholder="Enter the Password"/></td>
    
            </tr>
             <tr><td></td>
                <td>
                <span id="Password"></span>
                </td>
            </tr>
            
            <tr>
            <td><label>Retype Password:</label></td><td><input type="password" name="ConfPassword" id="pass1" placeholder="Enter the ConfPassword"/></td>
        
               
            </tr>
             <tr>
                 <td></td>
                <td>
                <span id="Confpass"></span>
                </td>
            </tr>
            <tr>
                <td><label>Email:</label></td><td><input type="text" name="Email" id="email" placeholder="Enter your Email"/></td>
            </tr>

            <tr><td></td>
                <td>
                <span id="Email"></span>
                </td>
            </tr>
            <tr>
            <td><label>Mobile:</label></td><td><input type="text" name="Mobile" id="mobile" placeholder="Enter the Mobile Number"/></td>
 </tr>
             <tr><td></td>
                <td>
                <span id="Mobile"></span>
                </td>
            </tr>
            
            <tr>
                <td>
                <input type="checkbox" id="t&c" name="t&c" value="t&C"/>
                <label for="t&c"> Accept T&C </label><br/>
                </td>
                <td>
    <input type="submit" name="submit" value="Submit" />
    </td>  </tr>
</table>
</div>
</form>
</div>


    );
  }
}
export default Ragistrationform