

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context = new ClassPathXmlApplicationContext("Applicationcontext.xml");
        A a = (A)context.getBean("refa");
        System.out.println(a.getX());
        System.out.println(a.getB().getY());
    }
}
