package springConstDemo;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context = new ClassPathXmlApplicationContext("springConstDemo/applicationcontext.xml");
        Employee e = (Employee)context.getBean("empci");
        System.out.println(e);
       
    }
}
