package com.yash.jdbcSpring;

public class Student {
private String gmail;
private String name;
public Student() {
super();
// TODO Auto-generated constructor stub
}
public Student(String name, String gmail) {
super();
this.name = name;
this.name = name;
}
public String getName() {
return name;
}
public String getgmail() {
return gmail;
}
public void setName(String name) {
this.name = name;
}
public void setGmail(String gmail) {
this.gmail = gmail;
}




}