package com.yash.jdbcSpring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Hello world!
 *
 */
public class App 
{
	public static void main( String[] args )
	{
	System.out.println( "Hello World!" );
	ApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
	JdbcTemplate temp = context.getBean("jdbctemp",JdbcTemplate.class);
	String q="insert into springdata(name,email) values(?,?)";

	int msg= temp.update(q,"Sunil","sunil@yash");
	System.out.println("record inserted" +msg);
	}
}
