package com.yash.springDemo1;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
       
        ApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"config.xml"});
        Employee e = (Employee)context.getBean("beanEmployee");
        System.out.println(e);
        Employee e1=(Employee) context.getBean("beanEmployee1");
        System.out.println(e1);
    }
}
