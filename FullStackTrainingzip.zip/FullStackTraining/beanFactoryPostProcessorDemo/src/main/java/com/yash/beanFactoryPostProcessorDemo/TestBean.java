package com.yash.beanFactoryPostProcessorDemo;

public class TestBean {
	public TestBean(){
		System.out.println("Object of TestBean is created.");
	}
} 