import testPackageAssignment.Foundation;
class Access
{
	public static void main(String args[])
	{
		Foundation f=new Foundation();
		//System.out.println(f.var1); //private not acccessed
		//System.out.println(f.var2); //cannot acces
		//System.out.println(f.var3);//access not possible
		System.out.println(f.var4); //accessed
		
	}
}